"""SDK hooks for OBS Agent.

- PreToolUse: guards immutable files/.env writes and blocks native tools
- Stop: route-local stop notifications; user Stop hooks may block ending the
  turn with ``{"decision": "block", "reason": ...}``
- PreCompact: opt-in handoff policy (``OBS_COMPACT_POLICY=handoff``): interrupt
  the CLI before it summarizes, so the runner can resume the same session with
  auto-compaction disabled and a handoff prompt (see docs/context-compaction.md)
- HookPipeline: extensible middleware that chains check functions
- HookState: shared state for message queuing and interrupt

See decisions D018, D022.
"""

from __future__ import annotations

# CACHE-PREFIX WARNING: hook additionalContext/reminder output must not
# silently alter historical API content. Stripped reminders retain their existing
# message breakpoint in the proxy. A break is silent: no error, the API just re-bills the whole conversation.
# Live check: scripts/cache_regression.py reminder_block ws_resume (docs/cache-proxy-safety.md).

import asyncio
import importlib.util
import inspect
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Awaitable

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    HookMatcher,
    SyncHookJSONOutput,
)

from obs_agent.lineage import obs_bootstrap_to_dict, resolve_obs_bootstrap
from obs_agent.queueing import QueuedMessage

if TYPE_CHECKING:
    from obs_agent.config import OBSConfig


# Write-mutating tool names that the guard should check
_WRITE_TOOLS = {"Write", "Edit", "NotebookEdit"}

# Read-only tools that are always allowed
_READ_TOOLS = {"Read", "Glob", "Grep", "Bash", "WebFetch", "WebSearch"}

# Native delegation tools are blocked so orchestration is forced through
# OBS-managed AgentTask tooling.
_BLOCKED_NATIVE_TASK_TOOLS = {"Task", "TaskStop"}  # TaskOutput allowed (read-only, useful for background bash)

# Native team inbox tools are blocked so worker messaging is forced through
# OBS-managed SendInboxMessage/ReadInbox implementations.
_BLOCKED_NATIVE_INBOX_TOOLS = {
    "SendMessage",
    "ReadMessage",
    "ReadMessages",
    "ListMessages",
    "GetMessages",
    "ReceiveMessages",
}

# Native runtime mode toggles are blocked in Telegram runtime.
_BLOCKED_NATIVE_MODE_TOOLS = {
    "EnterPlanMode",
}


def _normalize_tool_name(tool_name: str) -> str:
    """Normalize tool names from hook payloads.

    SDK hook payloads may report MCP tools as ``mcp__server__ToolName``.
    We normalize those to ``ToolName`` so deny/allow checks remain stable.
    """
    normalized = tool_name.strip()
    if normalized.startswith("mcp__"):
        parts = normalized.split("__", 2)
        if len(parts) == 3 and parts[2]:
            return parts[2]
    return normalized


def _deny(
    reason: str,
    *,
    additional_context: str | None = None,
    show_system_message: bool = False,
) -> dict:
    """Return a deny hook response with reason."""
    hook_output: dict[str, Any] = {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": reason,
    }
    if additional_context:
        hook_output["additionalContext"] = additional_context
    payload: dict[str, Any] = {
        "decision": "block",
        "reason": reason,
        "hookSpecificOutput": hook_output,
    }
    if show_system_message:
        payload["systemMessage"] = reason
    return payload


def on_pre_tool_use(
    tool_name: str,
    tool_input: dict,
    *,
    config: OBSConfig,
) -> dict | None:
    """Guard hook: block disallowed native tools and protected writes.

    Returns None to allow, or a deny dict to block.
    """
    normalized_tool_name = _normalize_tool_name(tool_name)

    if normalized_tool_name in _BLOCKED_NATIVE_TASK_TOOLS:
        return _deny(
            "Blocked by platform policy: native Task tools are disabled in Telegram runtime. "
            "Use AgentTask, AgentTaskOutput, and AgentTaskStop instead. "
            "TaskOutput is allowed for reading background task output.",
            additional_context=(
                "System: Native Task/TaskStop tools are disabled by platform policy in Telegram runtime. "
                "Do not retry Task/TaskStop; switch to AgentTask tools. TaskOutput is allowed."
            ),
            show_system_message=True,
        )

    if normalized_tool_name in _BLOCKED_NATIVE_INBOX_TOOLS:
        return _deny(
            "Blocked by platform policy: flat team messaging tools are disabled in Telegram runtime. "
            "Use SendInboxMessage and ReadInbox instead.",
            additional_context=(
                "System: Flat team messaging tools are disabled by platform policy in Telegram runtime. "
                "Use SendInboxMessage and ReadInbox."
            ),
            show_system_message=True,
        )

    if normalized_tool_name in _BLOCKED_NATIVE_MODE_TOOLS:
        return _deny(
            "Blocked by platform policy: EnterPlanMode is disabled in Telegram runtime.",
            additional_context=(
                "System: EnterPlanMode is not available in Telegram runtime. "
                "Continue in normal execution mode."
            ),
            show_system_message=True,
        )

    # Only guard write-mutating tools
    if normalized_tool_name not in _WRITE_TOOLS:
        return None

    file_path_str = tool_input.get("file_path", "")
    if not file_path_str:
        return None

    file_path = Path(file_path_str)

    # Check immutable patterns from config
    if config.is_immutable(file_path):
        return _deny(f"Blocked: {file_path} matches an immutable pattern. These files must not be edited.")

    return None


async def on_stop(
    *,
    config: OBSConfig,
    fork_runner: ForkRunner,
) -> None:
    """Stop hook: trigger memory extraction fork."""
    await fork_runner.extract_memory()


COMPACT_POLICY_ENV = "OBS_COMPACT_POLICY"
COMPACT_POLICY_HANDOFF = "handoff"

DEFAULT_COMPACTION_HANDOFF_PROMPT = (
    "COMPACTION STOPPED — CONTEXT BUDGET REACHED. Your context reached the automatic "
    "compaction point. Compaction was intercepted before any summary was written, so "
    "everything you have seen is still loaded, and auto-compaction is now disabled for "
    "this session. Do NOT continue the task. Your job for the rest of this session is to "
    "preserve what this context holds.\n"
    "Write handback.md in your own artifact directory "
    "(/workspace/runtime/git/obs-artifacts/Drafts/Artifacts/{root_team_key}/{agent_name}/ — "
    "take both values from session_lineage). Include the task VERBATIM; what you did, how "
    "and why; everything done, each with an evidence pointer; what is unverified; what is "
    "not done and why; blockers; wrong assumptions and corrections; what the next attempt "
    "must do differently; next steps; lessons; and related-reports, meaning every report, "
    "handback, plan or artifact you read or built on and what you used it for. Write it "
    "VERBOSELY: it is for other agents, and length is fine. State uncertainty explicitly, "
    "separating what you verified yourself from what you infer or took from another "
    "agent's claim. Source-cite every claim (file:line, command and output location, "
    "commit, artifact path, agent name and session id).\n"
    "Then commit it, send your caller the path, and end your turn."
)


def effective_compact_policy(explicit_env: dict | None) -> str:
    """Return the session's compaction policy.

    ``handoff`` activates only when the session's explicit env sets
    ``OBS_COMPACT_POLICY=handoff``. Without an explicit non-empty value, every
    model — local included — uses native (lossy auto) compaction (Daniel,
    2026-09-30; reverses the 2026-09-26 local-model default of fc45661).
    """
    explicit = (explicit_env or {}).get(COMPACT_POLICY_ENV)
    if explicit is not None and str(explicit).strip():
        return str(explicit).strip().lower()
    return ""


def _compact_policy(state: "HookState") -> str:
    return effective_compact_policy(state.sdk_env_overrides)


def _user_result_prompt(result: dict | None) -> str | None:
    """Extract a handoff prompt from a user PreCompact hook result."""
    if not isinstance(result, dict):
        return None
    hso = result.get("hookSpecificOutput")
    if isinstance(hso, dict):
        text = hso.get("additionalContext")
        if isinstance(text, str) and text.strip():
            return text.strip()
    text = result.get("systemMessage")
    if isinstance(text, str) and text.strip():
        return text.strip()
    return None


def _make_pre_compact_callback(
    state: "HookState",
    user_check: "CheckFn | None",
) -> Callable[[HookInput, str | None, HookContext], Awaitable[SyncHookJSONOutput]]:
    """Build the PreCompact callback (opt-in handoff policy).

    Pinned Claude Code 2.1.59 ignores a PreCompact "block", so the only way to
    stop an automatic compaction is to interrupt the CLI before it sends the
    summary request (E3 harness, 5/5 trials: no compact_boundary written).
    With the handoff policy in effect (explicit ``OBS_COMPACT_POLICY=handoff``
    in the session's env; see ``effective_compact_policy``) and an ``auto``
    trigger, this callback:

    1. runs the session's user PreCompact hook (if any) first; its
       ``additionalContext`` (or ``systemMessage``) becomes the handoff prompt,
       so the vault stays the single source of the prompt text;
    2. records the interception on HookState;
    3. awaits ``client.interrupt()`` inside the callback (awaiting removes the
       race with the summary request; the SDK serves control requests
       concurrently, so this does not deadlock);
    4. returns ``{}``.

    ConversationRunner then ends that CLI process and resumes the same session
    id with auto-compaction disabled and the handoff prompt. Manual ``/compact``
    and sessions without the policy keep native behaviour; the user hook's
    result is passed through unchanged for them.
    """

    async def _callback(
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput:
        user_result: dict | None = None
        if user_check is not None:
            user_result = await user_check(hook_input, tool_use_id, context)

        trigger = str(hook_input.get("trigger") or "").strip().lower()
        if _compact_policy(state) != COMPACT_POLICY_HANDOFF or trigger == "manual":
            return user_result or {}
        if state.compaction_intercepted:
            return {}

        state.compaction_intercepted = True
        state.compaction_handoff_prompt = _user_result_prompt(user_result)
        state.compaction_intercept_info = {
            "session_id": hook_input.get("session_id"),
            "trigger": trigger or None,
            "transcript_path": hook_input.get("transcript_path"),
        }
        interrupter = state.client_interrupter
        if interrupter is None:
            _log.error(
                "PreCompact handoff policy fired without a client interrupter; "
                "native compaction will proceed session_id=%s",
                hook_input.get("session_id"),
            )
            state.compaction_intercepted = False
            return {}
        try:
            await interrupter()
        except Exception:
            _log.error(
                "PreCompact handoff interrupt failed; native compaction may proceed "
                "session_id=%s",
                hook_input.get("session_id"),
                exc_info=True,
            )
            state.compaction_intercepted = False
            return {}
        _log.warning(
            "PreCompact handoff: interrupted automatic compaction session_id=%s",
            hook_input.get("session_id"),
        )
        return {}

    return _callback


# ---------------------------------------------------------------------------
# Hook Pipeline: extensible middleware for SDK hook callbacks
# ---------------------------------------------------------------------------

# Type alias for individual check functions within a pipeline.
# A check receives the same args as HookCallback and returns
# SyncHookJSONOutput | None (None means "no opinion, continue").
CheckFn = Callable[
    [HookInput, str | None, HookContext],
    Awaitable[SyncHookJSONOutput | None],
]


@dataclass
class HookState:
    """Shared mutable state between daemon endpoints and hook callbacks.

    Daemon endpoints write (enqueue messages, set interrupt flag).
    Hook callbacks read (drain queue, check/clear interrupt flag).
    status_queue is drained by the daemon's event_generator to yield SSE status events.
    """

    message_queue: asyncio.Queue[QueuedMessage | str] = field(default_factory=asyncio.Queue)
    status_queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    interrupt_flag: bool = False
    interrupt_requested: bool = False
    # Wall time of a /stop, /stop_* or AgentTaskStop for the running turn. While
    # set, a CLI exit ends the turn instead of reconnecting (vault-u3b.65).
    stop_requested_at: float | None = None
    # Wall time of an AgentTaskStop / task-scoped stop that outlives the turn
    # (obs-2). While set, queued work is not auto-delivered, the route is left
    # out of restart snapshots, and a turn that starts anyway keeps
    # stop_requested_at armed. Explicit new input (a user message, an inbox
    # wake, AgentTask resume, a schedule) clears it.
    stop_latched_at: float | None = None
    # Teammate notices that arrived while a stopped turn was winding down. They
    # are new input, so they survive the stop's leftover-batch discard and are
    # handed back to the route when the turn ends (obs-2).
    post_stop_messages: list = field(default_factory=list)
    interrupt_notice_pending: bool = False
    pause_queue_delivery: bool = False
    session_id: str | None = None
    background_tasks: set[asyncio.Task] = field(default_factory=set)
    last_result_data: dict | None = None  # last ResultMessage metrics
    fork_task_launcher: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    fork_task_outputter: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    fork_task_stopper: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    cron_creator: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    cron_lister: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    cron_deleter: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    inbox_recipient_validator: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None
    inbox_message_notifier: Callable[[dict[str, Any]], Awaitable[dict[str, Any] | None]] | None = None
    stop_event_notifier: Callable[[dict[str, Any]], Awaitable[None]] | None = None
    context_snapshot_provider: Callable[..., dict[str, Any] | None] | None = None
    team_status_provider: Callable[..., dict[Any, dict[str, Any]]] | None = None
    sdk_env_overrides: dict[str, str] = field(default_factory=dict)
    vault_path: Path | None = None
    effective_model: str | None = None
    current_tool_use_id: str | None = None
    schedule_run_active: bool = False
    execution_active: bool = False
    triggered_schedule_id: str | None = None
    active_schedule: dict[str, Any] | None = None
    pending_obs_bootstrap_xml: str | None = None  # set by telegram.py when bootstrap is primed
    # PreCompact handoff policy (OBS_COMPACT_POLICY=handoff). SessionManager
    # sets client_interrupter to the live client's interrupt(); the PreCompact
    # callback sets compaction_intercepted; ConversationRunner consumes it.
    client_interrupter: Callable[[], Awaitable[None]] | None = None
    compaction_intercepted: bool = False
    compaction_handoff_prompt: str | None = None
    compaction_intercept_info: dict[str, Any] | None = None

    def reset(self) -> None:
        """Clear all queued state for a fresh session.

        Called by /new to prevent cross-scenario contamination from
        stale background fork results or queued messages.
        """
        # Drain message queue
        while not self.message_queue.empty():
            try:
                self.message_queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        # Drain status queue
        while not self.status_queue.empty():
            try:
                self.status_queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        # Cancel running background tasks
        for task in self.background_tasks:
            if not task.done():
                task.cancel()
        self.background_tasks.clear()
        self.interrupt_flag = False
        self.interrupt_requested = False
        self.stop_requested_at = None
        self.stop_latched_at = None
        self.post_stop_messages = []
        self.interrupt_notice_pending = False
        self.pause_queue_delivery = False
        self.session_id = None
        self.last_result_data = None
        self.sdk_env_overrides = {}
        self.vault_path = None
        self.effective_model = None
        self.current_tool_use_id = None
        self.schedule_run_active = False
        self.execution_active = False
        self.triggered_schedule_id = None
        self.active_schedule = None
        self.compaction_intercepted = False
        self.compaction_handoff_prompt = None
        self.compaction_intercept_info = None


class HookPipeline:
    """Chains multiple check functions into a single SDK HookCallback.

    Runs checks sequentially. Short-circuits on:
    - continue_: False (interrupt)
    - permissionDecision: "deny"

    Accumulates additionalContext from all checks that run.
    """

    def __init__(self, checks: list[CheckFn]) -> None:
        self._checks = list(checks)

    async def __call__(
        self,
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput:
        """Run all checks, merging results."""
        merged: SyncHookJSONOutput = {}
        accumulated_context: list[str] = []
        event_name = hook_input.get("hook_event_name")

        for check in self._checks:
            result = await check(hook_input, tool_use_id, context)
            if result is None:
                continue

            # Extract additionalContext from hookSpecificOutput
            hso = result.get("hookSpecificOutput")
            if hso and "additionalContext" in hso:
                accumulated_context.append(hso["additionalContext"])

            # Check for short-circuit: continue_ is False
            if result.get("continue_") is False:
                # Merge accumulated context before returning
                if accumulated_context:
                    merged.setdefault("hookSpecificOutput", {})
                    merged["hookSpecificOutput"]["hookEventName"] = event_name
                    merged["hookSpecificOutput"]["additionalContext"] = "\n\n".join(accumulated_context)
                merged["continue_"] = False
                if "stopReason" in result:
                    merged["stopReason"] = result["stopReason"]
                return merged

            # Check for short-circuit: permissionDecision is "deny"
            if hso and hso.get("permissionDecision") == "deny":
                for key in (
                    "continue_",
                    "suppressOutput",
                    "stopReason",
                    "decision",
                    "systemMessage",
                    "reason",
                ):
                    if key in result:
                        merged[key] = result[key]
                merged_hso: dict[str, Any] = {
                    "hookEventName": event_name,
                    "permissionDecision": "deny",
                }
                if "permissionDecisionReason" in hso:
                    merged_hso["permissionDecisionReason"] = hso["permissionDecisionReason"]
                if "updatedInput" in hso:
                    merged_hso["updatedInput"] = hso["updatedInput"]
                if accumulated_context:
                    merged_hso["additionalContext"] = "\n\n".join(accumulated_context)
                merged["hookSpecificOutput"] = merged_hso
                return merged

            # Check for short-circuit: a Stop hook blocks ending the turn.
            # Claude Code 2.1.59 honours {"decision": "block", "reason": ...}
            # on Stop (continues the turn with the reason, then re-fires Stop
            # with stop_hook_active=true). Without this pass-through the block
            # was silently dropped. Scoped to Stop only.
            if event_name == "Stop" and result.get("decision") == "block":
                merged["decision"] = "block"
                if "reason" in result:
                    merged["reason"] = result["reason"]
                if accumulated_context:
                    merged["hookSpecificOutput"] = {
                        "hookEventName": event_name,
                        "additionalContext": "\n\n".join(accumulated_context),
                    }
                return merged

        # No short-circuit — return accumulated context if any
        if accumulated_context:
            merged.setdefault("hookSpecificOutput", {})
            merged["hookSpecificOutput"]["hookEventName"] = event_name
            merged["hookSpecificOutput"]["additionalContext"] = "\n\n".join(accumulated_context)

        return merged


# ---------------------------------------------------------------------------
# Check factory functions
# ---------------------------------------------------------------------------


def _make_interrupt_check(state: HookState) -> CheckFn:
    """Create a check that halts the current turn if interrupt_flag is set."""

    async def _check(
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput | None:
        if state.interrupt_flag:
            state.interrupt_flag = False
            state.interrupt_notice_pending = True
            return {
                "continue_": False,
                "stopReason": "Turn interrupted",
            }
        return None

    return _check


def _make_immutable_check(config: OBSConfig) -> CheckFn:
    """Create a check that wraps on_pre_tool_use() into SDK callback format.

    Handles native-tool denylists and immutable-write guards.
    Only meaningful for PreToolUse events — returns None for other events.
    """

    async def _check(
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput | None:
        # Only act on PreToolUse events
        if hook_input.get("hook_event_name") != "PreToolUse":
            return None

        tool_name = hook_input.get("tool_name", "")
        tool_input = hook_input.get("tool_input", {})

        result = on_pre_tool_use(tool_name, tool_input, config=config)
        if result is None:
            return None

        return result

    return _check


def _make_tool_state_check(state: HookState) -> CheckFn:
    """Track tool/session state without consuming queued user messages."""

    async def _check(
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput | None:
        event_name = hook_input.get("hook_event_name")
        if event_name == "PreToolUse":
            state.current_tool_use_id = tool_use_id
            session_id = hook_input.get("session_id")
            if isinstance(session_id, str) and session_id.strip():
                state.session_id = session_id.strip()
        elif event_name == "PostToolUse" and state.current_tool_use_id == tool_use_id:
            state.current_tool_use_id = None
        return None

    return _check


def _make_notification_check(state: HookState) -> CheckFn:
    """Create a check that surfaces notification/lifecycle hook events.

    We mirror native hook events into status_queue so transport adapters (e.g.
    Telegram) can show user-visible activity for teammate/task lifecycle.
    """

    async def _check(
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput | None:
        _ = tool_use_id, context
        event_name = hook_input.get("hook_event_name")
        if event_name not in {"Notification", "SubagentStart", "SubagentStop"}:
            return None

        from obs_agent.events import StatusEvent

        if event_name == "Notification":
            notification_type = str(hook_input.get("notification_type") or "notification").strip()
            title = str(hook_input.get("title") or "").strip()
            message = str(hook_input.get("message") or "").strip()
            lines: list[str] = []
            if title:
                lines.append(f"title: {title}")
            if message:
                lines.append(message)
            state.status_queue.put_nowait(
                StatusEvent(
                    type="notification",
                    summary=f"notification: {notification_type}",
                    messages=lines or None,
                )
            )
            return None

        agent_id = str(hook_input.get("agent_id") or "").strip()
        agent_type = str(hook_input.get("agent_type") or "").strip()
        lines = []
        if agent_id:
            lines.append(f"agent_id: {agent_id}")
        if agent_type:
            lines.append(f"agent_type: {agent_type}")
        if event_name == "SubagentStop":
            transcript = str(hook_input.get("agent_transcript_path") or "").strip()
            if transcript:
                lines.append(f"transcript: {transcript}")
        state.status_queue.put_nowait(
            StatusEvent(
                type="notification",
                summary=f"notification: {event_name}",
                messages=lines or None,
            )
        )
        return None

    return _check


def _make_stop_check(state: HookState) -> CheckFn:
    """Create a check that emits route-local stop notifications."""

    async def _check(
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput | None:
        _ = tool_use_id, context
        if hook_input.get("hook_event_name") != "Stop":
            return None
        session_id = hook_input.get("session_id")
        normalized_session_id = (
            session_id.strip() if isinstance(session_id, str) and session_id.strip() else None
        )
        if normalized_session_id is not None:
            state.session_id = normalized_session_id
        notifier = state.stop_event_notifier
        if notifier is None:
            return None
        payload = {
            "session_id": normalized_session_id,
            "hook_input": dict(hook_input),
            "schedule_run_active": bool(state.schedule_run_active),
            "execution_active": bool(state.execution_active),
            "current_tool_use_id": state.current_tool_use_id,
            "triggered_schedule_id": state.triggered_schedule_id,
            "active_schedule": (
                dict(state.active_schedule) if isinstance(state.active_schedule, dict) else None
            ),
        }
        await notifier(payload)
        return None

    return _check


# ---------------------------------------------------------------------------
# Dynamic user hook loading
# ---------------------------------------------------------------------------

_log = logging.getLogger(__name__)


# Explicit inventory, not an arbitrary **/hooks glob: uploads must never become
# daemon code just by being put in a directory named "hooks".
_TRUSTED_HOOK_DIRS = (
    "Projects/Personal Projects/Agentic/Agentic Fractals/hooks",
    "Projects/Personal Projects/Agentic/Agentic Fractals/procedures/hooks",
)
_TRUSTED_HOOK_FUNCTIONS = {
    **{f"{_TRUSTED_HOOK_DIRS[0]}/{name}.py": frozenset({"check"}) for name in (
        "assembler_eval_guard", "assembler_guard", "executor_guard", "holder_guard",
        "level_context_guard", "new_chat_guard", "reporter_spawn_guard", "router_guard",
        "service_writer_guard", "session_scope_guard_v1", "session_scope_guard_v2",
        "supervisor_guard", "verifier_guard", "watchdog_check_guard", "watchdog_check_guard_v2",
    )},
    **{f"{_TRUSTED_HOOK_DIRS[1]}/{name}_guard.py": frozenset({"check"})
       for name in ("assembler", "router", "verifier")},
    f"{_TRUSTED_HOOK_DIRS[0]}/feedback_stop_hook.py": frozenset({"spawn_feedback"}),
    f"{_TRUSTED_HOOK_DIRS[0]}/reporter_stop_hook.py": frozenset({"spawn_reporter"}),
    f"{_TRUSTED_HOOK_DIRS[0]}/service_stop_hook.py": frozenset({"spawn_services"}),
    f"{_TRUSTED_HOOK_DIRS[0]}/level_composite.py": frozenset({
        "worker_pre", "checkin_pre", "verifier_pre", "assembler_pre", "holder_pre", "stop",
        "worker_precompact", "holder_precompact", "assembler_precompact", "verifier_precompact",
        "checkin_precompact",
    }),
    "Projects/Personal Projects/Agentic/Agent Operations/scripts/ops/ops_admin_guard.py":
        frozenset({"check", "recovery_check"}),
    "Projects/Personal Projects/Agentic/Agent Operations/scripts/ops/rounds.py":
        frozenset({"recovery_handoff"}),
    # Registry high availability (ops-114): standby roots launch with this guard
    # (procedures/registry/high-availability.md, scripts/ops/registry_ha.py). It
    # postdates the 13:00Z inventory; the obs-54 V1 hook census found it.
    "Projects/Personal Projects/Agentic/Agent Operations/scripts/ops/registry_ha_guard.py":
        frozenset({"check"}),
    "Projects/Personal Projects/Personal Intelligence/scripts/pi_runner_guard.py": frozenset({"check"}),
}
_TRUSTED_HOOK_FILES = frozenset(_TRUSTED_HOOK_FUNCTIONS)


class HookValidationError(ValueError):
    """A hook is not trusted daemon code; do not start an unguarded session."""


def _trusted_hook_source(file_path: str, vault_path: Path, function_name: str) -> tuple[Path, bytes]:
    try:
        root = vault_path.resolve(strict=True)
        path = Path(file_path).expanduser()
        if not path.is_absolute():
            path = root / path
        path = path.resolve(strict=True)
        if not path.is_relative_to(root):
            raise HookValidationError("path resolves outside the configured vault")
        relative = path.relative_to(root)
        if not (
            relative.as_posix() in _TRUSTED_HOOK_FILES
            or any(relative.is_relative_to(directory) for directory in _TRUSTED_HOOK_DIRS)
        ):
            raise HookValidationError("path is not in a trusted hook directory or guard inventory")
        if path.suffix != ".py":
            raise HookValidationError("Hook file must be a .py file")
        if not path.is_file():
            raise HookValidationError("hook path is not a regular file")
        if function_name not in _TRUSTED_HOOK_FUNCTIONS.get(relative.as_posix(), ()):
            raise HookValidationError("path/function pair is not a trusted hook capability")

        def git(*args: str) -> bytes:
            return subprocess.run(
                ["git", "--no-optional-locks", "--literal-pathspecs", "-C", str(root), *args],
                check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5,
            ).stdout

        if Path(git("rev-parse", "--show-toplevel").decode().strip()).resolve() != root:
            raise HookValidationError("configured vault must be the Git repository root")
        entry = git("ls-tree", "-z", "HEAD", "--", relative.as_posix())
        metadata = entry.split(b"\t", 1)[0].split()
        if len(metadata) != 3 or metadata[0] not in {b"100644", b"100755"} or metadata[1] != b"blob":
            raise HookValidationError("hook must be a regular file tracked in Git HEAD")
        committed = git("cat-file", "blob", metadata[2].decode("ascii"))
        with path.open("rb") as handle:
            source = handle.read(len(committed) + 1)
        if source != committed:
            raise HookValidationError("hook has uncommitted modifications; commit reviewed hook code first")
        return path, source
    except (OSError, RuntimeError, ValueError, subprocess.SubprocessError) as exc:
        reason = str(exc) if isinstance(exc, HookValidationError) else "hook path or Git verification failed"
        _log.warning("Rejected user hook path=%r reason=%s", file_path, reason)
        raise HookValidationError(f"Rejected user hook {file_path!r}: {reason}") from exc


def validate_hook_spec(spec: str, vault_path: Path) -> str:
    """Validate without importing, before AgentTask creates a child topic."""
    if not isinstance(spec, str) or "::" not in spec:
        _log.warning("Rejected user hook spec=%r: expected file_path::function_name", spec)
        raise HookValidationError("Hook spec must be 'file_path::function_name'")
    file_path, function_name = spec.rsplit("::", 1)
    if not file_path or not function_name.isidentifier():
        _log.warning("Rejected user hook spec=%r: invalid path or function name", spec)
        raise HookValidationError("Hook spec requires a path and a Python function name")
    path, _ = _trusted_hook_source(file_path, vault_path, function_name)
    return f"{path}::{function_name}"


def load_hook_function(file_path: str, function_name: str, *, vault_path: Path) -> Callable:
    """Load only unchanged Git-tracked code in the vault hook allowlist."""
    path, source = _trusted_hook_source(file_path, vault_path, function_name)

    module_name = f"_obs_user_hook_{path.stem}_{id(path)}"
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec from: {path}")

    module = importlib.util.module_from_spec(spec)
    try:
        # Execute the bytes we verified, never an unchecked .pyc or a second
        # source read that could race with a replacement after validation.
        exec(compile(source, str(path), "exec", dont_inherit=True), module.__dict__)
    except SyntaxError as exc:
        raise SyntaxError(f"Syntax error in hook file {path}: {exc}") from exc
    except Exception as exc:
        raise ImportError(f"Error loading hook file {path}: {exc}") from exc

    func = getattr(module, function_name, None)
    if func is None:
        available = [
            n for n in dir(module)
            if callable(getattr(module, n, None)) and not n.startswith("_")
        ]
        raise AttributeError(
            f"Function '{function_name}' not found in {path}. "
            f"Available: {available}"
        )

    if not callable(func):
        raise TypeError(f"'{function_name}' in {path} is not callable")

    # Lenient signature validation: at least 2 params (hook_input, tool_use_id)
    try:
        sig = inspect.signature(func)
        params = [
            p for p in sig.parameters.values()
            if p.kind in (
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            )
        ]
        if len(params) < 2:
            # Check for **kwargs which would accept anything
            has_var_keyword = any(
                p.kind == inspect.Parameter.VAR_KEYWORD
                for p in sig.parameters.values()
            )
            if not has_var_keyword:
                _log.warning(
                    "Hook function '%s' has %d positional params, expected ≥2 "
                    "(hook_input, tool_use_id). Signature: %s",
                    function_name, len(params), sig,
                )
    except (ValueError, TypeError):
        pass  # Can't introspect — proceed anyway

    return func


# Mapping from user-facing name → HookState attribute.
# Keep this list intentionally small: user hooks receive only vetted callables
# and safe snapshot data, not a generic public tool registry.
_OBS_CONTEXT_FIELDS: dict[str, str] = {
    # Agent lifecycle
    "launch_agent": "fork_task_launcher",
    "agent_output": "fork_task_outputter",
    "agent_stop": "fork_task_stopper",
    # Scheduling
    "cron_creator": "cron_creator",
    "cron_lister": "cron_lister",
    "cron_deleter": "cron_deleter",
    # Messaging
    "inbox_message_notifier": "inbox_message_notifier",
    "inbox_recipient_validator": "inbox_recipient_validator",
    # Session
    "session_id": "session_id",
}

_SAFE_SNAPSHOT_KEYS = {
    "route",
    "team",
    "session",
    "topic",
    "effective_model",
}


def _safe_snapshot_dict(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    snapshot = {
        key: value[key]
        for key in _SAFE_SNAPSHOT_KEYS
        if key in value
    }
    return snapshot or None


def _build_obs_context(
    state: "HookState",
    hook_input: HookInput | None = None,
    tool_use_id: str | None = None,
) -> dict[str, Any]:
    """Build context["obs"] with vetted callables and safe runtime snapshots."""
    obs_context = {key: getattr(state, attr, None) for key, attr in _OBS_CONTEXT_FIELDS.items()}
    session_id = obs_context.get("session_id")
    if not session_id and hook_input is not None:
        input_session_id = hook_input.get("session_id")
        if isinstance(input_session_id, str) and input_session_id.strip():
            session_id = input_session_id.strip()
            obs_context["session_id"] = session_id

    current_tool_use_id = state.current_tool_use_id
    if (
        hook_input is not None
        and hook_input.get("hook_event_name") in {"PreToolUse", "PostToolUse"}
        and tool_use_id
    ):
        current_tool_use_id = tool_use_id

    obs_context["runtime"] = {
        "schedule_run_active": bool(state.schedule_run_active),
        "execution_active": bool(state.execution_active),
        "current_tool_use_id": current_tool_use_id,
    }
    obs_context["schedule"] = {
        "triggered_schedule_id": state.triggered_schedule_id,
        "active_schedule": dict(state.active_schedule) if isinstance(state.active_schedule, dict) else None,
    }
    obs_context["triggered_schedule_id"] = state.triggered_schedule_id
    obs_context["active_schedule"] = (
        dict(state.active_schedule) if isinstance(state.active_schedule, dict) else None
    )
    obs_context["effective_model"] = state.effective_model
    obs_context["sdk_env_overrides"] = dict(state.sdk_env_overrides)

    snapshot_provider = state.context_snapshot_provider
    snapshot = None
    if snapshot_provider is not None:
        try:
            snapshot = snapshot_provider(
                session_id=session_id,
                hook_input=hook_input,
                tool_use_id=tool_use_id,
            )
        except TypeError:
            snapshot = snapshot_provider()
        snapshot = _safe_snapshot_dict(snapshot)
    obs_context["snapshot"] = snapshot
    if snapshot:
        for key, value in snapshot.items():
            obs_context.setdefault(key, value)
        if obs_context.get("effective_model") is None:
            obs_context["effective_model"] = snapshot.get("effective_model")
    if obs_context.get("effective_model") is None:
        obs_context["effective_model"] = state.effective_model

    bootstrap = resolve_obs_bootstrap(
        pending_xml=state.pending_obs_bootstrap_xml,
        session_id=session_id,
        cwd=state.vault_path,
    )
    obs_context["bootstrap"] = (
        obs_bootstrap_to_dict(bootstrap, session_id=session_id, include_xml=True)
        if bootstrap is not None
        else None
    )
    return obs_context


def _make_user_hook_check(user_fn: Callable, state: "HookState") -> "CheckFn":
    """Wrap a user-provided hook function into a CheckFn for HookPipeline.

    The wrapper:
    - Enriches context with ``context["obs"]`` containing agent launch
      capabilities from HookState
    - Handles both sync and async user functions
    - Catches ALL exceptions and returns None (never crashes the session)
    - Validates return type loosely (dict or None accepted)
    """

    async def _user_check(
        hook_input: HookInput,
        tool_use_id: str | None,
        context: HookContext,
    ) -> SyncHookJSONOutput | None:
        try:
            # Enrich context with OBS capabilities
            enriched_context: dict[str, Any] = dict(context) if context else {}
            enriched_context["obs"] = _build_obs_context(state, hook_input, tool_use_id)

            result = user_fn(hook_input, tool_use_id, enriched_context)
            if inspect.isawaitable(result):
                result = await result

            # Validate return type loosely
            if result is None:
                return None
            if isinstance(result, dict):
                return result

            _log.warning(
                "User hook '%s' returned %s (expected dict or None), treating as None",
                getattr(user_fn, "__name__", "<unknown>"),
                type(result).__name__,
            )
            return None

        except Exception:
            _log.warning(
                "User hook '%s' raised an exception (swallowed for stability)",
                getattr(user_fn, "__name__", "<unknown>"),
                exc_info=True,
            )
            return None

    return _user_check


# ---------------------------------------------------------------------------
# Factory: build hook matchers for ClaudeAgentOptions
# ---------------------------------------------------------------------------


def create_hook_matchers(
    config: OBSConfig,
    state: HookState,
    *,
    user_hooks: dict[str, str] | None = None,
) -> dict[str, list[HookMatcher]]:
    """Build hook matcher dict ready for ClaudeAgentOptions(hooks=...).

    PreToolUse pipeline: interrupt -> native/immutable guard -> tool state -> [user hook]
    PostToolUse pipeline: tool state -> [user hook]
    Stop pipeline: stop notification -> [user hook]; a user ``decision: block`` is passed through
    PreCompact: [user hook] -> opt-in handoff interception (``OBS_COMPACT_POLICY=handoff``)

    WARNING: never drain message_queue into hook additionalContext. Native
    hook context is not persisted in JSONL and the cache proxy MUST strip it
    for fork/resume prefix fidelity. ConversationRunner owns queued delivery
    through normal persisted queries at turn boundaries instead.

    If *user_hooks* is provided (mapping of event name to
    ``"file_path::function_name"``), the user-supplied check is appended
    **after** OBS built-in guards so it cannot bypass them. Hook validation and
    loading failures are logged and prevent session startup (fail closed).
    """
    interrupt_check = _make_interrupt_check(state)
    immutable_check = _make_immutable_check(config)
    tool_state_check = _make_tool_state_check(state)
    notification_check = _make_notification_check(state)
    stop_check = _make_stop_check(state)

    # Validate the entire mapping before importing any hook, including restored
    # and inherited hooks that did not come through the AgentTask tool handler.
    validated = {
        event: validate_hook_spec(spec, config.vault_path)
        for event, spec in (user_hooks or {}).items()
    }
    _resolved_user_checks: dict[str, CheckFn] = {}
    for event_name, spec in validated.items():
        try:
            fpath, fname = spec.rsplit("::", 1)
            fn = load_hook_function(fpath, fname, vault_path=config.vault_path)
            _resolved_user_checks[event_name] = _make_user_hook_check(fn, state)
        except Exception:
            _log.error("Failed to load user hook event=%r spec=%r; refusing session startup",
                       event_name, spec, exc_info=True)
            raise

    def _pipeline(builtin: list[CheckFn], event: str) -> HookPipeline:
        checks = list(builtin)
        if event in _resolved_user_checks:
            checks.append(_resolved_user_checks[event])
        return HookPipeline(checks)

    pre_tool_pipeline = _pipeline([interrupt_check, immutable_check, tool_state_check], "PreToolUse")
    post_tool_pipeline = _pipeline([tool_state_check], "PostToolUse")
    notification_pipeline = _pipeline([notification_check], "Notification")
    stop_pipeline = _pipeline([stop_check], "Stop")
    pre_compact_callback = _make_pre_compact_callback(
        state, _resolved_user_checks.get("PreCompact")
    )

    return {
        "PreCompact": [
            HookMatcher(matcher=None, hooks=[pre_compact_callback]),
        ],
        "PreToolUse": [
            HookMatcher(matcher=None, hooks=[pre_tool_pipeline]),
        ],
        "PostToolUse": [
            HookMatcher(matcher=None, hooks=[post_tool_pipeline]),
        ],
        "Notification": [
            HookMatcher(matcher=None, hooks=[notification_pipeline]),
        ],
        "SubagentStart": [
            HookMatcher(matcher=None, hooks=[_pipeline([notification_check], "SubagentStart")]),
        ],
        "SubagentStop": [
            HookMatcher(matcher=None, hooks=[_pipeline([notification_check], "SubagentStop")]),
        ],
        "Stop": [
            HookMatcher(matcher=None, hooks=[stop_pipeline]),
        ],
    }
