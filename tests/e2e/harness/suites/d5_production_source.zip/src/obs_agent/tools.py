"""MCP tools for OBS Agent.

Provides in-process MCP tools that the Claude Agent SDK exposes to the model.
Current task orchestration primitives: ``AgentTask`` (with ``fork`` mode),
``AgentTaskOutput``, and ``AgentTaskStop``.

See decisions D018 (forking as core primitive).
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import math
import os
import re
import secrets
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable
import xml.etree.ElementTree as ET

from claude_agent_sdk import tool, create_sdk_mcp_server

from obs_agent.append_scan import AppendScanCache
from obs_agent.context_probe import probe_context_via_claude_cli
from obs_agent.context_jsonl import find_session_jsonl_index
from obs_agent import start_step as _start_step
from obs_agent.context_stats import (
    apply_context_probe,
    build_context_snapshot,
    format_context_snapshot_lines,
)
from obs_agent.config import parse_context_suffix
from obs_agent.lineage import (
    find_latest_obs_bootstrap_for_session,
    agent_name_for_lineage,
    lineage_fingerprint,
    normalize_lineage_name,
    obs_bootstrap_to_dict,
    parse_obs_bootstrap_xml,
    slugify_projection_label,
)

if TYPE_CHECKING:
    from obs_agent.config import OBSConfig
    from obs_agent.hooks import HookState

logger = logging.getLogger("obs_agent.tools")
_INBOX_FILE_LOCKS: dict[Path, asyncio.Lock] = {}
_SAFE_TEAM_IDENTITY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-[a-z0-9][a-z0-9_-]{0,127}$")
_SAFE_AGENT_IDENTITY_RE = re.compile(
    r"^(?:\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-[a-z0-9][a-z0-9_-]{0,127}|[0-9a-f]{10}-[a-z0-9][a-z0-9-]{0,117})$"
)


_EXTERNAL_SENDER_PREFIX = "external:"
_EXTERNAL_NAME_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def _external_outbox_path(name: str) -> Path:
    from obs_agent.control import control_dir

    safe = _EXTERNAL_NAME_UNSAFE.sub("-", name).strip(".-") or "unnamed"
    return control_dir() / "external-replies" / f"{safe}.jsonl"


def _deliver_external_reply(
    *, name: str, team_name: str, sender: str, content: str, summary: str | None
) -> dict:
    """Append an agent's reply to an ``external:NAME`` sender's outbox (obs-12)."""
    path = _external_outbox_path(name)
    row = {
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "team_name": team_name,
        "from": sender,
        "to": f"{_EXTERNAL_SENDER_PREFIX}{name}",
        "summary": summary or "",
        "text": content,
    }
    try:
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=True) + "\n")
    except OSError as exc:
        logger.warning("external reply outbox write failed path=%s", path, exc_info=True)
        reason = f"external reply could not be stored: {exc}"
        return {
            "content": [{"type": "text", "text": f"message underdelivered: {reason}"}],
            "tool_use_result": {
                "success": False,
                "delivered": False,
                "outcome": "underdelivered",
                "reason": reason,
                "recipient": row["to"],
                "team_name": team_name,
            },
            "is_error": True,
        }
    logger.info("[external_reply] stored team=%s from=%s to=%s path=%s", team_name, sender, row["to"], path)
    response = {
        "success": True,
        "delivered": True,
        "outcome": "external_reply",
        "team_name": team_name,
        "recipient": row["to"],
        "note": "external senders are scripts; the reply is stored in their outbox, no agent is woken",
    }
    return {
        "content": [{"type": "text", "text": json.dumps(response, ensure_ascii=True)}],
        "tool_use_result": response,
    }


def _error_result(text: str) -> dict:
    return {"content": [{"type": "text", "text": text}], "is_error": True}


def _resolve_hook_spec_path(spec: str, vault_path: Path) -> str:
    from obs_agent.hooks import validate_hook_spec

    return validate_hook_spec(spec, vault_path)


def validate_must_reply_recipient(
    *, sender: str, recipient: str, must_reply: bool
) -> dict[str, Any]:
    """Check whether a must_reply message is valid.

    Returns ``{"ok": True}`` on success or ``{"ok": False, "error": "..."}``
    when the message should be rejected (e.g. must_reply to self).
    """
    if not must_reply:
        return {"ok": True}
    if sender == recipient:
        return {"ok": False, "error": "must_reply to self is blocked (would cause infinite wake loop)"}
    return {"ok": True}


def detect_must_reply_completions(
    inbox_entries: list[dict],
    recipient_of_outgoing_message: str,
) -> tuple[list[dict], bool]:
    """Mark must_reply messages from *recipient_of_outgoing_message* as replied.

    When agent B sends a message to agent A, B calls this on B's own inbox
    entries to mark must_reply messages from A as ``replied: True``.

    Returns ``(updated_entries, all_replied)`` where *all_replied* indicates
    whether every must_reply message in *inbox_entries* is now replied.
    """
    changed = False
    for entry in inbox_entries:
        if (
            isinstance(entry, dict)
            and entry.get("must_reply") is True
            and entry.get("replied") is not True
            and entry.get("from") == recipient_of_outgoing_message
        ):
            entry["replied"] = True
            changed = True
    # Check if ALL must_reply obligations are now cleared
    all_replied = not any(
        isinstance(e, dict)
        and e.get("must_reply") is True
        and e.get("replied") is not True
        for e in inbox_entries
    )
    return inbox_entries, all_replied


def check_and_clear_must_reply_obligations(
    inbox_entries: list[dict],
) -> bool:
    """Check whether all must_reply messages have been replied to.

    Returns ``True`` if there are no unreplied must_reply messages
    (i.e. the reply_wake schedule can be deleted).
    """
    return not any(
        isinstance(e, dict)
        and e.get("must_reply") is True
        and e.get("replied") is not True
        for e in inbox_entries
    )



def _transport_unavailable(tool_name: str) -> dict:
    return _error_result(
        f"Cannot use {tool_name}: this transport does not provide task orchestration"
    )


_SAFE_IDENTITY_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_SEARCH_MODES = {"children", "siblings", "parent", "ancestors", "descendants", "family", "tree"}
_SEARCH_MAX_LIMIT = 200
_CURSOR_MAX_SNAPSHOTS = 64
_CURSOR_TTL_SECONDS = 300


class _CursorEntry:
    """Process-local frozen snapshot for mutation-stable cursor pagination."""

    __slots__ = (
        "created_at", "all_members", "total_count", "limit",
        "mode", "team_name", "current_agent", "target_agent",
        "target_lineage", "parent_name", "next_offset",
    )

    def __init__(
        self,
        *,
        created_at: float,
        all_members: list[dict[str, Any]],
        total_count: int,
        limit: int,
        mode: str,
        team_name: str,
        current_agent: str,
        target_agent: str,
        target_lineage: list[str],
        parent_name: str | None,
        next_offset: int,
    ):
        self.created_at = created_at
        self.all_members = all_members
        self.total_count = total_count
        self.limit = limit
        self.mode = mode
        self.team_name = team_name
        self.current_agent = current_agent
        self.target_agent = target_agent
        self.target_lineage = target_lineage
        self.parent_name = parent_name
        self.next_offset = next_offset


_cursor_store: OrderedDict[str, _CursorEntry] = OrderedDict()


def _cursor_evict(now: float) -> None:
    """Remove expired and excess cursor snapshots."""
    expired = [k for k, v in _cursor_store.items() if now - v.created_at > _CURSOR_TTL_SECONDS]
    for k in expired:
        del _cursor_store[k]
    while len(_cursor_store) > _CURSOR_MAX_SNAPSHOTS:
        _cursor_store.popitem(last=False)


def _build_member_xml_attrs(member: dict[str, Any]) -> dict[str, str]:
    """Build XML attributes for a single search_team member element."""
    attrs: dict[str, str] = {}
    for key in (
        "team_name", "agent_name", "display_name", "relation", "parent_agent_name",
        "parent_display_name", "root_team_key", "lineage_length", "session_id", "running", "runtime_status",
        "idle_ready", "task_status", "last_activity_epoch", "last_activity_at",
        "last_activity_source", "topic_chat_id", "topic_thread_id",
    ):
        value = member.get(key)
        if value is None:
            continue
        if key == "lineage_length" and not isinstance(value, int):
            continue
        attrs[key] = str(value).lower() if isinstance(value, bool) else str(value)
    lineage = member.get("lineage")
    if isinstance(lineage, list):
        attrs["lineage"] = "\\x1f".join(str(item) for item in lineage)
    return attrs


def _build_search_result_page(
    *,
    page_members: list[dict[str, Any]],
    mode: str,
    team_name: str,
    current_agent: str,
    target_agent: str,
    target_lineage: list[str],
    total_matching: int,
    offset: int,
    limit: int,
    parent_name: str | None,
    next_cursor: str | None = None,
) -> tuple[dict[str, Any], str]:
    """Build result dict and XML for a search_team page (shared by live and cursor paths)."""
    has_more = offset + len(page_members) < total_matching
    result: dict[str, Any] = {
        "mode": mode,
        "team_name": team_name,
        "current_agent": current_agent,
        "target_agent": target_agent,
        "target_lineage": list(target_lineage),
        "total_matching": total_matching,
        "offset": offset,
        "limit": limit,
        "returned": len(page_members),
        "has_more": has_more,
        "members": page_members,
    }
    if has_more:
        result["next_offset"] = offset + len(page_members)
    if next_cursor is not None:
        result["next_cursor"] = next_cursor
    page_names = [m["agent_name"] for m in page_members]
    if mode in {"children", "family"}:
        result["children"] = [n for n, m in zip(page_names, page_members) if m.get("relation") == "child"]
    if mode in {"parent", "family"}:
        result["parent"] = parent_name
    if mode in {"siblings", "family"}:
        result["siblings"] = [n for n, m in zip(page_names, page_members) if m.get("relation") == "sibling"]
    if mode == "ancestors":
        result["ancestors"] = [n for n, m in zip(page_names, page_members) if m.get("relation") == "ancestor"]
    if mode == "descendants":
        result["descendants"] = [n for n, m in zip(page_names, page_members) if m.get("relation") == "descendant"]
    if mode == "tree":
        result["tree"] = list(page_names)
        result["tree_members"] = page_members

    root_attrs: dict[str, str] = {
        "team_name": team_name,
        "target_agent": target_agent,
        "mode": mode,
        "offset": str(offset),
        "limit": str(limit),
        "total_matching": str(total_matching),
        "returned": str(len(page_members)),
        "has_more": "true" if has_more else "false",
    }
    if "next_offset" in result:
        root_attrs["next_offset"] = str(result["next_offset"])
    if next_cursor is not None:
        root_attrs["next_cursor"] = next_cursor
    xml_root = ET.Element("search_team", root_attrs)
    for member in page_members:
        ET.SubElement(xml_root, "member", _build_member_xml_attrs(member))
    xml_text = ET.tostring(xml_root, encoding="unicode", short_empty_elements=True)
    return result, xml_text


def _member_activity_sort_key(member: dict[str, Any], agent_name: str) -> tuple[int, float, str, str]:
    """Sort valid activity newest first, with unknown activity last."""
    activity = _parse_jsonl_event_timestamp(member.get("last_activity_epoch"))
    team_name = str(member.get("team_name") or "")
    if activity is not None:
        return (0, -activity, team_name, str(agent_name))
    return (1, 0.0, team_name, str(agent_name))


def _safe_search_identity(value: object, *, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a known local identity")
    normalized = value.strip()
    if not normalized or not _SAFE_IDENTITY_RE.fullmatch(normalized):
        raise ValueError(f"{field_name} must be a known local identity")
    return normalized


def _parse_search_timestamp(value: object, *, field_name: str) -> float | None:
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            parsed = float(value)
        elif isinstance(value, str):
            parsed_datetime = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
            if parsed_datetime.tzinfo is None or parsed_datetime.utcoffset() is None:
                raise ValueError
            parsed = parsed_datetime.timestamp()
        else:
            raise ValueError
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f"{field_name} must be epoch seconds or RFC3339") from None
    if not math.isfinite(parsed):
        raise ValueError(f"{field_name} must be finite")
    return parsed


def _parse_jsonl_event_timestamp(value: object) -> float | None:
    """Accept only timestamps that can also be rendered as a UTC datetime.

    A finite float is not sufficient: very large epochs and timezone offsets
    near years 1 and 9999 can lie outside datetime's supported range. Reject
    them here so an invalid newest event cannot hide a valid older event or
    crash result serialization later.
    """
    if isinstance(value, bool):
        return None
    try:
        if isinstance(value, (int, float)):
            parsed = float(value)
        elif isinstance(value, str) and value.strip():
            parsed_datetime = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
            if parsed_datetime.tzinfo is None or parsed_datetime.utcoffset() is None:
                return None
            parsed = parsed_datetime.timestamp()
        else:
            return None
        if not math.isfinite(parsed):
            return None
        datetime.fromtimestamp(parsed, tz=timezone.utc)
    except (TypeError, ValueError, OverflowError, OSError):
        return None
    return parsed


def _activity_fallback(entry: dict[str, Any]) -> tuple[float | None, str]:
    """Use the first usable runtime/projection timestamp, not the first field."""
    timestamp_fields = (
        "last_activity", "last_active_at", "last_activity_at",
        "updated_at", "completed_at", "created_at",
    )
    for key in timestamp_fields:
        value = entry.get(key)
        is_numeric = isinstance(value, (int, float)) and not isinstance(value, bool)
        if key == "updated_at" and is_numeric:
            # Older projection records use milliseconds for this field only.
            try:
                numeric_value = float(value)
            except (TypeError, ValueError, OverflowError):
                continue
            if numeric_value > 10_000_000_000:
                value = numeric_value / 1000.0
        parsed = _parse_jsonl_event_timestamp(value)
        if parsed is None:
            continue
        source = (
            "runtime_last_activity"
            if key == "last_activity" and is_numeric
            else "projection_timestamp"
        )
        return parsed, source
    return None, "unknown"


def _fold_jsonl_event_activity(newest: float | None, raw: str) -> float | None:
    if not raw:
        return newest
    try:
        record = json.loads(raw)
    except (TypeError, ValueError, RecursionError):
        return newest
    if not isinstance(record, dict):
        return newest
    timestamp = _parse_jsonl_event_timestamp(record.get("timestamp"))
    if timestamp is not None and (newest is None or timestamp > newest):
        return timestamp
    return newest


# obs-54: search_team parsed every member's whole session JSONL on each call
# (187 loop stalls of ~8 s on 2026-10-25). The newest timestamp is a running
# maximum, so it is kept with the offset reached and only appended bytes are
# read; search_team also runs these scans off the event loop.
_event_activity_cache: AppendScanCache[float | None] = AppendScanCache(
    _fold_jsonl_event_activity, None, errors="replace",
)


def _jsonl_event_activity(path: Any) -> float | None:
    try:
        if not isinstance(path, (str, os.PathLike)):
            # A path-like object that only offers open(): fold it in full.
            newest: float | None = None
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                for raw_line in handle:
                    newest = _fold_jsonl_event_activity(newest, raw_line.strip())
            return newest
        return _event_activity_cache.scan(path)
    except (OSError, UnicodeError):
        return None


def _jsonl_path_activity(path: Path) -> tuple[float | None, str]:
    activity_epoch = _jsonl_event_activity(path)
    if activity_epoch is not None:
        return activity_epoch, "jsonl_event_timestamp"
    try:
        activity_epoch = _parse_jsonl_event_timestamp(path.stat().st_mtime)
    except OSError:
        return None, "unknown"
    if activity_epoch is not None:
        return activity_epoch, "jsonl_mtime_fallback"
    return None, "unknown"


def _jsonl_activities(paths: list[Path]) -> dict[Path, tuple[float | None, str]]:
    return {path: _jsonl_path_activity(path) for path in paths}


_JSONL_SCAN_EXECUTOR: "ThreadPoolExecutor | None" = None


def _jsonl_scan_executor() -> "ThreadPoolExecutor":
    """One worker thread for session-file scans, so concurrent scans queue
    behind each other instead of all contending with the event loop."""
    global _JSONL_SCAN_EXECUTOR
    if _JSONL_SCAN_EXECUTOR is None:
        _JSONL_SCAN_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="obs-jsonl-scan")
    return _JSONL_SCAN_EXECUTOR


def _load_team_projection_metadata(team_name: str) -> dict[str, dict[str, Any]]:
    config_path = Path.home() / ".claude" / "teams" / team_name / "config.json"
    if not config_path.exists():
        return {}
    try:
        payload = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        logger.warning("Failed reading team config JSON: %s", config_path, exc_info=True)
        return {}
    if not isinstance(payload, dict):
        return {}
    members = payload.get("members")
    if not isinstance(members, list):
        return {}
    metadata: dict[str, dict[str, Any]] = {}
    for member in members:
        if not isinstance(member, dict):
            continue
        agent_name = str(member.get("name") or "").strip()
        if not agent_name or agent_name == "team-lead":
            continue
        if not _SAFE_IDENTITY_RE.fullmatch(agent_name):
            continue
        obs = member.get("obs")
        if not isinstance(obs, dict):
            obs = {}
        entry: dict[str, Any] = {
            "agent_name": agent_name,
            "team_name": team_name,
        }
        for source, target in ((member, "session_id"), (obs, "session_id")):
            value = source.get(target)
            if isinstance(value, str) and value.strip():
                entry[target] = value.strip()
        display_name = obs.get("display_name")
        if isinstance(display_name, str) and display_name.strip():
            entry["display_name"] = display_name.strip()
        parent_agent_name = obs.get("parent_agent_name")
        if isinstance(parent_agent_name, str) and parent_agent_name.strip():
            entry["parent_agent_name"] = parent_agent_name.strip()
        parent_display_name = obs.get("parent_display_name")
        if isinstance(parent_display_name, str) and parent_display_name.strip():
            entry["parent_display_name"] = parent_display_name.strip()
        for key in (
            "root_team_key",
            "runtime_status",
            "task_status",
            "status",
            "last_activity_source",
        ):
            value = obs.get(key)
            if isinstance(value, str) and value.strip():
                entry[key] = value.strip()
        for key in ("running", "idle_ready"):
            value = obs.get(key)
            if isinstance(value, bool):
                entry[key] = value
        for key in ("last_activity", "last_active_at", "last_activity_at", "updated_at", "completed_at", "created_at"):
            value = obs.get(key)
            if isinstance(value, (int, float, str)) and not isinstance(value, bool):
                entry[key] = value
        lineage = obs.get("lineage")
        if isinstance(lineage, list):
            normalized_lineage = [
                str(item).strip()
                for item in lineage
                if isinstance(item, str) and str(item).strip()
            ]
            if normalized_lineage:
                entry["lineage"] = normalized_lineage
                entry["lineage_length"] = len(normalized_lineage)
        for key in ("topic_chat_id", "topic_thread_id", "updated_at"):
            value = obs.get(key)
            if isinstance(value, int):
                entry[key] = value
        metadata[agent_name] = entry
    return metadata


def _coerce_bool_arg(value, *, name: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered == "true":
            return True
        if lowered == "false":
            return False
    raise ValueError(f"{name} must be true or false")


def _normalize_resume_arg(value: object) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    if not normalized:
        return None
    if normalized.lower() in {"false", "none", "null", "nil", "0", "no"}:
        return None
    return normalized


def _normalize_session_source_arg(value: object) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    if not normalized:
        return None
    if normalized.lower() in {"false", "none", "null", "nil", "0", "no"}:
        return None
    return normalized


def _inbox_lock(path: Path) -> asyncio.Lock:
    lock = _INBOX_FILE_LOCKS.get(path)
    if lock is None:
        lock = asyncio.Lock()
        _INBOX_FILE_LOCKS[path] = lock
    return lock


def create_obs_tools(
    config: OBSConfig,
    get_session_id: Callable[[], str | None],
    hook_state: HookState | None = None,
    *,
    return_tools: bool = False,
):
    """Create the OBS Agent MCP tool server.

    get_session_id is a callable that returns the current session_id
    (closure over daemon state).

    hook_state is optional. When provided, transport-owned task tools such as
    ``AgentTask`` can delegate launch behavior through hook_state callbacks.
    """

    def _current_obs_bootstrap():
        if hook_state is not None and hook_state.pending_obs_bootstrap_xml:
            try:
                return parse_obs_bootstrap_xml(hook_state.pending_obs_bootstrap_xml)
            except Exception:
                logger.warning("Failed parsing pending OBS bootstrap XML", exc_info=True)
        session_id = get_session_id()
        if not session_id and hook_state is not None:
            session_id = hook_state.session_id
        result = find_latest_obs_bootstrap_for_session(
            session_id=session_id,
            cwd=config.vault_path,
        )
        return result

    def _lookup_team_context() -> tuple[str | None, str | None]:
        """Return one validated caller team or a deterministic context error."""
        candidates: set[str] = set()
        env_team = (
            hook_state.sdk_env_overrides.get("CLAUDE_CODE_TEAM_NAME", "").strip()
            if hook_state is not None
            else ""
        )
        if env_team:
            if not _SAFE_TEAM_IDENTITY_RE.fullmatch(env_team.lower()):
                return None, "caller team context is invalid"
            candidates.add(env_team.lower())
        bootstrap = _current_obs_bootstrap()
        bootstrap_team = (
            str(bootstrap.root_team_key or "").strip()
            if bootstrap is not None
            else ""
        )
        if bootstrap_team:
            if not _SAFE_TEAM_IDENTITY_RE.fullmatch(bootstrap_team.lower()):
                return None, "caller team context is invalid"
            candidates.add(bootstrap_team.lower())
        if len(candidates) > 1:
            return None, "caller team context is ambiguous"
        if not candidates:
            return None, "caller team context is unavailable"
        return next(iter(candidates)), None

    def _start_step_warning(*, session_id: str | None, texts, display_name: str | None) -> str | None:
        """Agent Operations start-step check (vault-a6qm); None when nothing to say."""
        try:
            check_mode = _start_step.mode()
            if check_mode == "off":
                return None
            bootstrap = _current_obs_bootstrap()
            known = _start_step.known_bead_ids(config.vault_path)
            if not known:
                return None  # no Beads store: nothing to check against
            if any(_start_step.find_bead_ids(text, known) for text in texts):
                return None
            jsonl = None
            if session_id:
                jsonl = find_session_jsonl_index(session_ids={session_id}, cwd=config.vault_path).get(session_id)
            if _start_step.transcript_has_bead(jsonl, known, session_id=session_id):
                return None
            blocked = check_mode == "block"
            _start_step.log_warning(
                session_id=session_id,
                agent_name=bootstrap.agent_name if bootstrap is not None else None,
                team_name=bootstrap.root_team_key if bootstrap is not None else None,
                display_name=display_name,
                blocked=blocked,
            )
            return _start_step.warning_text(blocked=blocked)
        except Exception:
            logger.debug("start-step check failed", exc_info=True)
            return None

    async def _launch_task(
        args: dict,
        *,
        tool_name: str,
        default_fork: bool,
    ) -> dict:
        prompt = str(args.get("prompt", "")).strip()
        prompt_file = str(args.get("prompt_file", "")).strip()
        prompt_file_content = ""

        # --- prompt_file resolution ---
        if prompt_file:
            try:
                file_path = Path(prompt_file)
                if str(prompt_file).startswith("~"):
                    file_path = file_path.expanduser()
                elif not file_path.is_absolute():
                    file_path = config.vault_path / file_path
                file_content = file_path.read_text(encoding="utf-8")
            except FileNotFoundError:
                return _error_result(f"Cannot launch {tool_name}: prompt_file not found: {file_path}")
            except PermissionError:
                return _error_result(f"Cannot launch {tool_name}: permission denied reading prompt_file: {file_path}")
            except Exception as exc:
                return _error_result(f"Cannot launch {tool_name}: cannot read prompt_file: {exc}")
            prompt_file_content = file_content.strip()

        # display_name is the canonical param. alias/description/name are
        # deprecated fallbacks. This is the human-readable label, NOT the
        # machine agent_name (computed from lineage by agent_name_for_lineage).
        display_name = str(
            args.get("display_name") or args.get("alias") or args.get("description") or args.get("name") or ""
        ).strip() or None
        description = display_name  # Internal payload still uses "description" key
        resume = _normalize_resume_arg(args.get("resume"))
        session_source = _normalize_session_source_arg(args.get("session_source"))
        try:
            allow_cold_wake = _coerce_bool_arg(args.get("allow_cold_wake", False), name="allow_cold_wake")
        except ValueError:
            return _error_result(f"Cannot launch {tool_name}: allow_cold_wake must be true or false")
        run_in_background = args.get("run_in_background")
        team_name = str(args.get("team_name", "")).strip() or None
        agent_name = str(args.get("agent_name") or "").strip() or None
        new_tree_chat = args.get("new_tree_chat")
        if isinstance(new_tree_chat, str):
            new_tree_chat = new_tree_chat.strip() or None
        fork = default_fork
        if "fork" in args:
            try:
                fork = _coerce_bool_arg(args.get("fork"), name="fork")
            except ValueError:
                return _error_result(f"Cannot launch {tool_name}: fork must be true or false")
        if new_tree_chat is not None:
            # A new tree is a fresh root in another chat: it never copies this session's history.
            if "fork" in args and fork:
                return _error_result(
                    f"Cannot launch {tool_name}: new_tree_chat starts a fresh root; omit fork or pass fork=false"
                )
            if resume or session_source:
                return _error_result(
                    f"Cannot launch {tool_name}: new_tree_chat cannot be combined with resume or session_source"
                )
            if not display_name:
                return _error_result(f"Cannot launch {tool_name}: display_name (the new topic's title) is required")
            fork = False
        if session_source and not fork:
            return _error_result(
                f"Cannot launch {tool_name}: session_source is only supported with fork=true"
            )
        if session_source and resume:
            return _error_result(
                f"Cannot launch {tool_name}: resume and session_source are mutually exclusive"
            )
        # Model selection. Empty, "inherit" or "source" = the fork source's own model (the
        # launcher's own head, or the session_source); fresh launches inherit the parent's.
        # An explicit model on a fork is honoured within the source's model family and refused
        # across families by the launcher, which knows the source's model (fork_model.py).
        model_raw = str(args.get("model", "")).strip()
        model: str | None = None
        if model_raw and model_raw.lower() not in ("inherit", "source"):
            model = model_raw
        # Effort is independent of model/context and may change on a fork.
        from obs_agent.effort import EFFORT_ENV, normalize_effort

        effort = args.get("effort")
        if effort is not None:
            try:
                effort = (
                    "inherit" if isinstance(effort, str) and effort.strip().lower() == "inherit"
                    else normalize_effort(effort)
                )
            except ValueError as exc:
                return _error_result(f"Cannot launch {tool_name}: {exc}")
            if resume:
                return _error_result(
                    f"Cannot launch {tool_name}: resume preserves the child's effort; "
                    "use /effort in its topic before resuming"
                )
        # --- inherit_schedules ---
        inherit_schedules = True
        if "inherit_schedules" in args:
            try:
                inherit_schedules = _coerce_bool_arg(args.get("inherit_schedules"), name="inherit_schedules")
            except ValueError:
                return _error_result(f"Cannot launch {tool_name}: inherit_schedules must be true or false")

        # --- env passthrough ---
        env_override: dict[str, str] | None = None
        env_raw = args.get("env")
        if env_raw:
            try:
                env_override = json.loads(env_raw) if isinstance(env_raw, str) else env_raw
            except (json.JSONDecodeError, TypeError) as exc:
                return _error_result(f"Cannot launch {tool_name}: env must be a valid JSON object: {exc}")
            if not isinstance(env_override, dict):
                return _error_result(f"Cannot launch {tool_name}: env must be a JSON object (dict), got {type(env_override).__name__}")

        if env_override and EFFORT_ENV in env_override:
            try:
                normalize_effort(env_override[EFFORT_ENV])
            except ValueError as exc:
                return _error_result(f"Cannot launch {tool_name}: {exc}")
            if resume:
                return _error_result(f"Cannot launch {tool_name}: resume preserves the child's effort")

        # --- temperature ---
        temperature: float | None = None
        temperature_raw = args.get("temperature")
        if temperature_raw is not None and str(temperature_raw).strip():
            try:
                temperature = float(temperature_raw)
            except (TypeError, ValueError):
                return _error_result(f"Cannot launch {tool_name}: temperature must be a number (e.g. '0', '0.5', '1')")
            if temperature < 0 or temperature > 2:
                return _error_result(f"Cannot launch {tool_name}: temperature must be between 0 and 2")

        # --- hooks ---
        user_hooks: dict[str, str] | None = None
        hooks_raw = args.get("hooks")
        if hooks_raw:
            try:
                user_hooks = json.loads(hooks_raw) if isinstance(hooks_raw, str) else hooks_raw
            except (json.JSONDecodeError, TypeError) as exc:
                return _error_result(f"Cannot launch {tool_name}: hooks must be a valid JSON object: {exc}")
            if not isinstance(user_hooks, dict):
                return _error_result(
                    f"Cannot launch {tool_name}: hooks must be a JSON object, got {type(user_hooks).__name__}"
                )
            resolved_hooks: dict[str, str] = {}
            for event_name, spec in user_hooks.items():
                if not isinstance(spec, str) or "::" not in spec:
                    return _error_result(
                        f"Cannot launch {tool_name}: hooks['{event_name}'] must be "
                        f"'file_path::function_name', got: {spec!r}"
                    )
                try:
                    # obs-54: validation runs Git subprocesses; keep them off the event loop.
                    resolved_hooks[str(event_name)] = await asyncio.to_thread(
                        _resolve_hook_spec_path, spec, config.vault_path,
                    )
                except ValueError as exc:
                    return _error_result(f"Cannot launch {tool_name}: {exc}")
            user_hooks = resolved_hooks

        # --- inherit_hooks ---
        inherit_hooks = False
        if "inherit_hooks" in args:
            try:
                inherit_hooks = _coerce_bool_arg(args.get("inherit_hooks"), name="inherit_hooks")
            except ValueError:
                return _error_result(f"Cannot launch {tool_name}: inherit_hooks must be true or false")

        # Kept for internal/future use. Not declared in the MCP schema, so only in-process
        # callers can pass them: the MCP layer drops undeclared arguments before they
        # reach this handler (observed live 2026-10-20, obs-15 E3: max_turns arrived None).
        timeout_ms_raw = args.get("timeout_ms")
        max_turns_raw = args.get("max_turns")
        if not prompt and not prompt_file_content:
            return _error_result(f"Cannot launch {tool_name}: prompt or prompt_file is required")

        if run_in_background is not None:
            try:
                run_in_background = _coerce_bool_arg(
                    run_in_background,
                    name="run_in_background",
                )
            except ValueError:
                return _error_result(
                    f"Cannot launch {tool_name}: run_in_background must be true"
                )
            if run_in_background is False:
                return _error_result(f"Cannot launch {tool_name}: run_in_background must be true")

        if hook_state is None or hook_state.fork_task_launcher is None:
            return _transport_unavailable(tool_name)

        timeout_ms: int | None = None
        if timeout_ms_raw is not None:
            try:
                timeout_ms = max(int(timeout_ms_raw), 1)
            except (TypeError, ValueError):
                return _error_result(f"Cannot launch {tool_name}: timeout_ms must be an integer")
        max_turns: int | None = None
        if max_turns_raw is not None:
            try:
                max_turns = int(max_turns_raw)
            except (TypeError, ValueError):
                return _error_result(f"Cannot launch {tool_name}: max_turns must be an integer")
            if max_turns <= 0:
                return _error_result(f"Cannot launch {tool_name}: max_turns must be positive")

        try:
            effective_session_id = get_session_id()
            if not effective_session_id and hook_state is not None:
                effective_session_id = hook_state.session_id
            payload: dict[str, Any] = {
                "session_id": effective_session_id,
                "prompt": prompt,
                "description": description,
                "resume": resume,
                "session_source": session_source,
                "run_in_background": True,
                "timeout_ms": timeout_ms,
                "max_turns": max_turns,
                "fork": fork,
                "model": model,
                "effort": effort,
                "team_name": team_name,
                "agent_name": agent_name,
                "task_tool_name": tool_name,
                "tool_use_id": hook_state.current_tool_use_id,
                "inherit_schedules": inherit_schedules,
                "env": env_override,
                "temperature": temperature,
                "hooks": user_hooks,
                "inherit_hooks": inherit_hooks,
                "allow_cold_wake": allow_cold_wake,
            }
            if new_tree_chat is not None:
                payload["new_tree_chat"] = new_tree_chat
            if prompt_file:
                payload["prompt_file"] = prompt_file
                payload["prompt_file_content"] = prompt_file_content
            start_warning = None
            if not resume:
                start_warning = _start_step_warning(
                    session_id=effective_session_id,
                    texts=(prompt, prompt_file_content),
                    display_name=display_name,
                )
            if start_warning is not None and _start_step.mode() == "block":
                return _error_result(start_warning)
            result = await hook_state.fork_task_launcher(payload)
            if start_warning is not None and isinstance(result, dict) and not result.get("is_error"):
                content = result.get("content")
                if isinstance(content, list):
                    result["content"] = [*content, {"type": "text", "text": start_warning}]
            return result
        except Exception as exc:
            logger.exception("%s launch failed", tool_name)
            return _error_result(f"{tool_name} failed: {type(exc).__name__}: {exc}")

    @tool(
        "AgentTask",
        "Launch a delegated child agent in a new Telegram topic. "
        "Set fork=true to continue from current session head, or fork=false to start "
        "a fresh child session in the new topic.",
        {
            "type": "object",
            "properties": {
            "prompt": {
                "type": "string",
                "description": "Full task prompt for the child session. May be combined with prompt_file.",
            },
            "prompt_file": {
                "type": "string",
                "description": (
                    "Path to a file containing additional prompt context. Vault-relative by default, "
                    "absolute paths (/...) and ~/paths supported. May be combined with prompt."
                ),
            },
            "display_name": {
                "type": "string",
                "description": "Human-readable name for the child agent (used in topic titles and lineage).",
            },
            "alias": {
                "type": "string",
                "description": "Deprecated: use display_name.",
            },
            "description": {
                "type": "string",
                "description": "Deprecated: use display_name.",
            },
            "resume": {
                "type": "string",
                "description": "Optional deprecated/internal task handle to resume an existing child task",
            },
            "agent_name": {
                "type": "string",
                "description": "Optional stable hash-prefixed agent identity; returned with team_name, lineage, and actual session_id.",
            },
            "session_source": {
                "type": "string",
                "description": (
                    "Optional session to fork from when fork=true (any agent's session, any model). "
                    "Accepts a stored session ID or JSONL file path. The fork runs on that "
                    "session's own model and effort unless model is given, and appears under the "
                    "launcher in the agent tree. Not supported with fork=false."
                ),
            },
            "fork": {
                "type": "boolean",
                "description": "When true, fork from parent head; when false, start fresh",
            },
            # run_in_background: hardcoded true, not exposed in MCP schema
            # timeout_ms and max_turns: kept for internal/future use — not exposed in MCP schema
            "model": {
                "type": "string",
                "description": (
                    "Model for the child session. Accepts shorthands "
                    "(sol, claude, gpt, gemini) which resolve to the latest tier, or full names "
                    "(gpt-5.6-sol, gemini-2.5-pro). "
                    "Append a context suffix like [1m] or [200k] to set the session context "
                    "budget (default: model-specific). The suffix is a capacity/budget "
                    "selector, not the served window: the served window comes from the model "
                    "table (e.g. local-qwen3.8-27b[1m] serves a 262k window, not 1M; [1m] is "
                    "a literal 1M only on a true-1M profile). fork=false: 'inherit' or omitted = "
                    "the current session's model. fork=true: omitted, 'inherit' or 'source' = the "
                    "FORK SOURCE's own model and effort (the session_source when given, else this "
                    "session), which is what reuses its prompt cache; an explicit model is honoured "
                    "within the source's family (Claude, GPT, local) and refused across families, "
                    "because the copied history and its cache belong to the source's provider. Use "
                    "fork=false for a fresh session on another family."
                ),
            },
            "effort": {
                "type": "string",
                "enum": ["low", "medium", "high", "xhigh", "max", "auto", "inherit"],
                "description": (
                    "Reasoning effort, independent of model and context. Omitted: inherit parent "
                    "when model is inherited, otherwise use the selected model's default. "
                    "'inherit' explicitly uses parent effort; 'auto' uses the model default. "
                    "xhigh and max are distinct; provider/model support varies. "
                    "Passed via Claude Code env and translated for CLIProxyAPI. "
                    "Temperature/disabled-thinking overrides remain authoritative. "
                    "For a resumed child use /effort in its topic instead."
                ),
            },
            "name": {
                "type": "string",
                "description": "Deprecated: use display_name.",
            },
            "team_name": {
                "type": "string",
                "description": "Optional team/task-list name for flat team env bootstrap.",
            },
            "inherit_schedules": {
                "type": "string",
                "description": (
                    "Whether the child agent inherits the parent's schedules. "
                    "Default 'true'. Set to 'false' to prevent schedule inheritance."
                ),
            },
            "env": {
                "type": "string",
                "description": (
                    "JSON object of environment variable overrides for the child session. "
                    "These are merged into the child's SDK env overrides, e.g. "
                    '\'{"SOME_VAR": "value"}\'. User-provided env vars take precedence '
                    "over auto-configured ones."
                ),
            },
            "temperature": {
                "type": "string",
                "description": (
                    "Temperature for the child session (e.g. '0', '0.5', '1'). "
                    "WARNING: setting temperature requires disabling extended thinking — "
                    "the Anthropic API rejects temperature != 1 when thinking is enabled. "
                    "This trades reasoning quality for determinism. If both temperature "
                    "and env.CLAUDE_CODE_EXTRA_BODY are provided, temperature takes precedence."
                ),
            },
            "hooks": {
                "type": "string",
                "description": (
                    "JSON object mapping hook event names to Python function specs. "
                    "Each value must be 'file_path::function_name'; relative paths are resolved "
                    "against the vault path. The function is dynamically loaded and called with "
                    "(hook_input, tool_use_id, context). Hook functions run AFTER built-in OBS guards. Errors in hooks are "
                    "logged but never crash the session. "
                    'Example: \'{"PreToolUse": "procedures/hooks/guard.py::check_access"}\''
                ),
            },
            "allow_cold_wake": {
                "type": "boolean",
                "description": (
                    "Default false: resume or session_source of a session idle past its prompt-cache "
                    "lifetime is refused with its transcript path. Set true only when really needed."
                ),
            },
            "inherit_hooks": {
                "type": "string",
                "description": (
                    "Whether the child agent inherits its parent's hooks. "
                    "Default 'false'. Set to 'true' to propagate the parent session's "
                    "hooks to the child."
                ),
            },
            # CACHE-PREFIX WARNING: this schema is part of every session's tool list; any added
            # property breaks each live session's cache once, on its first turn after the deploy.
            # new_tree_chat (obs-15.5) is therefore NOT declared yet: _launch_task and the bot
            # already handle it, but model-issued calls drop undeclared arguments (probed
            # 2026-10-20: max_turns arrived as None), so agents use `obs-agentctl new-tree` for
            # now. Declare it here in the next deploy that changes a tool schema anyway.
            },
            "required": ["display_name"],
        },
    )
    async def agent_task(args: dict) -> dict:
        return await _launch_task(args, tool_name="AgentTask", default_fork=True)

    async def _task_output(args: dict, *, tool_name: str) -> dict:
        task_id = str(args.get("task_id", "")).strip()
        team_name = str(args.get("team_name", "")).strip()
        agent_name = str(args.get("agent_name", "")).strip()
        if task_id and (team_name or agent_name):
            return _error_result(f"Cannot use {tool_name}: task_id cannot be combined with stable identity")
        if not task_id and not agent_name:
            return _error_result(f"Cannot use {tool_name}: task_id or agent_name is required")
        if team_name and not agent_name:
            return _error_result(f"Cannot use {tool_name}: team_name requires agent_name")
        if team_name and not _SAFE_TEAM_IDENTITY_RE.fullmatch(team_name.lower()):
            return _error_result(f"Cannot use {tool_name}: team_name must be a timestamp-prefixed stable identity")
        if agent_name and not _SAFE_AGENT_IDENTITY_RE.fullmatch(agent_name.lower()):
            return _error_result(f"Cannot use {tool_name}: agent_name must be a hash-prefixed stable identity")
        if agent_name and not team_name:
            _caller_team, caller_error = _lookup_team_context()
            if caller_error:
                return _error_result(f"Cannot use {tool_name}: {caller_error}")
        block_raw = args.get("block")
        timeout = args.get("timeout")
        try:
            block = _coerce_bool_arg(block_raw, name="block")
        except ValueError:
            return _error_result(f"Cannot use {tool_name}: block must be true or false")
        try:
            timeout = int(timeout)
        except (TypeError, ValueError):
            return _error_result(f"Cannot use {tool_name}: timeout must be an integer")
        if timeout < 0:
            return _error_result(f"Cannot use {tool_name}: timeout must be non-negative")
        if hook_state is None or hook_state.fork_task_outputter is None:
            return _transport_unavailable(tool_name)
        try:
            return await hook_state.fork_task_outputter(
                {
                    "task_id": task_id,
                    "team_name": team_name,
                    "agent_name": agent_name,
                    "block": block,
                    "timeout": timeout,
                    "tool_use_id": hook_state.current_tool_use_id,
                }
            )
        except Exception as exc:
            logger.exception("%s failed", tool_name)
            return _error_result(f"{tool_name} failed: {type(exc).__name__}: {exc}")

    @tool(
        "AgentTaskOutput",
        "Inspect a running or completed AgentTask using stable agent_name with optional "
        "authorized team_name inference or deprecated/internal task_id compatibility, with bounded output.",
        {
            "task_id": {
                "type": "string",
                "description": "Deprecated/internal compatibility task handle returned by AgentTask",
            },
            "team_name": {
                "type": "string",
                "description": "Optional stable root team identity for an authorized on-behalf lookup; omit to infer the caller's accessible team",
            },
            "agent_name": {
                "type": "string",
                "description": "Stable hash-prefixed agent identity; team_name may be omitted to use the caller's accessible team",
            },
            "block": {
                "type": "boolean",
                "description": "Whether to wait for completion",
            },
            "timeout": {
                "type": "integer",
                "description": "Maximum wait time in milliseconds",
            },
        },
    )
    async def agent_task_output(args: dict) -> dict:
        return await _task_output(args, tool_name="AgentTaskOutput")

    async def _task_stop(args: dict, *, tool_name: str) -> dict:
        task_id = str(args.get("task_id") or args.get("shell_id") or "").strip()
        team_name = str(args.get("team_name", "")).strip()
        agent_name = str(args.get("agent_name", "")).strip()
        if task_id and (team_name or agent_name):
            return _error_result(f"Cannot use {tool_name}: task_id cannot be combined with stable identity")
        if not task_id and not agent_name:
            return _error_result(f"Cannot use {tool_name}: task_id or agent_name is required")
        if team_name and not agent_name:
            return _error_result(f"Cannot use {tool_name}: team_name requires agent_name")
        if team_name and not _SAFE_TEAM_IDENTITY_RE.fullmatch(team_name.lower()):
            return _error_result(f"Cannot use {tool_name}: team_name must be a timestamp-prefixed stable identity")
        if agent_name and not _SAFE_AGENT_IDENTITY_RE.fullmatch(agent_name.lower()):
            return _error_result(f"Cannot use {tool_name}: agent_name must be a hash-prefixed stable identity")
        if agent_name and not team_name:
            _caller_team, caller_error = _lookup_team_context()
            if caller_error:
                return _error_result(f"Cannot use {tool_name}: {caller_error}")
        if hook_state is None or hook_state.fork_task_stopper is None:
            return _transport_unavailable(tool_name)
        try:
            return await hook_state.fork_task_stopper(
                {
                    "task_id": task_id,
                    "team_name": team_name,
                    "agent_name": agent_name,
                    "tool_use_id": hook_state.current_tool_use_id,
                }
            )
        except Exception as exc:
            logger.exception("%s failed", tool_name)
            return _error_result(f"{tool_name} failed: {type(exc).__name__}: {exc}")

    @tool(
        "AgentTaskStop",
        "Stop a running AgentTask using stable agent_name with optional authorized team_name inference or deprecated/internal task_id input; repeated stable stops are idempotent.",
        {
            "task_id": {
                "type": "string",
                "description": "Deprecated/internal compatibility task handle returned by AgentTask",
            },
            "team_name": {
                "type": "string",
                "description": "Optional stable root team identity for an authorized on-behalf lookup; omit to infer the caller's accessible team",
            },
            "agent_name": {
                "type": "string",
                "description": "Stable hash-prefixed agent identity; team_name may be omitted to use the caller's accessible team",
            },
            "shell_id": {
                "type": "string",
                "description": "Deprecated alias for task_id, matching TaskStop.",
            },
        },
    )
    async def agent_task_stop(args: dict) -> dict:
        return await _task_stop(args, tool_name="AgentTaskStop")

    async def _cron_create(args: dict, *, tool_name: str) -> dict:
        prompt = str(args.get("prompt", "")).strip()
        prompt_file = str(args.get("prompt_file", "") or "").strip()
        if not prompt and not prompt_file:
            return _error_result(f"Cannot use {tool_name}: prompt is required unless prompt_file is given")
        cron = str(args.get("cron", "")).strip()
        schedule_mode_raw = args.get("schedule_mode")
        schedule_mode = (
            str(schedule_mode_raw).strip().lower()
            if schedule_mode_raw is not None
            else ""
        )
        if not schedule_mode:
            if args.get("interval_seconds") is not None:
                schedule_mode = "interval"
            elif cron:
                schedule_mode = "cron"
        if schedule_mode not in {"interval", "cron"}:
            return _error_result(
                f"Cannot use {tool_name}: schedule_mode must be interval or cron"
            )
        if schedule_mode == "cron" and not cron:
            return _error_result(f"Cannot use {tool_name}: cron is required for schedule_mode=cron")

        interval_seconds_raw = args.get("interval_seconds")
        interval_seconds: int | None = None
        if interval_seconds_raw is not None:
            try:
                interval_seconds = int(interval_seconds_raw)
            except (TypeError, ValueError):
                return _error_result(
                    f"Cannot use {tool_name}: interval_seconds must be an integer"
                )
            if interval_seconds < 0:
                return _error_result(
                    f"Cannot use {tool_name}: interval_seconds must be non-negative"
                )
        max_runs_raw = args.get("max_runs")
        max_runs: int = 1
        if max_runs_raw is not None:
            try:
                max_runs = int(max_runs_raw)
            except (TypeError, ValueError):
                return _error_result(f"Cannot use {tool_name}: max_runs must be an integer")
            if max_runs <= 0:
                return _error_result(f"Cannot use {tool_name}: max_runs must be positive")

        reset_session_raw = args.get("reset_session")
        reset_session: bool | None = None
        if reset_session_raw is not None:
            if isinstance(reset_session_raw, bool):
                reset_session = reset_session_raw
            elif isinstance(reset_session_raw, (int, float)):
                reset_session = bool(int(reset_session_raw))
            elif isinstance(reset_session_raw, str):
                normalized = reset_session_raw.strip().lower()
                if normalized in {"true", "1", "yes", "on"}:
                    reset_session = True
                elif normalized in {"false", "0", "no", "off"}:
                    reset_session = False
                else:
                    return _error_result(
                        f"Cannot use {tool_name}: reset_session must be a boolean"
                    )
            else:
                return _error_result(
                    f"Cannot use {tool_name}: reset_session must be a boolean"
                )

        legacy_run_mode = str(args.get("run_mode") or "").strip().lower()
        if reset_session is None and legacy_run_mode:
            if legacy_run_mode not in {"continue", "reset_session"}:
                return _error_result(
                    f"Cannot use {tool_name}: run_mode must be continue or reset_session"
                )
            reset_session = legacy_run_mode == "reset_session"
        if reset_session is None:
            reset_session = False

        inherit = str(args.get("inherit") or "").strip().lower() or "none"
        if inherit not in {"none", "fork", "all"}:
            return _error_result(
                f"Cannot use {tool_name}: inherit must be none, fork, or all"
            )

        if hook_state is None or hook_state.cron_creator is None:
            return _transport_unavailable(tool_name)
        try:
            return await hook_state.cron_creator(
                {
                    "schedule_mode": schedule_mode,
                    "cron": cron,
                    "prompt": prompt,
                    "prompt_file": prompt_file or None,
                    "interval_seconds": interval_seconds,
                    "reset_session": reset_session,
                    "description": str(args.get("description") or "").strip() or None,
                    "max_runs": max_runs,
                    "from": str(args.get("from") or "").strip() or None,
                    "until": str(args.get("until") or "").strip() or None,
                    "inherit": inherit,
                    "tool_use_id": hook_state.current_tool_use_id,
                }
            )
        except Exception as exc:
            logger.exception("%s failed", tool_name)
            return _error_result(f"{tool_name} failed: {type(exc).__name__}: {exc}")

    async def _cron_list(args: dict, *, tool_name: str) -> dict:
        _ = args
        if hook_state is None or hook_state.cron_lister is None:
            return _transport_unavailable(tool_name)
        try:
            return await hook_state.cron_lister({"tool_use_id": hook_state.current_tool_use_id})
        except Exception as exc:
            logger.exception("%s failed", tool_name)
            return _error_result(f"{tool_name} failed: {type(exc).__name__}: {exc}")

    async def _cron_delete(args: dict, *, tool_name: str) -> dict:
        schedule_id = str(args.get("id") or "").strip()
        if not schedule_id:
            return _error_result(f"Cannot use {tool_name}: id is required")
        if hook_state is None or hook_state.cron_deleter is None:
            return _transport_unavailable(tool_name)
        try:
            return await hook_state.cron_deleter(
                {"id": schedule_id, "tool_use_id": hook_state.current_tool_use_id}
            )
        except Exception as exc:
            logger.exception("%s failed", tool_name)
            return _error_result(f"{tool_name} failed: {type(exc).__name__}: {exc}")

    @tool(
        "CronCreate",
        "Create a per-topic schedule in interval or cron mode. "
        "Interval mode is inactivity-based: after each topic turn finishes, "
        "next_run_at is reset to now + interval_seconds (not fixed wall-clock slots). "
        "Cron mode is wall-clock based (standard 5-field cron). "
        "Schedules run only when the topic is idle and the bot is available. "
        "Default behavior is one-shot (max_runs=1). "
        "Repeat by setting max_runs > 1.",
        {
            "schedule_mode": {
                "type": "string",
                "description": (
                    "interval or cron. interval = inactivity-based (re-anchored on topic completion/stop); "
                    "cron = wall-clock. If omitted, inferred from provided fields."
                ),
            },
            "cron": {
                "type": "string",
                "description": (
                    "Cron expression for schedule_mode=cron (wall-clock). "
                    "Standard 5-field cron syntax."
                ),
            },
            "prompt": {
                "type": "string",
                "description": "Prompt injected when this schedule fires. Optional when prompt_file is given.",
            },
            "prompt_file": {
                "type": "string",
                "description": (
                    "Optional file (vault-relative, absolute or ~) re-read at EVERY fire and "
                    "appended after prompt, so a memory/checkpoint file can be the wake prompt."
                ),
            },
            "interval_seconds": {
                "type": "integer",
                "description": (
                    "Interval seconds for schedule_mode=interval. "
                    "After each topic completion/stop, next run is scheduled after this many seconds. "
                    "0 means trigger on topic stop."
                ),
            },
            "reset_session": {
                "type": "boolean",
                "description": "If true, clear the session before each scheduled run.",
            },
            "description": {
                "type": "string",
                "description": "Optional short schedule name shown in completion messages.",
            },
            "max_runs": {
                "type": "integer",
                "description": "Run cap. Defaults to 1 when omitted.",
            },
            "from": {
                "type": "string",
                "description": "Optional RFC3339 start timestamp for active window start (inclusive).",
            },
            "until": {
                "type": "string",
                "description": "Optional RFC3339 cutoff timestamp; schedule stops at/after this time.",
            },
            "inherit": {
                "type": "string",
                "description": "Optional inheritance mode: none, fork, or all.",
            },
            "run_mode": {
                "type": "string",
                "description": "Deprecated alias: continue or reset_session.",
            },
        },
    )
    async def cron_create(args: dict) -> dict:
        return await _cron_create(args, tool_name="CronCreate")

    @tool(
        "CronList",
        "List schedules for the current topic route only, including next_run_at and run counters.",
        {},
    )
    async def cron_list(args: dict) -> dict:
        return await _cron_list(args, tool_name="CronList")

    @tool(
        "CronDelete",
        "Delete one schedule by ID in the current topic route.",
        {
            "id": {
                "type": "string",
                "description": "Schedule ID returned by CronCreate.",
            },
        },
    )
    async def cron_delete(args: dict) -> dict:
        return await _cron_delete(args, tool_name="CronDelete")

    async def _send_inbox_message(args: dict) -> dict:
        # On delivery failure, return "message underdelivered" and use _rollback_written_message after writes.
        bootstrap = _current_obs_bootstrap()
        team_name = str(args.get("team_name", "")).strip() or (
            bootstrap.root_team_key if bootstrap is not None else ""
        )
        recipient = str(args.get("recipient", "")).strip()
        content = str(args.get("content", "")).strip()
        summary = str(args.get("summary", "")).strip() or None
        sender = str(args.get("sender", "")).strip() or (
            bootstrap.agent_name if bootstrap is not None and bootstrap.agent_name else "obs-worker"
        )
        # vault-5lko: record the sender's own team so a recipient in another
        # tree can reply. Data-only field; the tool schema is unchanged.
        sender_team = (
            bootstrap.root_team_key.strip()
            if bootstrap is not None and bootstrap.root_team_key
            else ""
        ) or None
        # Backend-only optional reply flags stay accepted for internal callers,
        # but they are intentionally omitted from the MCP schema so agents cannot set them.
        # Use _coerce_bool_arg to handle string "false" correctly (bool("false") is True).
        if "needs_reply" in args:
            needs_reply_raw = args.get("needs_reply")
        else:
            needs_reply_raw = args.get("must_reply", False)
        try:
            must_reply = _coerce_bool_arg(needs_reply_raw, name="needs_reply")
        except ValueError:
            must_reply = False
        if not team_name:
            return _error_result(
                "Cannot use SendInboxMessage: team_name is required or must be inferable from current lineage"
            )
        if not recipient:
            return _error_result("Cannot use SendInboxMessage: recipient is required")
        if not content:
            return _error_result("Cannot use SendInboxMessage: content is required")
        # Block must_reply to self (would cause infinite wake loop)
        if must_reply and sender == recipient:
            return _error_result(
                "Cannot send must_reply to yourself — this would cause an infinite wake loop."
            )
        try:
            allow_cold_wake = _coerce_bool_arg(args.get("allow_cold_wake", False), name="allow_cold_wake")
        except ValueError:
            return _error_result("Cannot use SendInboxMessage: allow_cold_wake must be true or false")

        if recipient.startswith(_EXTERNAL_SENDER_PREFIX):
            # obs-12: messages from scripts (obs-agentctl message) arrive "from external:NAME".
            # External callers have no route, so a reply used to fail with "recipient has no
            # current route binding". Append it to the caller's outbox instead; no agent path
            # changes. See docs/external-control.md.
            return _deliver_external_reply(
                name=recipient[len(_EXTERNAL_SENDER_PREFIX):],
                team_name=team_name,
                sender=sender,
                content=content,
                summary=summary,
            )

        async def _validate_recipient(target: str) -> dict[str, Any] | None:
            if hook_state is None or hook_state.inbox_recipient_validator is None:
                return None
            try:
                validation = await hook_state.inbox_recipient_validator(
                    {
                        "team_name": team_name,
                        "recipient": target,
                        "allow_cold_wake": allow_cold_wake,
                    }
                )
            except Exception:
                logger.warning("SendInboxMessage validator failed", exc_info=True)
                return {"deliverable": False, "reason": "recipient validation failed"}
            if isinstance(validation, dict):
                return validation
            return {"deliverable": bool(validation)}

        def _is_deliverable(validation: dict[str, Any] | None) -> bool:
            return bool(validation and validation.get("deliverable"))

        inbox_dir = Path.home() / ".claude" / "teams" / team_name / "inboxes"
        resolved_recipient = recipient
        inbox_path = inbox_dir / f"{resolved_recipient}.json"
        validation = await _validate_recipient(resolved_recipient)

        # Alias resolution is intentionally limited to direct children:
        # exact agent_name wins, otherwise try "{sender_lineage_hash}-{alias_slug}".
        if (
            not inbox_path.exists()
            and not _is_deliverable(validation)
            and bootstrap is not None
            and bootstrap.lineage
        ):
            child_hash = lineage_fingerprint(
                tuple(normalize_lineage_name(n) for n in bootstrap.lineage)
            )
            child_slug = slugify_projection_label(recipient, fallback="")
            if child_slug:
                candidate = f"{child_hash}-{child_slug}"
                candidate_path = inbox_dir / f"{candidate}.json"
                candidate_validation = await _validate_recipient(candidate)
                if candidate_path.exists() or _is_deliverable(candidate_validation):
                    resolved_recipient = candidate
                    inbox_path = candidate_path
                    validation = candidate_validation

        if validation is not None and not _is_deliverable(validation):
            reason = str(validation.get("reason") or validation.get("warning") or "recipient has no current route binding")
            cold = bool(validation.get("cold"))
            return {
                "content": [{"type": "text", "text": reason if cold else f"message underdelivered: {reason}"}],
                "tool_use_result": {
                    "success": False,
                    "delivered": False,
                    "outcome": "cold_blocked" if cold else "underdelivered",
                    "reason": reason,
                    "recipient": resolved_recipient,
                    "team_name": team_name,
                },
                "is_error": True,
            }
        inbox_path.parent.mkdir(parents=True, exist_ok=True)
        lock = _inbox_lock(inbox_path)
        async with lock:
            entries: list[dict] = []
            if inbox_path.exists():
                try:
                    loaded = json.loads(inbox_path.read_text(encoding="utf-8"))
                    if isinstance(loaded, list):
                        entries = [item for item in loaded if isinstance(item, dict)]
                except Exception:
                    logger.warning("Failed reading inbox JSON: %s", inbox_path, exc_info=True)
            message: dict[str, Any] = {
                "from": sender,
                **({"from_team": sender_team} if sender_team else {}),
                "text": content,
                "summary": summary or "",
                "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "read": False,
            }
            if must_reply:
                message["must_reply"] = True
                message["replied"] = False
            entries.append(message)
            inbox_path.write_text(json.dumps(entries, ensure_ascii=True), encoding="utf-8")

        async def _rollback_written_message() -> None:
            async with lock:
                if not inbox_path.exists():
                    return
                try:
                    loaded = json.loads(inbox_path.read_text(encoding="utf-8"))
                except Exception:
                    logger.warning("Failed reading inbox JSON during rollback: %s", inbox_path, exc_info=True)
                    return
                if not isinstance(loaded, list):
                    return
                remaining = [item for item in loaded if isinstance(item, dict)]
                removed = False
                for index in range(len(remaining) - 1, -1, -1):
                    item = remaining[index]
                    if (
                        item.get("timestamp") == message["timestamp"]
                        and item.get("from") == sender
                        and item.get("text") == content
                        and item.get("summary", "") == (summary or "")
                    ):
                        del remaining[index]
                        removed = True
                        break
                if not removed:
                    return
                if remaining:
                    inbox_path.write_text(json.dumps(remaining, ensure_ascii=True), encoding="utf-8")
                else:
                    inbox_path.unlink(missing_ok=True)

        response = {
            "success": True,
            "delivered": True,
            "outcome": "reached",
            "team_name": team_name,
            "recipient": resolved_recipient,
            "message_count": len(entries),
        }
        if validation is not None and validation.get("warning"):
            response["warning"] = str(validation["warning"])
        notifier_result: dict[str, Any] | None = None
        if hook_state is not None and hook_state.inbox_message_notifier is not None:
            try:
                notification_payload: dict[str, Any] = {
                    "team_name": team_name,
                    "recipient": resolved_recipient,
                    "sender": sender,
                    "content": content,
                    "summary": summary,
                    "_direct_send": True,
                }
                if sender_team:
                    notification_payload["sender_team"] = sender_team
                if must_reply:
                    notification_payload["_must_reply"] = True
                raw_notifier_result = await hook_state.inbox_message_notifier(notification_payload)
                if isinstance(raw_notifier_result, dict):
                    notifier_result = raw_notifier_result
            except Exception:
                logger.warning("SendInboxMessage notifier failed", exc_info=True)
        if notifier_result is not None and notifier_result.get("delivered") is False:
            await _rollback_written_message()
            reason = str(notifier_result.get("reason") or "recipient wake failed")
            return {
                "content": [{"type": "text", "text": f"message underdelivered: {reason}"}],
                "tool_use_result": {
                    "success": False,
                    "delivered": False,
                    "outcome": "underdelivered",
                    "reason": reason,
                    "recipient": resolved_recipient,
                    "team_name": team_name,
                },
                "is_error": True,
            }

        # Reply detection: if we just sent a message to `recipient`, check our OWN
        # inbox for must_reply messages FROM that recipient that are unreplied.
        # If found, mark them replied.  When ALL must_reply messages are replied,
        # delete the reply_wake schedule.
        if sender and sender != resolved_recipient:
            sender_inbox_path = (
                Path.home()
                / ".claude"
                / "teams"
                / team_name
                / "inboxes"
                / f"{sender}.json"
            )
            if sender_inbox_path.exists():
                sender_lock = _inbox_lock(sender_inbox_path)
                async with sender_lock:
                    try:
                        sender_entries = json.loads(sender_inbox_path.read_text(encoding="utf-8"))
                        if isinstance(sender_entries, list):
                            updated, all_replied = detect_must_reply_completions(
                                sender_entries, resolved_recipient
                            )
                            replied_something = any(
                                e.get("replied") is True
                                for e in updated
                                if e.get("must_reply") is True and e.get("from") == resolved_recipient
                            )
                            if replied_something:
                                sender_inbox_path.write_text(
                                    json.dumps(updated, ensure_ascii=True),
                                    encoding="utf-8",
                                )
                            if all_replied and hook_state is not None:
                                if hook_state.inbox_message_notifier is not None:
                                    try:
                                        await hook_state.inbox_message_notifier(
                                            {
                                                "team_name": team_name,
                                                "recipient": sender,
                                                "sender": resolved_recipient,
                                                "content": "__reply_wake_clear__",
                                                "summary": "all must_reply messages replied",
                                                "_reply_wake_clear": True,
                                                "_direct_send": True,
                                            }
                                        )
                                    except Exception:
                                        logger.warning("Reply wake clear notification failed", exc_info=True)
                    except Exception:
                        logger.warning("Reply detection: failed reading sender inbox %s", sender_inbox_path, exc_info=True)
        return {
            "content": [{"type": "text", "text": json.dumps(response, ensure_ascii=True)}],
            "tool_use_result": response,
        }

    async def _read_inbox(args: dict) -> dict:
        bootstrap = _current_obs_bootstrap()
        team_name = str(args.get("team_name", "")).strip() or (
            bootstrap.root_team_key if bootstrap is not None else ""
        )
        agent = str(args.get("agent", "")).strip() or (
            bootstrap.agent_name if bootstrap is not None else ""
        )
        if not team_name:
            return _error_result(
                "Cannot use ReadInbox: team_name is required or must be inferable from current lineage"
            )
        if not agent:
            return _error_result(
                "Cannot use ReadInbox: agent is required or must be inferable from current lineage"
            )
        include_read = _coerce_bool_arg(args.get("include_read", False), name="include_read")
        mark_read = _coerce_bool_arg(args.get("mark_read", True), name="mark_read")
        try:
            limit = int(args.get("limit", 50))
        except (TypeError, ValueError):
            return _error_result("Cannot use ReadInbox: limit must be an integer")
        if limit <= 0:
            return _error_result("Cannot use ReadInbox: limit must be positive")

        inbox_path = (
            Path.home()
            / ".claude"
            / "teams"
            / team_name
            / "inboxes"
            / f"{agent}.json"
        )
        lock = _inbox_lock(inbox_path)
        async with lock:
            entries: list[dict] = []
            if inbox_path.exists():
                try:
                    loaded = json.loads(inbox_path.read_text(encoding="utf-8"))
                    if isinstance(loaded, list):
                        entries = [item for item in loaded if isinstance(item, dict)]
                except Exception:
                    logger.warning("Failed reading inbox JSON: %s", inbox_path, exc_info=True)

            selected = [
                item for item in entries
                if include_read or not bool(item.get("read", False))
            ]
            if len(selected) > limit:
                selected = selected[-limit:]
            if mark_read and entries:
                changed = False
                for item in selected:
                    if not bool(item.get("read", False)):
                        item["read"] = True
                        changed = True
                if changed:
                    inbox_path.parent.mkdir(parents=True, exist_ok=True)
                    inbox_path.write_text(json.dumps(entries, ensure_ascii=True), encoding="utf-8")

        result = {
            "team_name": team_name,
            "agent": agent,
            "count": len(selected),
            "messages": selected,
        }
        return {
            "content": [{"type": "text", "text": json.dumps(result, ensure_ascii=True)}],
            "tool_use_result": result,
        }

    @tool(
        "SendInboxMessage",
        "Write a message to a team inbox JSON file.",
        {
            "type": "object",
            "properties": {
                "team_name": {
                    "type": "string",
                    "description": "Optional team name; defaults to the current root team.",
                },
                "recipient": {
                    "type": "string",
                    "description": "Recipient agent name.",
                },
                "content": {
                    "type": "string",
                    "description": "Message body.",
                },
                "summary": {
                    "type": "string",
                    "description": "Optional short summary.",
                },
                "sender": {
                    "type": "string",
                    "description": "Optional sender label; defaults to the current agent name.",
                },
                "allow_cold_wake": {
                    "type": "boolean",
                    "description": (
                        "Default false: a message that would wake an agent idle past its prompt-cache "
                        "lifetime is refused with its transcript path. Set true only when the wake is "
                        "really needed."
                    ),
                },
                # Backend-only optional flags intentionally omitted from the MCP schema:
                # "needs_reply": {"type": "boolean", ...}
                # "must_reply": {"type": "boolean", ...}
            },
            "required": ["recipient", "content"],
            "additionalProperties": False,
        },
    )
    async def send_inbox_message(args: dict) -> dict:
        return await _send_inbox_message(args)

    @tool(
        "ReadInbox",
        "Read messages from a team inbox JSON file.",
        {
            "type": "object",
            "properties": {
                "team_name": {
                    "type": "string",
                    "description": "Optional team name; defaults to the current root team.",
                },
                "agent": {
                    "type": "string",
                    "description": "Optional agent inbox name; defaults to the current agent name.",
                },
                "include_read": {
                    "type": "boolean",
                    "description": "Include already-read messages.",
                },
                "mark_read": {
                    "type": "boolean",
                    "description": "Mark returned unread messages as read.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of messages to return.",
                },
            },
            "required": [],
            "additionalProperties": False,
        },
    )
    async def read_inbox(args: dict) -> dict:
        return await _read_inbox(args)

    def _effective_context_window_tokens() -> int:
        if hook_state is not None and hook_state.effective_model:
            _clean, tokens = parse_context_suffix(hook_state.effective_model)
            return tokens
        return config.context_window_estimate_tokens

    async def _render_context_and_session() -> str:
        data = hook_state.last_result_data if hook_state is not None else None
        snapshot = build_context_snapshot(
            session_id=get_session_id(),
            data=data,
            context_window_estimate_tokens=_effective_context_window_tokens(),
            cwd=config.vault_path,
        )
        probe = None
        if config.context_probe_claude_cli:
            probe = await probe_context_via_claude_cli(
                session_id=snapshot.get("session_id"),
                cwd=config.vault_path,
            )
        snapshot = apply_context_probe(snapshot, probe)
        return "\n".join(format_context_snapshot_lines(snapshot))

    @tool(
        "session_info",
        "Return current session + usage snapshot: session ID, turn count, latest usage, "
        "billing token totals, and estimated context remaining.",
        {},
    )
    async def session_info(args: dict) -> dict:
        return {"content": [{"type": "text", "text": await _render_context_and_session()}]}

    @tool(
        "context_info",
        "Return current session + context usage snapshot including latest input/output/cache "
        "token stats, billing token total, and estimated context remaining.",
        {},
    )
    async def context_info(args: dict) -> dict:
        return {"content": [{"type": "text", "text": await _render_context_and_session()}]}

    @tool(
        "session_lineage",
        "Return the current OBS lineage/bootstrap identity for this session.",
        {
            "include_xml": {
                "type": "boolean",
                "description": "Include the raw bootstrap XML payload in the response. Defaults to false.",
            },
        },
    )
    async def session_lineage(args: dict) -> dict:
        include_xml = _coerce_bool_arg(args.get("include_xml", False), name="include_xml")
        bootstrap = _current_obs_bootstrap()
        if bootstrap is None:
            return _error_result("Cannot use session_lineage: no OBS bootstrap found for current session")
        current_session_id = get_session_id()
        if not current_session_id and hook_state is not None:
            # The manager learns a fresh session's id from the CLI's system/init
            # (vault-1i53; before that, only when the turn finished). The hook
            # layer also sees it on every tool call (B27), so keep it as a fallback.
            current_session_id = hook_state.session_id
        payload = obs_bootstrap_to_dict(
            bootstrap,
            session_id=current_session_id,
            include_xml=include_xml,
        )
        if current_session_id:
            # vault-mngu: an inline reply-fork carries its agent's bootstrap only in
            # copied history, so the bootstrap's session_id names the parent branch.
            payload["session_id"] = current_session_id
        return {
            "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=True)}],
            "tool_use_result": payload,
        }

    @tool(
        "search_team",
        "Discover teammates in a lineage tree with target-relative filters, activity, and pagination.",
        {
            "type": "object",
            "properties": {
                "mode": {
                    "type": "string",
                    "description": "One of: parent, children, siblings, ancestors, descendants, family, tree",
                },
                "team_name": {
                    "type": "string",
                    "description": "Optional locally known team identity; defaults to the caller's team.",
                },
                "agent_name": {
                    "type": "string",
                    "description": "Optional locally known agent identity; defaults to the caller or known team root.",
                },
                "running_only": {
                    "type": "boolean",
                    "description": "Return only members currently known to be running.",
                },
                "activity_after": {
                    "type": ["number", "string"],
                    "description": "Strict lower activity bound as epoch seconds or RFC3339.",
                },
                "activity_before": {
                    "type": ["number", "string"],
                    "description": "Strict upper activity bound as epoch seconds or RFC3339.",
                },
                "active_within_seconds": {
                    "type": "number",
                    "description": "Inclusive recent activity window in nonnegative seconds.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Positive page size, default 50, maximum 200.",
                },
                "offset": {
                    "type": "integer",
                    "description": "Nonnegative result offset, default 0.",
                },
                "cursor": {
                    "type": "string",
                    "description": "Opaque cursor token for stable pagination continuation. When provided, no other arguments are allowed.",
                },
            },
            "required": [],
            "additionalProperties": False,
        },
    )
    async def search_team(args: dict) -> dict:
        now = time.time()

        # --- Cursor continuation path (Property 2) ---
        cursor_raw = args.get("cursor")
        if cursor_raw is not None:
            cursor_token = str(cursor_raw).strip()
            other_keys = set(args.keys()) - {"cursor"}
            if other_keys:
                return _error_result(
                    "search_team: cursor requests must not include other search arguments"
                )
            entry = _cursor_store.pop(cursor_token, None)
            if entry is None:
                return _error_result("search_team: unknown, expired, or malformed cursor")
            if now - entry.created_at > _CURSOR_TTL_SECONDS:
                return _error_result("search_team: unknown, expired, or malformed cursor")
            page_offset = entry.next_offset
            page = entry.all_members[page_offset: page_offset + entry.limit]
            has_more_cursor = page_offset + len(page) < entry.total_count
            next_cursor_token: str | None = None
            if has_more_cursor:
                next_cursor_token = secrets.token_urlsafe(12)
                _cursor_store[next_cursor_token] = _CursorEntry(
                    created_at=entry.created_at,
                    all_members=entry.all_members,
                    total_count=entry.total_count,
                    limit=entry.limit,
                    mode=entry.mode,
                    team_name=entry.team_name,
                    current_agent=entry.current_agent,
                    target_agent=entry.target_agent,
                    target_lineage=entry.target_lineage,
                    parent_name=entry.parent_name,
                    next_offset=page_offset + len(page),
                )
                _cursor_evict(now)
            cursor_result, cursor_xml = _build_search_result_page(
                page_members=page,
                mode=entry.mode,
                team_name=entry.team_name,
                current_agent=entry.current_agent,
                target_agent=entry.target_agent,
                target_lineage=entry.target_lineage,
                total_matching=entry.total_count,
                offset=page_offset,
                limit=entry.limit,
                parent_name=entry.parent_name,
                next_cursor=next_cursor_token,
            )
            return {
                "content": [{"type": "text", "text": cursor_xml}],
                "tool_use_result": cursor_result,
            }

        mode = str(args.get("mode") or args.get("who") or "family").strip().lower()
        if mode == "all":
            mode = "family"
        if mode == "tree_children":
            mode = "children"
        if mode not in _SEARCH_MODES:
            return _error_result(
                "search_team: 'mode' must be one of: parent, children, siblings, ancestors, descendants, family, tree, tree_children"
            )
        try:
            running_only = _coerce_bool_arg(args.get("running_only", False), name="running_only")
            activity_after = _parse_search_timestamp(args.get("activity_after"), field_name="activity_after")
            activity_before = _parse_search_timestamp(args.get("activity_before"), field_name="activity_before")
            recent_raw = args.get("active_within_seconds")
            if recent_raw is None or (isinstance(recent_raw, str) and not recent_raw.strip()):
                active_within_seconds = None
            elif isinstance(recent_raw, bool):
                raise ValueError("active_within_seconds must be a nonnegative finite number")
            else:
                active_within_seconds = float(recent_raw)
                if not math.isfinite(active_within_seconds) or active_within_seconds < 0:
                    raise ValueError("active_within_seconds must be a nonnegative finite number")
            limit_raw = args.get("limit", 50)
            if isinstance(limit_raw, bool) or (
                isinstance(limit_raw, float) and not limit_raw.is_integer()
            ):
                raise ValueError("limit must be a positive integer no greater than 200")
            limit = int(limit_raw)
            if limit <= 0 or limit > _SEARCH_MAX_LIMIT:
                raise ValueError("limit must be a positive integer no greater than 200")
            offset_raw = args.get("offset", 0)
            if isinstance(offset_raw, bool) or (
                isinstance(offset_raw, float) and not offset_raw.is_integer()
            ):
                raise ValueError("offset must be a nonnegative integer")
            offset = int(offset_raw)
            if offset < 0:
                raise ValueError("offset must be a nonnegative integer")
        except (TypeError, ValueError, OverflowError) as exc:
            return _error_result(f"search_team: {exc}")

        bootstrap = _current_obs_bootstrap()
        if bootstrap is None:
            return _error_result("Cannot use search_team: no OBS bootstrap found")
        if not bootstrap.root_team_key or not bootstrap.agent_name:
            return _error_result("Cannot use search_team: missing team key or agent name")
        if not bootstrap.lineage:
            return _error_result("Cannot use search_team: empty lineage")
        try:
            caller_team = _safe_search_identity(bootstrap.root_team_key, field_name="caller team_name")
            caller_agent = _safe_search_identity(bootstrap.agent_name, field_name="caller agent_name")
            requested_team = _safe_search_identity(args.get("team_name"), field_name="team_name")
            requested_agent = _safe_search_identity(args.get("agent_name"), field_name="agent_name")
        except ValueError as exc:
            return _error_result(f"search_team: {exc}")
        if caller_team is None or caller_agent is None:
            return _error_result("Cannot use search_team: missing team key or agent name")

        def _provider_entries(team_name: str) -> dict[str, dict[str, Any]]:
            provider = getattr(hook_state, "team_status_provider", None) if hook_state is not None else None
            if provider is None:
                return {}
            try:
                # Select the legacy positional convention before invoking the
                # provider. Retrying after TypeError would call a broken provider
                # twice and mistake its implementation error for an API mismatch.
                use_positional_argument = False
                try:
                    provider_signature = inspect.signature(provider)
                except (TypeError, ValueError):
                    provider_signature = None
                if provider_signature is not None:
                    try:
                        provider_signature.bind(team_name=team_name)
                    except TypeError:
                        provider_signature.bind(team_name)
                        use_positional_argument = True
                if use_positional_argument:
                    raw = provider(team_name)
                else:
                    raw = provider(team_name=team_name)
            except Exception:
                logger.debug("search_team runtime provider failed", exc_info=True)
                return {}
            if not isinstance(raw, dict):
                return {}
            entries: dict[str, dict[str, Any]] = {}
            for key, value in raw.items():
                if not isinstance(value, dict):
                    continue
                canonical_team = value.get("team_name")
                canonical_agent = value.get("agent_name")
                if isinstance(key, tuple) and len(key) == 2:
                    canonical_team = canonical_team or key[0]
                    canonical_agent = canonical_agent or key[1]
                if not isinstance(canonical_team, str) or not isinstance(canonical_agent, str):
                    continue
                if canonical_team != team_name:
                    continue
                try:
                    safe_agent = _safe_search_identity(canonical_agent, field_name="agent_name")
                except ValueError:
                    continue
                if safe_agent:
                    entries[safe_agent] = dict(value)
                    entries[safe_agent]["team_name"] = canonical_team
                    entries[safe_agent]["agent_name"] = safe_agent
            return entries

        if requested_agent is not None and requested_team is None:
            team_name = caller_team
        else:
            team_name = requested_team or caller_team
        agent_name = requested_agent or (caller_agent if team_name == caller_team else None)
        try:
            team_projection_metadata = _load_team_projection_metadata(team_name)
            runtime_metadata = _provider_entries(team_name)
            for runtime_agent, runtime_details in runtime_metadata.items():
                projection_details = team_projection_metadata.get(runtime_agent)
                if projection_details is not None:
                    runtime_details.setdefault("lineage", projection_details.get("lineage"))
                    runtime_details.setdefault("display_name", projection_details.get("display_name"))
                    runtime_details.setdefault("parent_agent_name", projection_details.get("parent_agent_name"))
                    runtime_details.setdefault("parent_display_name", projection_details.get("parent_display_name"))
        except (OSError, ValueError) as exc:
            return _error_result(f"search_team: {exc}")
        merged_known = {name: dict(details) for name, details in team_projection_metadata.items()}
        for name, details in runtime_metadata.items():
            merged_known.setdefault(name, {}).update(details)
        if team_name == caller_team and caller_agent not in merged_known:
            merged_known[caller_agent] = {
                "team_name": team_name,
                "agent_name": caller_agent,
                "lineage": list(bootstrap.lineage),
                "lineage_length": len(bootstrap.lineage),
                "display_name": bootstrap.lineage[-1],
            }
        if requested_agent is not None and requested_agent not in merged_known:
            return _error_result("search_team: target identity is not locally known")
        if requested_agent is None and team_name == caller_team and caller_agent in merged_known:
            agent_name = caller_agent
        if agent_name is None:
            root_candidates = [
                name for name, details in merged_known.items()
                if details.get("lineage_length") == 1
                or (isinstance(details.get("lineage"), list) and len(details["lineage"]) == 1)
                or name == team_name
            ]
            root_candidates = sorted(set(root_candidates))
            if len(root_candidates) != 1:
                return _error_result("search_team: team_name has no unambiguous locally known root agent")
            agent_name = root_candidates[0]
        if agent_name not in merged_known:
            return _error_result("search_team: target identity is not locally known")
        target_details = merged_known[agent_name]
        target_lineage_raw = target_details.get("lineage")
        target_lineage = tuple(
            str(item).strip() for item in target_lineage_raw
            if isinstance(item, str) and str(item).strip()
        ) if isinstance(target_lineage_raw, list) else ()
        if not target_lineage and team_name == caller_team and agent_name == caller_agent:
            target_lineage = tuple(bootstrap.lineage)
            target_details["lineage"] = list(target_lineage)
            target_details["lineage_length"] = len(target_lineage)
        if not target_lineage:
            return _error_result("search_team: target identity has no locally known lineage")
        target_details["team_name"] = team_name
        target_details["agent_name"] = agent_name
        target_details["root_team_key"] = target_details.get("root_team_key") or team_name
        inboxes_dir = Path.home() / ".claude" / "teams" / team_name / "inboxes"
        all_agents = set(merged_known)
        if inboxes_dir.is_dir():
            try:
                for path in inboxes_dir.iterdir():
                    if path.suffix != ".json":
                        continue
                    try:
                        inbox_agent = _safe_search_identity(path.stem, field_name="agent_name")
                    except ValueError:
                        continue
                    if inbox_agent is not None:
                        all_agents.add(inbox_agent)
            except OSError:
                pass
        all_agents.add(agent_name)
        for name in all_agents:
            merged_known.setdefault(name, {"team_name": team_name, "agent_name": name})

        session_ids = {
            str(details["session_id"]).strip()
            for details in merged_known.values()
            if isinstance(details.get("session_id"), str) and details["session_id"].strip()
        }
        session_paths = find_session_jsonl_index(
            session_ids=session_ids,
            cwd=config.vault_path,
        )
        # obs-54: reading the members' session files is file and CPU work;
        # keep it off the event loop that serves every topic and agent.
        jsonl_activity = await asyncio.get_running_loop().run_in_executor(
            _jsonl_scan_executor(),
            _jsonl_activities,
            [path for path in session_paths.values() if path is not None],
        )
        for name, details in merged_known.items():
            details["team_name"] = team_name
            details["agent_name"] = name
            session_id = details.get("session_id")
            if isinstance(session_id, str) and session_id.strip():
                session_id = session_id.strip()
                details["session_id"] = session_id
                path = session_paths.get(session_id)
            else:
                # Provider records are best-effort metadata. A malformed ID
                # must neither become a dictionary key nor leak into results.
                details.pop("session_id", None)
                path = None
            activity_epoch = None
            activity_source = "unknown"
            if path is not None:
                activity_epoch, activity_source = jsonl_activity.get(path, (None, "unknown"))
            if activity_epoch is None:
                activity_epoch, activity_source = _activity_fallback(details)
            details["last_activity_source"] = activity_source
            if activity_epoch is not None and math.isfinite(activity_epoch):
                details["last_activity_epoch"] = activity_epoch
                details["last_activity_at"] = datetime.fromtimestamp(
                    activity_epoch,
                    tz=timezone.utc,
                ).isoformat(timespec="microseconds").replace("+00:00", "Z")
            else:
                details.pop("last_activity_epoch", None)
                details.pop("last_activity_at", None)
            running = details.get("running")
            if not isinstance(running, bool):
                running = None
            details["running"] = running
            runtime_status = details.get("runtime_status")
            if not isinstance(runtime_status, str) or runtime_status not in {
                "running", "idle", "completed", "failed", "stopped", "unknown",
            }:
                runtime_status = "running" if running is True else "unknown"
            details["runtime_status"] = runtime_status
            if "task_status" not in details and isinstance(details.get("status"), str):
                details["task_status"] = details["status"]
            if "display_name" not in details:
                details["display_name"] = name.replace("-", " ")
            if isinstance(details.get("lineage"), tuple):
                details["lineage"] = list(details["lineage"])
            if isinstance(details.get("lineage"), list):
                details["lineage_length"] = len(details["lineage"])

        my_lineage = target_lineage
        my_agent_name = agent_name
        my_hash = lineage_fingerprint(tuple(normalize_lineage_name(n) for n in my_lineage))

        def _sort_member_names(names: list[str]) -> list[str]:
            return sorted(names, key=lambda name: _member_activity_sort_key(merged_known.get(name) or {}, name))

        children = _sort_member_names([
            name for name in all_agents
            if name.startswith(f"{my_hash}-") and name != my_agent_name
        ])
        parent: str | None = None
        if len(my_lineage) > 1:
            parent_name = target_details.get("parent_agent_name")
            if not isinstance(parent_name, str) or not parent_name.strip():
                parent_name = agent_name_for_lineage(my_lineage[:-1], team_key=team_name)
            if parent_name in all_agents:
                parent = parent_name
        siblings: list[str] = []
        if len(my_lineage) > 1:
            parent_hash = lineage_fingerprint(tuple(normalize_lineage_name(n) for n in my_lineage[:-1]))
            siblings = _sort_member_names([
                name for name in all_agents
                if name.startswith(f"{parent_hash}-") and name != my_agent_name
            ])
        ancestors: list[str] = []
        for ancestor_length in range(1, len(my_lineage)):
            ancestor_name = agent_name_for_lineage(
                my_lineage[:ancestor_length], team_key=team_name
            )
            # Lineage can outlive a deleted or unavailable projection record.
            # Return only locally known members, as the other relation modes do.
            if ancestor_name in all_agents:
                ancestors.append(ancestor_name)
        descendants = _sort_member_names([
            name for name, details in merged_known.items()
            if isinstance(details.get("lineage"), list)
            and len(details["lineage"]) > len(my_lineage)
            and tuple(details["lineage"][: len(my_lineage)]) == my_lineage
        ])

        relation_members: list[str]
        relation_by_name: dict[str, str] = {}
        if mode == "parent":
            relation_members = [parent] if parent is not None else []
            if parent is not None:
                relation_by_name[parent] = "parent"
        elif mode == "children":
            relation_members = children
            relation_by_name.update({name: "child" for name in children})
        elif mode == "siblings":
            relation_members = siblings
            relation_by_name.update({name: "sibling" for name in siblings})
        elif mode == "ancestors":
            relation_members = ancestors
            relation_by_name.update({name: "ancestor" for name in ancestors})
        elif mode == "descendants":
            relation_members = descendants
            relation_by_name.update({name: "descendant" for name in descendants})
        elif mode == "family":
            relation_members = ([parent] if parent is not None else []) + children + siblings
            relation_by_name.update({name: "child" for name in children})
            relation_by_name.update({name: "sibling" for name in siblings})
            if parent is not None:
                relation_by_name[parent] = "parent"
        else:
            relation_members = sorted(all_agents)
            relation_by_name[my_agent_name] = "self"
            if parent is not None:
                relation_by_name[parent] = "parent"
            relation_by_name.update({name: "child" for name in children})
            relation_by_name.update({name: "sibling" for name in siblings})
            for name in relation_members:
                relation_by_name.setdefault(name, "tree")

        activity_filter_active = (
            activity_after is not None or activity_before is not None or active_within_seconds is not None
        )
        filtered_members: list[str] = []
        for name in relation_members:
            details = merged_known[name]
            epoch = details.get("last_activity_epoch")
            if running_only and details.get("running") is not True:
                continue
            if activity_filter_active and not isinstance(epoch, (int, float)):
                continue
            if activity_after is not None and not float(epoch) > activity_after:
                continue
            if activity_before is not None and not float(epoch) < activity_before:
                continue
            if active_within_seconds is not None and float(epoch) < now - active_within_seconds:
                continue
            filtered_members.append(name)
        filtered_members.sort(key=lambda name: _member_activity_sort_key(merged_known[name], name))
        total_matching = len(filtered_members)
        page_names = filtered_members[offset: offset + limit]

        def _detailed_member(name: str) -> dict[str, Any]:
            # A cursor promises a frozen snapshot, including nested lineage and
            # provider metadata that may change after the first page is returned.
            details = deepcopy(merged_known[name])
            details["relation"] = relation_by_name.get(name, "tree")
            details["agent_name"] = name
            details["team_name"] = team_name
            return details

        page_members = [_detailed_member(name) for name in page_names]
        has_more = offset + len(page_members) < total_matching

        # --- Cursor snapshot creation (Property 2) ---
        live_next_cursor: str | None = None
        if has_more:
            all_detailed = [_detailed_member(name) for name in filtered_members]
            snap_now = time.time()
            live_next_cursor = secrets.token_urlsafe(12)
            _cursor_store[live_next_cursor] = _CursorEntry(
                created_at=snap_now,
                all_members=all_detailed,
                total_count=total_matching,
                limit=limit,
                mode=mode,
                team_name=team_name,
                current_agent=caller_agent,
                target_agent=my_agent_name,
                target_lineage=list(my_lineage),
                parent_name=parent,
                next_offset=offset + len(page_members),
            )
            _cursor_evict(snap_now)

        result, xml_text = _build_search_result_page(
            page_members=page_members,
            mode=mode,
            team_name=team_name,
            current_agent=caller_agent,
            target_agent=my_agent_name,
            target_lineage=list(my_lineage),
            total_matching=total_matching,
            offset=offset,
            limit=limit,
            parent_name=parent,
            next_cursor=live_next_cursor,
        )
        return {
            "content": [{"type": "text", "text": xml_text}],
            "tool_use_result": result,
        }

    @tool(
        "PlaceholderTool",
        "A placeholder tool whose behavior is defined by hooks. "
        "Call this tool when instructed by the system or a procedure. "
        "A pre-tool-use hook intercepts the call and provides the actual implementation.",
        {
            "action": {
                "type": "string",
                "description": "The action to perform.",
            },
            "input": {
                "type": "string",
                "description": "Free-form input for the action.",
            },
        },
    )
    async def placeholder_tool(args: dict) -> dict:
        action = str(args.get("action", "")).strip()
        tool_input = str(args.get("input", "")).strip()
        return {
            "content": [
                {
                    "type": "text",
                    "text": f"PlaceholderTool executed: action={action!r}, input={tool_input!r}",
                }
            ],
        }

    tools = [
            agent_task,
            agent_task_output,
            agent_task_stop,
            cron_create,
            cron_list,
            cron_delete,
            send_inbox_message,
            read_inbox,
            session_info,
            context_info,
            session_lineage,
            search_team,
            placeholder_tool,
    ]
    if return_tools:
        # The external control channel (control.py, vault-h667) calls these same handlers so
        # every guard of the agent tools applies to externally triggered actions too.
        return tools
    server = create_sdk_mcp_server("obs-agent", tools=tools)
    return server
