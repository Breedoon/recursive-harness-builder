"""JSONL-backed context usage extraction for stable occupancy estimates."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import stat
from typing import Any


@dataclass(frozen=True)
class JsonlUsageSnapshot:
    """Latest usage snapshot from a session JSONL assistant entry."""

    source_path: Path
    assistant_entries: int
    usage_entries: int
    latest_input_tokens: int
    latest_output_tokens: int
    latest_cache_creation_input_tokens: int
    latest_cache_read_input_tokens: int
    latest_total_tokens_billed: int
    latest_context_triplet_tokens: int
    recent_peak_context_triplet_tokens: int
    session_peak_context_triplet_tokens: int
    text_estimate_tokens: int = 0
    context_estimate_source: str = "jsonl_latest_triplet"


def _as_int(value: Any) -> int:
    """Accept only nonnegative integer token counts, not JSON booleans."""
    if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
        return value
    return 0


def _content_char_count(value: Any) -> int:
    """Approximate text-bearing transcript content length."""
    if isinstance(value, str):
        return len(value)
    if isinstance(value, list):
        total = 0
        for item in value:
            total += _content_char_count(item)
        return total
    if isinstance(value, dict):
        total = 0
        for key in ("text", "content", "thinking"):
            if key in value:
                total += _content_char_count(value.get(key))
        if total:
            return total
        try:
            return len(json.dumps(value, ensure_ascii=False))
        except TypeError:
            return 0
    return 0


def _estimate_tokens_from_chars(char_count: int) -> int:
    if char_count <= 0:
        return 0
    return max(1, int(round(char_count / 4)))


def _encode_project_path(cwd: Path) -> str:
    """Encode a workspace path like Claude CLI project directory names."""
    resolved = str(cwd.expanduser().resolve(strict=False))
    slug = re.sub(r"[^A-Za-z0-9]", "-", resolved)
    return re.sub(r"-{2,}", "-", slug) or "-"


def _projects_root(projects_root: Path | None) -> Path:
    if projects_root is not None:
        return projects_root
    return Path.home() / ".claude" / "projects"


def _session_file_mtime(path: Path) -> float | None:
    """Observe a regular file once; concurrent cleanup must not abort a batch."""
    try:
        metadata = path.stat()
    except OSError:
        return None
    if not stat.S_ISREG(metadata.st_mode):
        return None
    return metadata.st_mtime


def find_session_jsonl_index(
    *,
    session_ids: set[str],
    cwd: Path,
    projects_root: Path | None = None,
) -> dict[str, Path | None]:
    """Resolve session basenames with one best-effort project-directory scan.

    The current workspace wins over any fallback, even a newer one. Otherwise,
    choose the newest readable candidate, using its path to break timestamp ties.
    Invalid identifiers stay unresolved; they must never become filesystem paths.
    """
    requested = {
        session_id for session_id in session_ids
        if isinstance(session_id, str) and session_id
    }
    resolved: dict[str, Path | None] = {session_id: None for session_id in requested}
    remaining = {
        session_id for session_id in requested
        if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", session_id)
    }
    if not remaining:
        return resolved

    root = _projects_root(projects_root)
    try:
        if not root.is_dir():
            return resolved
    except OSError:
        return resolved

    preferred_dir = root / _encode_project_path(cwd)
    for session_id in remaining.copy():
        preferred = preferred_dir / f"{session_id}.jsonl"
        if _session_file_mtime(preferred) is not None:
            resolved[session_id] = preferred
            remaining.remove(session_id)
    if not remaining:
        return resolved

    # Store the observed ranking rather than stat-ing candidates again in a sort.
    # A disappearing or inaccessible file must not erase another valid result.
    best_ranks: dict[str, tuple[float, str]] = {}
    try:
        for project_dir in root.iterdir():
            try:
                if not project_dir.is_dir():
                    continue
            except OSError:
                continue
            for session_id in remaining:
                candidate = project_dir / f"{session_id}.jsonl"
                modified_at = _session_file_mtime(candidate)
                if modified_at is None:
                    continue
                rank = (modified_at, str(candidate))
                previous_rank = best_ranks.get(session_id)
                if previous_rank is None or rank > previous_rank:
                    best_ranks[session_id] = rank
                    resolved[session_id] = candidate
    except OSError:
        # Keep results already observed if the directory iterator itself fails.
        pass
    return resolved


def find_session_jsonl(
    *,
    session_id: str,
    cwd: Path,
    projects_root: Path | None = None,
) -> Path | None:
    """Find session JSONL, preferring the current workspace project directory."""
    return find_session_jsonl_index(
        session_ids={session_id},
        cwd=cwd,
        projects_root=projects_root,
    ).get(session_id)


_CONVERSATION_ROW_TYPES = frozenset({"user", "assistant"})


def session_jsonl_has_conversation(
    *,
    session_id: str,
    cwd: Path,
    projects_root: Path | None = None,
) -> bool | None:
    """Whether the CLI can resume this session yet: True, False, or None (no file).

    OBS learns a session id from the CLI's ``system/init`` message, before the
    first API call (vault-1i53). The CLI writes a turn's user row together with
    its first assistant content block, so until then the session's JSONL holds
    only ``queue-operation`` rows and ``--resume`` fails with "No conversation
    found" (CLI 2.1.59). False means the file exists and has no user/assistant
    row; the scan stops at the first such row, which is near the top.
    """
    path = find_session_jsonl(session_id=session_id, cwd=cwd, projects_root=projects_root)
    if path is None:
        return None
    try:
        with path.open("rb") as handle:
            for raw in handle:
                if b'"type"' not in raw:
                    continue
                try:
                    entry = json.loads(raw)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue
                if isinstance(entry, dict) and entry.get("type") in _CONVERSATION_ROW_TYPES:
                    return True
    except OSError:
        return None
    return False


def load_jsonl_usage_snapshot(
    *,
    session_id: str | None,
    cwd: Path | None,
    projects_root: Path | None = None,
    recent_window: int = 8,
) -> JsonlUsageSnapshot | None:
    """Load latest same-session assistant usage metrics from JSONL."""
    if not session_id or cwd is None:
        return None

    path = find_session_jsonl(session_id=session_id, cwd=cwd, projects_root=projects_root)
    if path is None:
        return None

    assistant_entries = 0
    usage_totals: list[tuple[int, int, int, int, int]] = []
    # tuples: (input, output, cache_creation, cache_read, triplet_total)
    text_char_count = 0
    events: dict[str, tuple[str, int, tuple[int, int, int, int, int] | None]] = {}

    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line_no, line in enumerate(handle, 1):
                raw = line.strip()
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                except (ValueError, RecursionError):
                    continue

                # Valid JSON is not necessarily a transcript event. Corrupt or
                # foreign records must not hide usable events later in the file.
                if not isinstance(obj, dict):
                    continue
                event_type = obj.get("type")
                if not isinstance(event_type, str) or event_type not in {"assistant", "user"}:
                    continue
                message = obj.get("message")
                if not isinstance(message, dict):
                    continue
                try:
                    chars = _content_char_count(message.get("content"))
                except RecursionError:
                    chars = 0
                entry_uuid = obj.get("uuid")
                key = entry_uuid if isinstance(entry_uuid, str) and entry_uuid else f"line:{line_no}"
                # Last UUID payload wins without moving its original event order.
                events[key] = (event_type, chars, None)
                if event_type != "assistant":
                    continue

                usage = message.get("usage")
                if not isinstance(usage, dict):
                    continue

                input_tokens = _as_int(usage.get("input_tokens"))
                output_tokens = _as_int(usage.get("output_tokens"))
                cache_creation = _as_int(usage.get("cache_creation_input_tokens"))
                cache_read = _as_int(usage.get("cache_read_input_tokens"))
                triplet_total = input_tokens + cache_creation + cache_read
                events[key] = (event_type, chars, (input_tokens, output_tokens, cache_creation, cache_read, triplet_total))
    except OSError:
        return None

    assistant_entries = sum(kind == "assistant" for kind, _chars, _usage in events.values())
    text_char_count = sum(chars for _kind, chars, _usage in events.values())
    usage_totals = [usage for _kind, _chars, usage in events.values() if usage is not None]
    text_estimate_tokens = _estimate_tokens_from_chars(text_char_count)
    informative_usage_totals = [total for total in usage_totals if total[4] > 0]
    if informative_usage_totals:
        latest = informative_usage_totals[-1]
        context_estimate_source = (
            "jsonl_latest_triplet"
            if usage_totals and usage_totals[-1] == latest
            else "jsonl_latest_positive_triplet"
        )
    elif text_estimate_tokens > 0:
        latest = (0, 0, 0, 0, text_estimate_tokens)
        context_estimate_source = "jsonl_text_estimate"
    else:
        return None

    recent_slice = usage_totals[-max(1, recent_window) :]
    recent_peak = max([total[4] for total in recent_slice] + [latest[4]])
    session_peak = max([total[4] for total in usage_totals] + [latest[4]])
    latest_total_billed = latest[0] + latest[1] + latest[2] + latest[3]

    return JsonlUsageSnapshot(
        source_path=path,
        assistant_entries=assistant_entries,
        usage_entries=len(usage_totals),
        latest_input_tokens=latest[0],
        latest_output_tokens=latest[1],
        latest_cache_creation_input_tokens=latest[2],
        latest_cache_read_input_tokens=latest[3],
        latest_total_tokens_billed=latest_total_billed,
        latest_context_triplet_tokens=latest[4],
        recent_peak_context_triplet_tokens=recent_peak,
        session_peak_context_triplet_tokens=session_peak,
        text_estimate_tokens=text_estimate_tokens,
        context_estimate_source=context_estimate_source,
    )
