"""Canonical lineage/bootstrap helpers for multi-level Telegram agent trees.

Naming convention (two-tier):
  - **agent_name**: the routing/machine name (e.g., ``"6b25cfc451-fix"``).
    Used for inbox files, messaging (sender/recipient), team config, env vars.
    Deterministically derived from the lineage via :func:`agent_name_for_lineage`.
  - **display_name**: the human-readable label (e.g., ``"Fix New Teams"``).
    Used for topic titles, lineage XML node labels, user-facing text.
"""

from __future__ import annotations

# CACHE-PREFIX WARNING: lineage/bootstrap payloads belong in append-only
# JSONL-visible context, not regenerated historical messages on fork/resume.
# Stable identity must survive new-process replay; transient values append.
# A break is silent: no error, the API just re-bills the whole conversation.
# Live check: scripts/cache_regression.py resume_new_proc parallel_fork (docs/cache-proxy-safety.md).

import functools
import hashlib
import json
import re
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence

from obs_agent.append_scan import AppendScanCache
from obs_agent.context_jsonl import find_session_jsonl

_OBS_BOOTSTRAP_RE = re.compile(
    r"(?s)(<obs-bootstrap\b[^>]*>.*?</obs-bootstrap>)"
)
_NON_ALNUM_RE = re.compile(r"[^A-Za-z0-9]+")
_ROOT_TEAM_KEY_RE = re.compile(
    r"^(?P<date>\d{4}-\d{2}-\d{2})-(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<slug>.+)$"
)


@dataclass(frozen=True)
class ObsBootstrap:
    """Parsed canonical bootstrap payload."""

    raw_xml: str
    lineage: tuple[str, ...]
    origin: str
    is_fork: bool
    session_id: str | None
    agent_id: str | None
    parent_session_id: str | None
    root_team_key: str | None
    agent_name: str | None
    parent_agent_name: str | None
    parent_display_name: str | None

    def __getattr__(self, name: str) -> Any:
        if name == "native_agent_name":
            return self.agent_name
        raise AttributeError(name)


@dataclass(frozen=True)
class AgentIdentity:
    """Who an agent is: stable across every conversation branch it owns.

    vault-mngu ADR (2026-10-20): an agent's identity (root team key, agent
    name, lineage) is separate from the conversation branch (session JSONL)
    currently carrying it. Replying to an earlier message in the same topic
    starts a new *branch* of the same agent; it must never mint a new
    identity. Only AgentTask/``/fork`` create new agents.
    """

    root_team_key: str
    agent_name: str
    lineage: tuple[str, ...]


@dataclass(frozen=True)
class ConversationBranch:
    """One conversation branch of an agent: a session JSONL forked at a point."""

    session_id: str
    parent_session_id: str | None
    fork_point_uuid: str | None
    identity: AgentIdentity


def normalize_lineage_name(value: str | None) -> str:
    """Collapse whitespace and trim a lineage node label."""
    normalized = " ".join((value or "").split()).strip()
    return normalized


def slugify_projection_label(value: str | None, *, fallback: str) -> str:
    """Build a filesystem-safe slug for flat team/inbox projection."""
    normalized = normalize_lineage_name(value)
    slug = _NON_ALNUM_RE.sub("-", normalized).strip("-").lower()
    return slug or fallback


def lineage_fingerprint(lineage: Sequence[str]) -> str:
    """Return a short stable digest for a lineage."""
    digest = hashlib.sha1("\x1f".join(lineage).encode("utf-8")).hexdigest()
    return digest[:10]


def root_team_key_for_lineage(
    lineage: Sequence[str],
    *,
    timestamp: float | None = None,
) -> str:
    """Project a lineage tree onto a timestamp-based root team key.

    Format: ``YYYY-MM-DD-HH-MM-{slug}``

    *timestamp* defaults to the current UTC time.  Passing an explicit value
    makes the result deterministic (useful for tests and for idempotent
    restores from persisted state).
    """
    if not lineage:
        return "0000-00-00-00-00-root"
    root = normalize_lineage_name(lineage[0])
    slug = slugify_projection_label(root, fallback="root")
    ts = timestamp if timestamp is not None else time.time()
    dt = datetime.fromtimestamp(ts, tz=timezone.utc)
    prefix = dt.strftime("%Y-%m-%d-%H-%M")
    return f"{prefix}-{slug}"


def format_root_display_name(
    root_team_key: str | None,
    display_name: str | None,
) -> str:
    """Return the user-facing trunk display name, including the team timestamp."""
    normalized = normalize_lineage_name(display_name)
    if not normalized:
        return normalized
    match = _ROOT_TEAM_KEY_RE.match((root_team_key or "").strip())
    if match is None:
        return normalized
    prefix = f"{match.group('date')} {match.group('hour')}-{match.group('minute')}"
    if normalized.startswith(f"{prefix} "):
        return normalized
    return f"{prefix} {normalized}"


def strip_root_display_timestamp(
    display_name: str | None,
    root_team_key: str | None,
) -> str:
    """Recover the canonical trunk lineage name from a timestamped display label."""
    normalized = normalize_lineage_name(display_name)
    if not normalized:
        return normalized
    match = _ROOT_TEAM_KEY_RE.match((root_team_key or "").strip())
    if match is None:
        return normalized
    prefix = f"{match.group('date')} {match.group('hour')}-{match.group('minute')} "
    if normalized.startswith(prefix):
        stripped = normalize_lineage_name(normalized[len(prefix):])
        if stripped:
            return stripped
    return normalized


def agent_name_for_lineage(
    lineage: Sequence[str],
    *,
    team_key: str | None = None,
) -> str:
    """Project a lineage member onto one safe agent name.

    Two-tier naming:
    - **Trunk** (single-element lineage): the team key if provided,
      otherwise just the slug.  In the Telegram runtime the trunk
      agent_name *is* the team key (``_default_team_projection``
      overrides this).
    - **Child** (multi-element lineage): ``{parent_lineage_hash}-{slug}``.
      E.g. ``("Root", "Worker")`` → ``"{hash_of_Root}-worker"``

    The parent hash is the fingerprint of the lineage *up to but not including*
    the leaf, ensuring siblings under the same parent share a prefix while
    same-named children under different parents get unique names.
    """
    if not lineage:
        return "root"
    leaf = normalize_lineage_name(lineage[-1])
    slug = slugify_projection_label(leaf, fallback="node")
    if len(lineage) == 1:
        # Trunk: use team key if provided (matches Telegram runtime),
        # otherwise just the slug.
        return team_key if team_key else slug
    # Child: prefix with parent lineage hash
    parent_lineage = tuple(normalize_lineage_name(n) for n in lineage[:-1])
    parent_hash = lineage_fingerprint(parent_lineage)
    return f"{parent_hash}-{slug}"

def build_obs_bootstrap_xml(
    *,
    lineage: Sequence[str],
    origin: str,
    is_fork: bool,
    session_id: str | None,
    agent_id: str | None = None,
    parent_session_id: str | None = None,
    root_team_key: str | None = None,
    agent_name: str | None = None,
    parent_agent_name: str | None = None,
    parent_display_name: str | None = None,
    **legacy_kwargs: Any,
) -> str:
    """Serialize the canonical OBS bootstrap XML envelope (v2).

    Each ``obs-node`` element carries both a human-readable ``display_name``
    and the machine-safe ``agent_name`` that can be used for messaging.
    """
    legacy_agent_name = legacy_kwargs.pop("native_agent_name", None)
    if legacy_kwargs:
        unexpected = ", ".join(sorted(legacy_kwargs))
        raise TypeError(f"Unexpected keyword argument(s): {unexpected}")
    resolved_agent_name = agent_name or legacy_agent_name
    root = ET.Element("obs-bootstrap", {"version": "2"})
    lineage_el = ET.SubElement(root, "obs-lineage")
    normalized = [normalize_lineage_name(n) for n in lineage]
    for idx, node_name in enumerate(normalized):
        display_name = (
            format_root_display_name(root_team_key, node_name)
            if idx == 0
            else node_name
        )
        attrs: dict[str, str] = {"display_name": display_name}
        sub_lineage = tuple(normalized[: idx + 1])
        computed_name = agent_name_for_lineage(
            sub_lineage,
            team_key=root_team_key if idx == 0 else None,
        )
        # Only the leaf node should use the explicit resolved agent_name.
        # Parent nodes must keep their own projected names, otherwise descendant
        # bootstraps incorrectly show the child's agent_name on ancestor nodes.
        if idx == len(normalized) - 1 and resolved_agent_name:
            attrs["agent_name"] = resolved_agent_name
        else:
            attrs["agent_name"] = computed_name
        ET.SubElement(lineage_el, "obs-node", attrs)

    fork_context = ET.SubElement(root, "fork_context")
    ET.SubElement(fork_context, "origin").text = origin
    ET.SubElement(fork_context, "is_fork").text = "true" if is_fork else "false"
    if agent_id:
        ET.SubElement(fork_context, "agent_id").text = agent_id
    if session_id:
        ET.SubElement(fork_context, "session_id").text = session_id
    if parent_session_id:
        ET.SubElement(fork_context, "parent_session_id").text = parent_session_id

    team_context = ET.SubElement(root, "team_context")
    if root_team_key:
        ET.SubElement(team_context, "root_team_key").text = root_team_key
    if resolved_agent_name:
        ET.SubElement(team_context, "agent_name").text = resolved_agent_name
    if parent_agent_name:
        ET.SubElement(team_context, "parent_agent_name").text = parent_agent_name
    if parent_display_name:
        ET.SubElement(team_context, "parent_display_name").text = parent_display_name

    return ET.tostring(root, encoding="unicode", short_empty_elements=True)


def extract_obs_bootstrap_xml(text: str | None) -> str | None:
    """Return the first bootstrap block found anywhere in *text*."""
    if not text:
        return None
    match = _OBS_BOOTSTRAP_RE.search(text)
    if match is None:
        return None
    return match.group(1)


# obs-54: called for every route's pending bootstrap on each team-status and
# inbox-projection pass. The result is a frozen value of the text alone.
@functools.lru_cache(maxsize=4096)
def parse_obs_bootstrap_xml(xml_text: str) -> ObsBootstrap:
    """Parse a canonical OBS bootstrap XML block."""
    root = ET.fromstring(xml_text)
    if root.tag != "obs-bootstrap":
        raise ValueError(f"Unexpected root tag: {root.tag}")

    fork_context = root.find("fork_context")
    team_context = root.find("team_context")

    def _child_text(parent: ET.Element | None, child_name: str) -> str | None:
        if parent is None:
            return None
        child = parent.find(child_name)
        if child is None or child.text is None:
            return None
        text = child.text.strip()
        return text or None

    root_team_key = _child_text(team_context, "root_team_key")
    lineage_el = root.find("obs-lineage")
    lineage: list[str] = []
    if lineage_el is not None:
        for idx, node in enumerate(lineage_el.findall("obs-node")):
            # v2 uses display_name=, v1 uses name=. Try new first, fall back.
            display = node.attrib.get("display_name") or node.attrib.get("name")
            normalized_display = normalize_lineage_name(display)
            if idx == 0:
                normalized_display = strip_root_display_timestamp(
                    normalized_display,
                    root_team_key,
                )
            lineage.append(normalized_display)

    is_fork_text = (_child_text(fork_context, "is_fork") or "").lower()
    # v2 uses <agent_name>; legacy v1 uses <native_agent_name>. Try new first.
    resolved_agent = (
        _child_text(team_context, "agent_name")
        or _child_text(team_context, "native_agent_name")
    )
    return ObsBootstrap(
        raw_xml=xml_text,
        lineage=tuple(item for item in lineage if item),
        origin=_child_text(fork_context, "origin") or "unknown",
        is_fork=is_fork_text in {"true", "1", "yes", "on"},
        session_id=_child_text(fork_context, "session_id"),
        agent_id=_child_text(fork_context, "agent_id"),
        parent_session_id=_child_text(fork_context, "parent_session_id"),
        root_team_key=root_team_key,
        agent_name=resolved_agent,
        parent_agent_name=_child_text(team_context, "parent_agent_name"),
        parent_display_name=_child_text(team_context, "parent_display_name"),
    )


def obs_bootstrap_to_dict(
    bootstrap: ObsBootstrap,
    *,
    session_id: str | None = None,
    include_xml: bool = False,
) -> dict[str, Any]:
    """Return the JSON-serializable session_lineage payload for a bootstrap."""
    payload: dict[str, Any] = {
        "lineage": list(bootstrap.lineage),
        "lineage_length": len(bootstrap.lineage),
        "origin": bootstrap.origin,
        "is_fork": bootstrap.is_fork,
        "session_id": bootstrap.session_id or session_id,
        "agent_id": bootstrap.agent_id,
        "parent_session_id": bootstrap.parent_session_id,
        "root_team_key": bootstrap.root_team_key,
        "agent_name": bootstrap.agent_name,
        "parent_agent_name": bootstrap.parent_agent_name,
        "parent_display_name": bootstrap.parent_display_name,
        "path": "/".join(bootstrap.lineage),
    }
    payload["agent_names"] = [
        agent_name_for_lineage(
            bootstrap.lineage[: i + 1],
            team_key=bootstrap.root_team_key,
        )
        for i in range(len(bootstrap.lineage))
    ]
    if include_xml:
        payload["xml"] = bootstrap.raw_xml
    return payload


def resolve_obs_bootstrap(
    *,
    pending_xml: str | None = None,
    session_id: str | None = None,
    cwd: str | Path | None = None,
) -> ObsBootstrap | None:
    """Resolve the current bootstrap from pending XML, then session JSONL."""
    if pending_xml:
        try:
            return parse_obs_bootstrap_xml(pending_xml)
        except Exception:
            pass
    if not session_id or cwd is None:
        return None
    return find_latest_obs_bootstrap_for_session(session_id=session_id, cwd=cwd)


def _message_text_blocks(content: Any) -> Iterable[str]:
    if isinstance(content, str):
        yield content
        return
    if not isinstance(content, list):
        return
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            text = block.get("text")
            if isinstance(text, str):
                yield text


def _entry_candidate_texts(entry: dict[str, Any]) -> Iterable[str]:
    entry_type = str(entry.get("type") or "").strip().lower()
    if entry_type == "queue-operation":
        content = entry.get("content")
        if isinstance(content, str):
            yield content
        return

    if entry_type == "system":
        content = entry.get("content")
        if isinstance(content, str):
            yield content
        return

    message = entry.get("message")
    if not isinstance(message, dict):
        return
    role = str(message.get("role") or "").strip().lower()
    if role != "user":
        return
    yield from _message_text_blocks(message.get("content"))


def _fold_latest_bootstrap_xml(latest_xml: str | None, line: str) -> str | None:
    if not line:
        return latest_xml
    try:
        entry = json.loads(line)
    except json.JSONDecodeError:
        return latest_xml
    if not isinstance(entry, dict):
        return latest_xml
    for text in _entry_candidate_texts(entry):
        bootstrap_xml = extract_obs_bootstrap_xml(text)
        if bootstrap_xml:
            latest_xml = bootstrap_xml
    return latest_xml


# obs-54: this scan ran over the whole session JSONL on every stream event of
# every run (_bind_state_session -> _state_inbox_projection), on the event
# loop. Session files only grow, so the latest block found so far is kept with
# the offset it was found at and only appended bytes are read. A line can only
# hold a block if the raw line contains the tag name, so other lines are not
# JSON-parsed at all (JSON escaping never touches ASCII letters or "-"); every
# line is still decoded, so an undecodable transcript raises as before.
_bootstrap_scan_cache: AppendScanCache[str | None] = AppendScanCache(
    _fold_latest_bootstrap_xml, None, needle="obs-bootstrap",
)


def find_latest_obs_bootstrap_in_jsonl(path: Path) -> ObsBootstrap | None:
    """Scan a transcript JSONL for the latest canonical bootstrap."""
    latest_xml = _bootstrap_scan_cache.scan(path)
    if latest_xml is None:
        return None
    return parse_obs_bootstrap_xml(latest_xml)


def find_latest_obs_bootstrap_for_session(
    *,
    session_id: str | None,
    cwd: str | Path,
) -> ObsBootstrap | None:
    """Resolve a session JSONL and parse its latest bootstrap block."""
    if not session_id:
        return None
    path = find_session_jsonl(session_id=session_id, cwd=Path(cwd))
    if path is None or not path.exists():
        return None
    return find_latest_obs_bootstrap_in_jsonl(path)


def __getattr__(name: str) -> Any:
    if name == "native_agent_name_for_lineage":
        return agent_name_for_lineage
    raise AttributeError(name)
