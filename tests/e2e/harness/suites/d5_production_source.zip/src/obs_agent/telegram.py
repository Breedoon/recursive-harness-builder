"""Telegram bot for OBS Agent.

Receives messages from Telegram, processes them through ConversationRunner,
and sends chronological per-turn updates. Key behavior:
- FragmentBuffer batches rapid same-user messages and reassembles Telegram auto-split long user text
- Per-turn flush: text + status events are interleaved in arrival order
- Per-chat lock serialization (keeps replies ordered within a chat)
- Background queue poller auto-delivers queued results every 3 seconds
- Final idle context summary is sent with notification enabled once the queue is empty
"""

from __future__ import annotations

import asyncio
import hashlib
import html
import json
import logging
import os
import signal
import random
import re
import shlex
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:
    from croniter import croniter
except Exception:  # pragma: no cover - optional import error surfaced on cron create
    croniter = None

from telegram import Bot, Update
from telegram.constants import ChatAction, ParseMode
from telegram.error import BadRequest, Conflict, NetworkError, RetryAfter, TelegramError, TimedOut
from telegram.ext import Application, ApplicationHandlerStop, CommandHandler, ContextTypes, MessageHandler, filters
from telegram.request import HTTPXRequest

from obs_agent.context_stats import (
    build_context_snapshot,
    format_context_snapshot_compact,
)
from obs_agent.config import (
    normalize_model_for_claude_code,
    parse_context_suffix,
    resolve_model,
)
from obs_agent.events import StatusEvent
from obs_agent.hooks import HookState
from obs_agent.context_jsonl import find_session_jsonl, session_jsonl_has_conversation
from obs_agent.jsonl_health import (
    JsonlSessionHealth,
    futile_refusal_streak,
    is_stale_session_head,
    record_refusal_streak,
    resolve_safe_jsonl_target,
)
from obs_agent.jsonl_fork import fork_session_jsonl, resolve_session_source
from obs_agent import maintenance_restart as _maint
from obs_agent.lineage import (
    AgentIdentity,
    ConversationBranch,
    agent_name_for_lineage,
    build_obs_bootstrap_xml,
    find_latest_obs_bootstrap_for_session,
    format_root_display_name,
    normalize_lineage_name,
    parse_obs_bootstrap_xml,
    root_team_key_for_lineage,
    slugify_projection_label,
)
from obs_agent.queueing import QueuedMessage, coerce_queued_message
from obs_agent.runner import ConversationRunner, DoneEvent, TextEvent, TurnEndEvent
from obs_agent.session import SessionManager
from obs_agent.session_info import (
    SessionViewContext, build_session_info, format_session_info_lines, session_context_window,
)
from obs_agent.telegram_format import md_to_telegram_html, split_message
from obs_agent import schedule_scope as _schedule_scope
from obs_agent import cache_readiness as _cache_readiness
from obs_agent import cache_gate as _cache_gate
from obs_agent import freeze_guard as _freeze_guard
from obs_agent import credit_limit as _credit_limit
from obs_agent import fork_model as _fork_model
from obs_agent.telegram_ingest import TelegramInboundNormalizer
from obs_agent.telegram_state_store import TelegramStateStore
from obs_agent.telegram_userbot import TelegramUserbotProvisioner

if TYPE_CHECKING:
    from obs_agent.config import OBSConfig

logger = logging.getLogger("obs_agent.telegram")

# Delay between sending split message chunks (Telegram rate limit: ~1 msg/sec/chat)
_CHUNK_DELAY_SECONDS = 1.0
_TRANSPORT_BASE_CHAT_INTERVAL_SECONDS = 0.35
_TRANSPORT_MAX_CHAT_INTERVAL_SECONDS = 5.0
_TYPING_ACTION_INTERVAL_SECONDS = 4.0
_OBSERVABILITY_COALESCE_SECONDS = 1.5
# obs-13 instrumentation: an inline observability flush slower than this is logged.
_OBSERVABILITY_SLOW_FLUSH_WARN_SECONDS = 30.0

# Inbound batching quiet period. Hold delivery until no new same-chat/user
# message arrives within this window so forwarded multi-message batches are
# injected together.
_FRAGMENT_MAX_GAP_SECONDS = 1.0

# Only near-limit chunks should be considered Telegram auto-split fragments.
_FRAGMENT_MIN_PART_LENGTH = 4000

# Buffer gap for Telegram media groups/albums.
_MEDIA_GROUP_GAP_SECONDS = 0.75

# Background queue polling interval
_BACKGROUND_POLL_SECONDS = 3.0
# obs-54: the inbox wake poller reuses a parsed inbox while its file is
# unchanged, but only once the file is older than this (coarse fs clocks).
_INBOX_CACHE_SETTLE_SECONDS = 2.0
# obs-54: long synchronous sweeps hand the event loop back this often.
_LOOP_YIELD_EVERY = 256
# obs-54: an unchanged team-config member entry is rewritten at most this often.
_TEAM_PROJECTION_REFRESH_SECONDS = 30.0

# One-shot reminder for the root/main session age.
_MAIN_SESSION_WARNING_SECONDS = 50 * 60.0

# AgentTask lifecycle visibility cadence (parent-topic notifications).
_SUPER_TASK_HEARTBEAT_SECONDS = 15.0
_SUPER_TASK_IDLE_SECONDS = 30.0
_SUPER_TASK_MONITOR_TICK_SECONDS = 1.0
_SCHEDULE_STOP_SUPPRESS_SECONDS = 3.0
_SCHEDULE_IN_PROGRESS_PREFIX = "run in progress, started "
_SCHEDULE_INTERRUPTED_PREFIX = "interrupted: run started "
_SCHEDULE_STOP_MAX_DEFERS = 5
_TASK_OUTPUT_MAX_CHARS = 12_000
_TASK_OUTPUT_SCAN_BYTES = 96_000
_TASK_OUTPUT_MAX_RECORDS = 48
_TASK_OUTPUT_MAX_TEXTS_PER_RECORD = 8
_TASK_OUTPUT_MAX_RECORD_CHARS = 4_000
_TASK_IDENTITY_MAX_CHARS = 256
_SAFE_TEAM_IDENTITY_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-[a-z0-9][a-z0-9_-]{0,127}$"
)
_SAFE_AGENT_IDENTITY_RE = re.compile(
    r"^(?:\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-[a-z0-9][a-z0-9_-]{0,127}|[0-9a-f]{10}-[a-z0-9][a-z0-9-]{0,117})$"
)

# Prompt used when auto-delivering queued background results while user is idle.
_AUTO_DELIVERY_PROMPT = (
    "(System: queued updates arrived while idle. Process and summarize them.)"
)

_TELEGRAM_HELP_TEXT = """Usage:
/help — show this help
/stop — interrupt this topic; /stop all interrupts every running agent in every tree; /stop chat every topic in this chat
/stop_branch — interrupt this agent and all recursive descendants
/stop_tree — interrupt the entire agent tree, including its trunk
/unschedule [branch|tree|all|chat] — remove schedules of this topic, branch, tree, every tree, or this chat; responsibility-owned schedules are kept unless you add --include-protected
/restart — restart OBS and auto-resume agents that were mid-turn (alias /maintenance_restart)
/restart plain — kill-switch restart: nothing is resumed
/restart skip-cache-gate REASON — emergency: restart although cache-sensitive code has no passing cache regression report (logged)
/shutdown — stop OBS only; no agents auto-resume at the next startup
/shutdown_autoresume — stop OBS only; save running agents for one-time resume at the next startup, with no expiry
/fork [name] — create a new topic from this head or a replied message
/new [name] — reset this topic into a new trunk agent
/clear — clear this topic but keep its agent identity
/model MODEL — select the model before the first message of a new or cleared session
/effort [LEVEL] — show/set effort between turns; auto restores the model default
/session — show agent, model, files, runtime and hooks

Bare commands are not supported; use the slash form, e.g. /stop.
""".strip()

_PRIORITY_SYSTEM = 0
_PRIORITY_ASSISTANT = 10
_PRIORITY_OBSERVABILITY = 30
_TOPIC_CREATE_MAX_ATTEMPTS = 3
# obs-54: launch/resume notices retry through 2+4+8+16+30 s of backoff before
# the launch goes on without them (_send_task_launch_notice); was 3 attempts.
_TASK_LAUNCH_SEND_MAX_ATTEMPTS = 6
_RANDOM_TOPIC_WORDS = (
    "amber",
    "atlas",
    "bloom",
    "cinder",
    "copper",
    "dawn",
    "ember",
    "field",
    "forest",
    "harbor",
    "hollow",
    "lattice",
    "meadow",
    "north",
    "orbit",
    "pine",
    "raven",
    "river",
    "signal",
    "silver",
    "stone",
    "summit",
    "tidal",
    "willow",
)

_NEW_GROUP_ALIAS_PATTERN = r"^/new-group(?:@[A-Za-z0-9_]+)?(?:\s|$)"
_NEW_BOT_ALIAS_PATTERN = r"^/new-bot(?:@[A-Za-z0-9_]+)?(?:\s|$)"


# ---------------------------------------------------------------------------
# Queue helpers
# ---------------------------------------------------------------------------

def _drain_queue(queue: asyncio.Queue) -> list[QueuedMessage]:
    """Drain all messages from an asyncio.Queue, returning them as a list."""
    messages: list[QueuedMessage] = []
    while not queue.empty():
        try:
            messages.append(coerce_queued_message(queue.get_nowait()))
        except asyncio.QueueEmpty:
            break
    return messages


def _path_is_within(path: Path, parent: Path) -> bool:
    normalized_path = path.expanduser().resolve(strict=False)
    normalized_parent = parent.expanduser().resolve(strict=False)
    return normalized_path == normalized_parent or normalized_parent in normalized_path.parents


# ---------------------------------------------------------------------------
# FragmentBuffer: reassemble user messages auto-split by Telegram
# ---------------------------------------------------------------------------

@dataclass
class _PendingFragment:
    """A fragment of a split user message waiting for more parts."""

    chat_id: int
    user_id: int
    thread_id: int | None
    last_message_id: int
    segments: list[str] = field(default_factory=list)
    last_seen: float = 0.0
    last_part_length: int = 0
    update: Update | None = None  # The first update (for reply context)
    context: ContextTypes.DEFAULT_TYPE | None = None


@dataclass
class _PendingMediaGroup:
    """A Telegram media group waiting for all items to arrive."""

    chat_id: int
    user_id: int
    thread_id: int | None
    media_group_id: str
    updates: list[Update] = field(default_factory=list)
    last_seen: float = 0.0
    context: ContextTypes.DEFAULT_TYPE | None = None


@dataclass(frozen=True)
class TelegramRoute:
    """Logical Telegram delivery route: one chat + optional topic thread."""

    chat_id: int
    thread_id: int | None = None


@dataclass(frozen=True)
class _TelegramMessageBinding:
    """Maps a Telegram message to a JSONL UUID in a specific session."""

    jsonl_uuid: str
    session_id: str
    role: str
    route: TelegramRoute


@dataclass(frozen=True)
class _ObservabilityChunk:
    """Buffered observability-only render fragment with optional binding data."""

    html_text: str
    jsonl_uuid: str | None
    session_id: str | None


@dataclass
class TelegramSessionState:
    """Runtime state for one Telegram route (DM or forum topic)."""

    route: TelegramRoute
    hook_state: HookState
    session_manager: SessionManager
    pending_messages: list[QueuedMessage] = field(default_factory=list)
    busy: bool = False
    last_bot: object | None = None
    topic_title: str | None = None
    topic_icon_custom_emoji_id: str | None = None
    warning_sent: bool = False
    child_fork_count: int = 0
    child_fork_base_title: str | None = None
    notify_on_completion: bool = True
    active_fork_task_ids: set[str] = field(default_factory=set)
    agent_lineage: tuple[str, ...] | None = None
    pending_obs_bootstrap: str | None = None
    # Inbox wake queueing: when a message arrives while the agent is busy,
    # store the wake request so it fires when the turn completes.
    inbox_wake_pending: bool = False
    inbox_wake_sender: str | None = None
    inbox_wake_summary: str | None = None
    inbox_wake_content: str | None = None
    # Input text of the turn in flight. The crash snapshot records it for a
    # route whose session id is not known yet, so a resume after a crash in
    # the first seconds of a new session does not lose the original request.
    inflight_user_text: str | None = None
    # True while the turn in flight started without a session id, i.e. it is
    # the first turn of a new session (vault-1i53). The session id is known
    # from the CLI's init message soon after, but until the CLI writes the
    # turn's first rows the session cannot be resumed, so the crash snapshot
    # keeps the turn's input for this whole turn and the resume decides from
    # the transcript.
    inflight_first_turn: bool = False

    @property
    def session_id(self) -> str | None:
        return self.session_manager.session_id


class ScheduledPromptFileError(RuntimeError):
    """vault-wlh: a schedule's prompt_file could not be read at fire time."""


class _TopicDeletedError(Exception):
    """Raised when a Telegram topic has been deleted (thread not found)."""

    def __init__(self, route: "TelegramRoute") -> None:
        self.route = route
        super().__init__(f"Topic deleted for route {route}")


class _TelegramPollingConflictError(RuntimeError):
    pass


# obs-52: how many times in a row a route may be recovered from a content
# refusal by a session that answered nothing of its own (a futile retry of the
# same context) before OBS stops and tells the route. Two is the upper end of
# "not ... more than once or twice" (bead obs-52): on 2026-10-25 a
# cybersecurity-flagged route got going again on a retry, the proc-work trunk
# never did.
_CONTENT_REFUSAL_FUTILE_LIMIT = 2
_CONTENT_REFUSAL_LABELS = {
    "usage_policy": "it says the request appears to violate its Usage Policy",
    "cybersecurity_flag": "it flagged the content as a possible cybersecurity risk",
}


class ContentRefusalLoopError(RuntimeError):
    """obs-52: the API keeps refusing this context; recovering again would re-send it.

    The text is stable for one session and kind, so the run-start failure
    notice (deduplicated per session and error) is posted once, not per wake.
    """

    def __init__(self, *, session_id: str, kind: str, futile: int) -> None:
        self.session_id = session_id
        self.kind = kind
        self.futile = futile
        super().__init__(
            f"content refusal ({kind}) of session {session_id}; {futile} attempts in a row were "
            "refused before answering anything, so the same context is not re-sent"
        )

    def notice(self) -> str:
        return (
            "The model provider refused this conversation again "
            f"({_CONTENT_REFUSAL_LABELS.get(self.kind, self.kind)}). {self.futile} attempts in a "
            "row were refused before answering anything, so OBS stopped re-sending the same "
            "context. Nothing was sent to the model for this message; queued agent messages "
            "stay queued. To continue, reply to an earlier message to fork from before the "
            "refused part, or send /clear to start a fresh session."
        )


@dataclass
class _ForkTaskRecord:
    """In-memory lifecycle record for an agent-launched child topic."""

    task_id: str
    parent_route: TelegramRoute
    parent_session_id_at_launch: str
    parent_source_uuid: str
    child_route: TelegramRoute
    child_session_id: str
    prompt: str
    prompt_file: str | None = None
    prompt_file_content: str | None = None
    description: str | None = None
    timeout_ms: int | None = None
    max_turns: int | None = None
    status: str = "launched"
    created_at: float = field(default_factory=time.time)
    completed_at: float | None = None
    launch_parent_message_id: int | None = None
    launch_child_message_id: int | None = None
    child_completion_message_id: int | None = None
    parent_callback_message_id: int | None = None
    error: str | None = None
    terminal_request: str | None = None
    result_text: str | None = None
    tool_use_id: str | None = None
    usage_total_tokens: int | None = None
    usage_tool_uses: int | None = None
    usage_duration_ms: int | None = None
    is_fork: bool = True
    launch_tool_name: str = "ForkTask"
    team_name: str | None = None
    agent_name: str | None = None
    idle_ready: bool = False
    wake_requested: bool = False
    wake_source_sender: str | None = None
    wake_source_summary: str | None = None
    wake_source_content: str | None = None
    emit_parent_callback: bool = True
    # Restored after a maintenance restart or crash while mid-turn and not yet
    # called back: the launching parent is still owed a completion callback.
    # The next run of this child (inbox wake included) delivers it once.
    callback_owed: bool = False


@dataclass
class _IdleClaudeProcessCandidate:
    record: _ForkTaskRecord
    state: TelegramSessionState
    idle_at: float


@dataclass
class _TopicScheduleRecord:
    schedule_id: str
    route: TelegramRoute
    description: str | None
    schedule_mode: str  # interval | cron
    cron_expr: str | None
    trigger_kind: str  # interval | cron | on_topic_stop
    interval_seconds: int | None
    prompt: str
    reset_session: bool = False
    recurring: bool = True
    enabled: bool = True
    run_count: int = 0
    max_runs: int | None = None
    from_ts: float | None = None
    until_ts: float | None = None
    inherit_mode: str = "none"
    next_run_at: float | None = None
    last_run_at: float | None = None
    last_success_at: float | None = None
    last_error: str | None = None
    max_retry_attempts: int = 0
    retry_delay_seconds: int = 30
    retry_attempt_count: int = 0
    # vault-wlh: path (vault-relative, absolute or ~) whose content is read at
    # every fire and appended after ``prompt``; None = inline prompt only.
    prompt_file: str | None = None


def reply_wake_schedule_id(route: TelegramRoute) -> str:
    """Return the deterministic schedule ID for a reply_wake on *route*."""
    thread = route.thread_id if route.thread_id is not None else "general"
    return f"reply-wake-{route.chat_id}-{thread}"


def create_reply_wake_schedule(route: TelegramRoute) -> _TopicScheduleRecord:
    """Create a reply_wake schedule record for *route*.

    Parameters match the design spec: interval_seconds=1, max_runs=3,
    deterministic schedule ID.
    """
    return _TopicScheduleRecord(
        schedule_id=reply_wake_schedule_id(route),
        route=route,
        description="reply_wake: agent has unreplied must_reply messages",
        schedule_mode="interval",
        cron_expr=None,
        trigger_kind="interval",
        interval_seconds=1,
        prompt=(
            "(System: You have messages you haven't replied to. "
            "Check your inbox with ReadInbox and reply to the senders "
            "using SendInboxMessage.)"
        ),
        max_runs=3,
        run_count=0,
    )


def is_reply_wake_schedule(record: _TopicScheduleRecord) -> bool:
    return record.schedule_id.startswith("reply-wake-")


@dataclass(frozen=True)
class _DefaultScheduleTemplate:
    schedule_mode: str
    cron_expr: str | None
    interval_seconds: int | None
    prompt: str
    reset_session: bool
    recurring: bool
    description: str | None
    max_runs: int | None
    from_ts: float | None
    until_ts: float | None
    inherit_mode: str
    max_retry_attempts: int
    retry_delay_seconds: int


_AUTO_DELIVERY_BACKOFF_BASE_SECONDS = 30.0
_AUTO_DELIVERY_BACKOFF_MAX_SECONDS = 30 * 60.0


@dataclass(frozen=True)
class _RunOutcome:
    """Observable outcome for one route run used by ForkTask bookkeeping."""

    assistant_text: str
    failed: bool = False
    error: str | None = None


@dataclass
class _TransportSendOp:
    route: TelegramRoute
    text: str
    disable_notification: bool
    parse_mode: ParseMode | None
    reply_to_message_id: int | None
    fallback_bot: Any | None
    max_attempts: int | None
    future: asyncio.Future


@dataclass
class _TransportDeleteTopicOp:
    route: TelegramRoute
    fallback_bot: Any | None
    future: asyncio.Future


@dataclass
class _TransportCreateTopicOp:
    route: TelegramRoute
    name: str
    icon_custom_emoji_id: str | None
    fallback_bot: Any | None
    future: asyncio.Future


@dataclass
class _TopicMetadata:
    title: str | None = None
    icon_custom_emoji_id: str | None = None


@dataclass(order=True)
class _TransportEnvelope:
    priority: int
    sequence: int
    op: _TransportSendOp | _TransportDeleteTopicOp | _TransportCreateTopicOp = field(compare=False)


class FragmentBuffer:
    """Buffers consecutive Telegram messages from the same user/chat.

    When a user pastes text longer than 4096 chars, Telegram auto-splits it
    into multiple updates with consecutive message_ids sent in rapid succession.
    This buffer also batches separate same-chat/user messages arriving within a
    short quiet period, so forwarded multi-message dumps are injected together.
    Only true near-limit Telegram fragments are concatenated directly; other
    batched messages are separated by paragraph breaks.

    IMPORTANT: add() blocks (awaits) until the message is fully processed.
    This keeps processing within the python-telegram-bot handler context,
    which is required for the SDK's anyio task groups to work correctly.
    """

    def __init__(
        self,
        on_complete,  # async callable(full_text, update, context, *, last_message_id)
        gap_seconds: float = _FRAGMENT_MAX_GAP_SECONDS,
    ) -> None:
        self._on_complete = on_complete
        self._gap = gap_seconds
        self._pending: dict[tuple[int, int, int | None], _PendingFragment] = {}
        self._flush_events: dict[tuple[int, int, int | None], asyncio.Event] = {}

    async def add(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Add an incoming message. Blocks until the message is fully processed."""
        if update.effective_message is None or update.effective_message.text is None:
            return
        if update.effective_user is None:
            return

        chat_id = update.effective_message.chat_id
        user_id = update.effective_user.id
        message_id = update.effective_message.message_id
        text = update.effective_message.text
        now = time.monotonic()
        key = (chat_id, user_id, getattr(update.effective_message, "message_thread_id", None))

        pending = self._pending.get(key)

        if pending is not None:
            within_gap = (now - pending.last_seen) < self._gap
            if within_gap:
                is_fragment = (
                    message_id == pending.last_message_id + 1
                    and pending.last_part_length >= _FRAGMENT_MIN_PART_LENGTH
                )
                if is_fragment:
                    pending.segments[-1] += text
                else:
                    pending.segments.append(text)
                pending.last_message_id = message_id
                pending.last_seen = now
                pending.last_part_length = len(text)
                evt = self._flush_events.get(key)
                if evt is not None:
                    evt.set()
                return
            await self._flush(key)

        done_event = asyncio.Event()
        self._flush_events[key] = done_event
        self._pending[key] = _PendingFragment(
            chat_id=chat_id,
            user_id=user_id,
            last_message_id=message_id,
            segments=[text],
            last_seen=now,
            last_part_length=len(text),
            thread_id=getattr(update.effective_message, "message_thread_id", None),
            update=update,
            context=context,
        )

        while True:
            done_event.clear()
            try:
                await asyncio.wait_for(done_event.wait(), timeout=self._gap)
            except asyncio.TimeoutError:
                break

        await self._flush(key)

    async def _flush(self, key: tuple[int, int, int | None]) -> None:
        """Concatenate pending fragments and deliver to on_complete."""
        pending = self._pending.pop(key, None)
        self._flush_events.pop(key, None)
        if pending is None:
            return

        full_text = "\n\n".join(pending.segments)
        if pending.update is not None and pending.context is not None:
            try:
                await self._on_complete(
                    full_text, pending.update, pending.context,
                    last_message_id=pending.last_message_id,
                )
            except Exception:
                logger.exception("Error in fragment flush callback")


class MediaGroupBuffer:
    """Buffers Telegram media groups so albums become one logical turn."""

    def __init__(self, on_complete, gap_seconds: float = _MEDIA_GROUP_GAP_SECONDS) -> None:
        self._on_complete = on_complete
        self._gap = gap_seconds
        self._pending: dict[tuple[int, int, int | None, str], _PendingMediaGroup] = {}
        self._flush_events: dict[tuple[int, int, int | None, str], asyncio.Event] = {}

    async def add(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_message is None or update.effective_user is None:
            return
        media_group_id = update.effective_message.media_group_id
        if media_group_id is None:
            return

        key = (
            update.effective_message.chat_id,
            update.effective_user.id,
            getattr(update.effective_message, "message_thread_id", None),
            str(media_group_id),
        )
        now = time.monotonic()
        pending = self._pending.get(key)
        if pending is not None:
            pending.updates.append(update)
            pending.last_seen = now
            pending.context = context
            evt = self._flush_events.get(key)
            if evt is not None:
                evt.set()
            return

        done_event = asyncio.Event()
        self._flush_events[key] = done_event
        self._pending[key] = _PendingMediaGroup(
            chat_id=update.effective_message.chat_id,
            user_id=update.effective_user.id,
            thread_id=getattr(update.effective_message, "message_thread_id", None),
            media_group_id=str(media_group_id),
            updates=[update],
            last_seen=now,
            context=context,
        )

        while True:
            done_event.clear()
            try:
                await asyncio.wait_for(done_event.wait(), timeout=self._gap)
            except asyncio.TimeoutError:
                break

        await self._flush(key)

    async def _flush(self, key: tuple[int, int, int | None, str]) -> None:
        pending = self._pending.pop(key, None)
        self._flush_events.pop(key, None)
        if pending is None or pending.context is None:
            return
        try:
            await self._on_complete(pending.updates, pending.context)
        except Exception:
            logger.exception("Error in media-group flush callback")


def _is_killable_cli_pid(pid: object) -> bool:
    """True only for a real child pid; never coerce (int(MagicMock()) == 1 once
    made a stop SIGKILL every descendant of PID 1, 2026-10-16)."""
    return isinstance(pid, int) and not isinstance(pid, bool) and pid > 1 and pid != os.getpid()


class TelegramBot:
    """Telegram bot that wraps ConversationRunner."""

    def __init__(
        self,
        config: OBSConfig,
        *,
        fragment_gap: float = _FRAGMENT_MAX_GAP_SECONDS,
        background_poll_seconds: float = _BACKGROUND_POLL_SECONDS,
        enable_background_poller: bool = True,
        super_task_heartbeat_seconds: float = _SUPER_TASK_HEARTBEAT_SECONDS,
        super_task_idle_seconds: float = _SUPER_TASK_IDLE_SECONDS,
        super_task_monitor_tick_seconds: float = _SUPER_TASK_MONITOR_TICK_SECONDS,
    ) -> None:
        self._config = config
        try:
            self._user_timezone = ZoneInfo(config.user_timezone)
        except ZoneInfoNotFoundError as exc:
            raise ValueError(f"Invalid OBS user timezone: {config.user_timezone}") from exc
        logger.info(
            "schedule_evaluator_loaded code_sha256=%s per_schedule_utc=%s default_timezone=%s",
            hashlib.sha256(self._next_cron_fire_ts.__code__.co_code).hexdigest(),
            "CRON_TZ=UTC " in self._next_cron_fire_ts.__code__.co_consts,
            config.user_timezone,
        )
        if _path_is_within(config.telegram_state_db_path, config.telegram_temp_root):
            raise ValueError(
                "Invalid Telegram state DB path: OBS_TELEGRAM_STATE_DB_PATH must be outside "
                "OBS_TELEGRAM_TEMP_ROOT to avoid startup cleanup deleting persistence data."
            )
        self._fragment_buffer = FragmentBuffer(
            on_complete=self._process_admitted_message, gap_seconds=fragment_gap
        )
        self._media_group_buffer = MediaGroupBuffer(
            on_complete=self._process_media_group,
        )
        self._normalizer = TelegramInboundNormalizer(
            temp_root=config.telegram_temp_root,
            transcription_script=config.telegram_transcription_script,
        )

        self._route_locks: dict[TelegramRoute, asyncio.Lock] = {}
        self._states_by_route: dict[TelegramRoute, TelegramSessionState] = {}
        self._route_by_session_id: dict[str, TelegramRoute] = {}
        self._message_map: dict[tuple[int, int], _TelegramMessageBinding] = {}
        self._session_heads: dict[str, str] = {}
        # route -> (session_id, error) already reported, so retries do not spam the topic.
        self._recovery_failure_notified: dict[TelegramRoute, tuple[str | None, str]] = {}
        self._fork_tasks_by_id: dict[str, _ForkTaskRecord] = {}
        self._fork_task_by_child_route: dict[TelegramRoute, str] = {}
        self._fork_task_tasks: dict[str, asyncio.Task] = {}
        # Detached route-target inbox wakes.  Held by strong reference: asyncio
        # keeps only a weak reference to a running task, so a bare
        # create_task(...) can be garbage-collected mid-flight.
        self._detached_wake_tasks: set[asyncio.Task] = set()
        # Opt-in maintenance restart (see obs_agent.maintenance_restart).
        self._maintenance_resume_task: asyncio.Task | None = None
        self._maintenance_restart_requested = False
        # Injectable for tests; default terminates the process group so
        # supervisord autorestarts OBS exactly like a plain restart.
        self._maintenance_exit_fn: Any = None
        # Crash resume: periodic snapshot of mid-turn routes (crash-resume.json).
        self._crash_snapshot_task: asyncio.Task | None = None
        self._crash_snapshot_disabled = False
        # Consecutive crash resumes per route; guards against crash loops.
        self._crash_resume_counts: dict[TelegramRoute, int] = {}
        # /stop escalation (vault-u3b.65): kill a CLI that ignores the interrupt.
        self._stop_escalation_tasks: set[asyncio.Task] = set()
        self._background_delivery_tasks: dict[TelegramRoute, asyncio.Task] = {}
        # Auto-delivery retry backoff per route: (consecutive failures, next
        # attempt monotonic time). A run that fails the same way every time
        # (torn transcript, vault-qjit) must not retry every poll tick.
        self._auto_delivery_backoff: dict[TelegramRoute, tuple[int, float]] = {}
        self._inbox_wake_poll_task: asyncio.Task | None = None
        self._team_worker_records: dict[tuple[str, str], str] = {}
        self._route_inbox_targets: dict[tuple[str, str], TelegramRoute] = {}
        self._route_inbox_target_keys_by_route: dict[TelegramRoute, tuple[str, str]] = {}
        self._chat_titles: dict[int, str] = {}
        self._daemon_started_at = time.time()
        # Previous daemon's last-alive time (minus slack) when a fresh
        # maintenance marker or crash snapshot shows the restart was not a kill
        # switch; see _inbox_wake_floor (vault-u3b.35).
        self._outage_inbox_floor: float | None = None
        # Dedup set for inbox wake polling — prevents re-triggering the same
        # unread message every poll cycle within this daemon process. Pre-start
        # inbox messages are ignored after daemon restart.
        self._notified_inbox_keys: set[tuple[str, str, str]] = set()
        # inbox path -> (file identity, wake floor, latest unread); see
        # _cached_latest_unread_team_inbox_message (obs-54).
        self._inbox_latest_cache: dict[Path, tuple[tuple[int, ...], float, Any]] = {}
        # (team, agent) -> (member data fingerprint, monotonic write time, config
        # size after the write); see _upsert_team_projection_config (obs-54).
        self._team_projection_written: dict[tuple[str, str], tuple[str, float, int]] = {}
        self._topic_schedules_by_id: dict[str, _TopicScheduleRecord] = {}
        self._pending_schedule_owners: dict[str, tuple[_TopicScheduleRecord, Any]] = {}
        self._pending_schedule_owner_retirements: set[str] = set()
        self._schedule_owner_sweep_pending = False
        self._schedule_owner_repair_task: asyncio.Task | None = None
        self._schedule_ids_by_route: dict[TelegramRoute, set[str]] = {}
        self._schedule_execution_tasks: dict[str, asyncio.Task] = {}
        self._schedule_running_by_route: set[TelegramRoute] = set()
        self._active_schedule_execution_by_route: dict[TelegramRoute, str] = {}
        self._schedule_stop_events: asyncio.Queue[tuple[TelegramRoute, dict[str, Any]]] = asyncio.Queue()
        self._schedule_stop_suppress_until: dict[TelegramRoute, float] = {}
        # vault-ns5: a route whose last turn hit a provider credit limit holds its
        # schedules until this epoch time, so outage fires neither run nor count.
        self._route_credit_limit_until: dict[TelegramRoute, float] = {}
        self._schedule_limit_streak: dict[str, int] = {}
        self._primary_bot: Any | None = None
        self._media_group_receipt_ids: dict[tuple[int, int, int | None, str], list[int]] = {}
        self._settings_payload = self._load_settings_payload()
        self._schedule_retry_max_attempts, self._schedule_retry_delay_seconds = (
            self._load_schedule_retry_policy(self._settings_payload)
        )
        self._default_schedule_template = self._load_default_schedule_template(self._settings_payload)
        self._default_new_chat_hooks = self._load_default_new_chat_hooks(self._settings_payload)

        self._enable_background_poller = enable_background_poller
        self._background_poll_seconds = background_poll_seconds
        self._super_task_heartbeat_seconds = max(float(super_task_heartbeat_seconds), 0.05)
        self._super_task_idle_seconds = max(
            float(super_task_idle_seconds),
            self._super_task_heartbeat_seconds,
        )
        self._super_task_monitor_tick_seconds = max(
            float(super_task_monitor_tick_seconds),
            0.01,
        )
        self._background_task: asyncio.Task | None = None
        self._schedule_poller_task: asyncio.Task | None = None
        self._idle_evict_task: asyncio.Task | None = None
        self._cli_hang_task: asyncio.Task | None = None
        # Loop-stall fix (2026-10-21): last head uuid validated by a per-stream-event
        # refresh, per session. Turn/done/post_run refreshes always re-validate.
        self._event_loop_head_checked: dict[str, str] = {}
        self._control_server: Any | None = None  # external control channel (control.py, vault-h667)
        self._control_start_task: asyncio.Task | None = None
        self._cli_hang_samples: dict[tuple[TelegramRoute, int], dict[str, float | None]] = {}
        self._cli_hang_kills: dict[TelegramRoute, list[float]] = {}
        self._transport_queue: asyncio.PriorityQueue[_TransportEnvelope] = asyncio.PriorityQueue()
        self._transport_sequence = 0
        self._transport_worker_task: asyncio.Task | None = None
        self._chat_next_send_at: dict[int, float] = {}
        self._chat_send_interval: dict[int, float] = {}
        self._chat_pending_ops: dict[int, int] = {}
        self._typing_tasks: dict[int, asyncio.Task] = {}
        self._sender_bots: list[Bot] = []
        self._sender_rr_by_chat: dict[int, int] = {}
        self._sender_chat_blacklist: dict[int, set[int]] = {}
        self._observability_buffer: dict[TelegramRoute, list[_ObservabilityChunk]] = {}
        self._observability_flush_tasks: dict[TelegramRoute, asyncio.Task] = {}
        self._system_message_ids: set[tuple[int, int]] = set()
        self._system_message_routes: dict[tuple[int, int], TelegramRoute] = {}
        self._last_inbound_message_id_by_route: dict[TelegramRoute, int] = {}
        self._pending_inbound_message_ids_by_route: dict[TelegramRoute, set[int]] = {}
        self._topic_metadata_by_route: dict[TelegramRoute, _TopicMetadata] = {}
        self._state_store = TelegramStateStore(config.telegram_state_db_path)
        self._state_store.initialize()
        self._transport_base_chat_interval_seconds = max(
            float(config.telegram_transport_base_chat_interval_seconds),
            0.0,
        )
        self._transport_max_chat_interval_seconds = max(
            float(config.telegram_transport_max_chat_interval_seconds),
            self._transport_base_chat_interval_seconds or _TRANSPORT_MAX_CHAT_INTERVAL_SECONDS,
        )
        self._typing_action_interval_seconds = max(
            float(config.telegram_typing_action_interval_seconds),
            0.5,
        )
        self._typing_actions_enabled = bool(config.telegram_typing_actions_enabled)

    async def initialize_runtime(self) -> None:
        """Purge the Telegram temp root once and create a fresh workspace."""
        self._normalizer.initialize()
        self._state_store.initialize()
        self._state_store.prune(
            retention_days=self._config.telegram_state_retention_days
        )
        self._restore_state_from_store()
        await self._ensure_transport_worker()
        await self._ensure_background_poller(None)

    def _next_transport_sequence(self) -> int:
        self._transport_sequence += 1
        return self._transport_sequence

    async def _ensure_sender_pool(self) -> None:
        if self._sender_bots:
            return
        tokens = self._config.telegram_sender_bot_tokens
        if len(tokens) <= 1:
            return
        # Token[0] is the polling bot handled by python-telegram-bot Application.
        for token in tokens[1:]:
            try:
                self._sender_bots.append(Bot(token=token))
            except Exception:
                logger.warning("Failed creating Telegram sender bot from token", exc_info=True)

    async def _ensure_transport_worker(self) -> None:
        await self._ensure_sender_pool()
        if self._transport_worker_task is not None and not self._transport_worker_task.done():
            return
        self._transport_worker_task = asyncio.create_task(self._transport_worker_loop())

    async def _maybe_stop_transport_worker(self) -> None:
        task = self._transport_worker_task
        if task is None or task.done():
            self._transport_worker_task = None
            return
        if not self._transport_queue.empty():
            return
        if self._chat_pending_ops:
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        self._transport_worker_task = None

    def _increment_pending_chat_ops(self, chat_id: int) -> None:
        self._chat_pending_ops[chat_id] = self._chat_pending_ops.get(chat_id, 0) + 1
        if not self._typing_actions_enabled:
            return
        task = self._typing_tasks.get(chat_id)
        if task is None or task.done():
            self._typing_tasks[chat_id] = asyncio.create_task(self._typing_loop(chat_id))

    def _decrement_pending_chat_ops(self, chat_id: int) -> None:
        remaining = self._chat_pending_ops.get(chat_id, 0) - 1
        if remaining <= 0:
            self._chat_pending_ops.pop(chat_id, None)
            return
        self._chat_pending_ops[chat_id] = remaining

    def _sender_candidates(self, *, fallback_bot: Any | None, chat_id: int) -> list[Any]:
        if fallback_bot is not None and chat_id > 0:
            return [fallback_bot]
        candidates: list[Any] = []
        if fallback_bot is not None:
            candidates.append(fallback_bot)
        for sender in self._sender_bots:
            if all(id(existing) != id(sender) for existing in candidates):
                candidates.append(sender)
        blocked = self._sender_chat_blacklist.get(chat_id, set())
        if blocked:
            candidates = [candidate for candidate in candidates if id(candidate) not in blocked]
        if not candidates and fallback_bot is not None:
            candidates.append(fallback_bot)
        if len(candidates) <= 1:
            return candidates
        start = self._sender_rr_by_chat.get(chat_id, 0) % len(candidates)
        self._sender_rr_by_chat[chat_id] = start + 1
        return candidates[start:] + candidates[:start]

    async def _wait_for_chat_send_slot(self, chat_id: int) -> None:
        next_allowed = self._chat_next_send_at.get(chat_id, 0.0)
        now = time.monotonic()
        if next_allowed > now:
            await asyncio.sleep(next_allowed - now)
            now = time.monotonic()
        interval = self._chat_send_interval.get(chat_id, self._transport_base_chat_interval_seconds)
        self._chat_next_send_at[chat_id] = now + interval

    def _note_chat_send_success(self, chat_id: int) -> None:
        current = self._chat_send_interval.get(chat_id, self._transport_base_chat_interval_seconds)
        if current <= self._transport_base_chat_interval_seconds:
            self._chat_send_interval[chat_id] = self._transport_base_chat_interval_seconds
            return
        # Recover gradually after temporary flood waits.
        self._chat_send_interval[chat_id] = max(
            self._transport_base_chat_interval_seconds,
            current * 0.92,
        )

    def _note_chat_retry_after(self, chat_id: int, delay: float) -> None:
        current = self._chat_send_interval.get(chat_id, self._transport_base_chat_interval_seconds)
        boosted = max(
            current * 1.4,
            min(self._transport_max_chat_interval_seconds, max(1.0, delay / 10.0)),
        )
        self._chat_send_interval[chat_id] = min(self._transport_max_chat_interval_seconds, boosted)

    async def _execute_send_with_retry(self, op: _TransportSendOp):
        candidates = self._sender_candidates(fallback_bot=op.fallback_bot, chat_id=op.route.chat_id)
        if not candidates:
            raise RuntimeError("No Telegram sender bot available")

        attempt = 0
        last_error: Exception | None = None
        max_attempts = op.max_attempts if isinstance(op.max_attempts, int) and op.max_attempts > 0 else None
        while True:
            for candidate in candidates:
                await self._wait_for_chat_send_slot(op.route.chat_id)
                try:
                    sent = await candidate.send_message(
                        chat_id=op.route.chat_id,
                        text=op.text,
                        parse_mode=op.parse_mode,
                        disable_web_page_preview=True,
                        disable_notification=op.disable_notification,
                        reply_to_message_id=op.reply_to_message_id,
                        message_thread_id=op.route.thread_id,
                    )
                    self._note_chat_send_success(op.route.chat_id)
                    return sent
                except RetryAfter as exc:
                    delay = max(float(exc.retry_after), 1.0)
                    attempt += 1
                    if max_attempts is not None and attempt >= max_attempts:
                        raise
                    self._chat_next_send_at[op.route.chat_id] = max(
                        self._chat_next_send_at.get(op.route.chat_id, 0.0),
                        time.monotonic() + delay,
                    )
                    self._note_chat_retry_after(op.route.chat_id, delay)
                    logger.warning(
                        "Telegram rate limit route=%s attempt=%d retry_in=%.1fs",
                        op.route, attempt, delay,
                    )
                    await asyncio.sleep(delay)
                    last_error = exc
                    break
                except BadRequest as exc:
                    msg_lower = str(exc).lower()
                    # Payload/HTML errors are handled by the caller.
                    if "can't parse entities" in msg_lower or "too long" in msg_lower:
                        raise
                    if (
                        op.reply_to_message_id is not None
                        and (
                            "message to be replied not found" in msg_lower
                            or "reply message not found" in msg_lower
                        )
                    ):
                        logger.info(
                            "Telegram reply target missing route=%s reply_to=%s; retrying without reply",
                            op.route,
                            op.reply_to_message_id,
                        )
                        op.reply_to_message_id = None
                        continue
                    if (
                        "not enough rights" in msg_lower
                        or "chat not found" in msg_lower
                        or "bot is not a member" in msg_lower
                    ):
                        self._sender_chat_blacklist.setdefault(op.route.chat_id, set()).add(id(candidate))
                        last_error = exc
                        continue
                    if (
                        "message thread not found" in msg_lower
                        or "topic_deleted" in msg_lower
                        or "topic_closed" in msg_lower
                    ):
                        logger.warning(
                            "Topic deleted/closed for route=%s: %s",
                            op.route,
                            exc,
                        )
                        raise _TopicDeletedError(op.route) from exc
                    raise
                except TelegramError as exc:
                    attempt += 1
                    if max_attempts is not None and attempt >= max_attempts:
                        raise
                    delay = min(30.0, 2 ** min(attempt, 5))
                    logger.warning(
                        "Telegram send failed route=%s attempt=%d retry_in=%.1fs: %s",
                        op.route, attempt, delay, exc,
                    )
                    await asyncio.sleep(delay)
                    last_error = exc
                    break
            else:
                if last_error is not None:
                    raise last_error
                raise RuntimeError("All Telegram sender candidates failed")

    async def _execute_delete_topic_with_retry(self, op: _TransportDeleteTopicOp) -> None:
        if op.route.thread_id is None:
            raise RuntimeError("Cannot delete General topic via transport delete")
        # Topic lifecycle operations require elevated chat permissions.
        # Keep them pinned to the primary polling bot to avoid sender-pool
        # members lacking admin rights (which causes noisy 400 failures).
        candidates = [op.fallback_bot] if op.fallback_bot is not None else []
        if not candidates:
            candidates = self._sender_candidates(fallback_bot=op.fallback_bot, chat_id=op.route.chat_id)
        if not candidates:
            raise RuntimeError("No Telegram sender bot available")
        attempt = 0
        last_error: Exception | None = None
        while True:
            for candidate in candidates:
                await self._wait_for_chat_send_slot(op.route.chat_id)
                try:
                    await candidate.delete_forum_topic(
                        chat_id=op.route.chat_id,
                        message_thread_id=op.route.thread_id,
                    )
                    self._note_chat_send_success(op.route.chat_id)
                    return
                except RetryAfter as exc:
                    delay = max(float(exc.retry_after), 1.0)
                    attempt += 1
                    self._chat_next_send_at[op.route.chat_id] = max(
                        self._chat_next_send_at.get(op.route.chat_id, 0.0),
                        time.monotonic() + delay,
                    )
                    self._note_chat_retry_after(op.route.chat_id, delay)
                    await asyncio.sleep(delay)
                    last_error = exc
                    break
                except TelegramError as exc:
                    attempt += 1
                    delay = min(30.0, 2 ** min(attempt, 5))
                    await asyncio.sleep(delay)
                    last_error = exc
                    break
            else:
                if last_error is not None:
                    raise last_error
                raise RuntimeError("All Telegram sender candidates failed for delete")

    async def _execute_create_topic_with_retry(self, op: _TransportCreateTopicOp):
        # Topic lifecycle operations require elevated chat permissions.
        # Keep them pinned to the primary polling bot to avoid sender-pool
        # members lacking admin rights (which causes noisy 400 failures).
        candidates = [op.fallback_bot] if op.fallback_bot is not None else []
        if not candidates:
            candidates = self._sender_candidates(fallback_bot=op.fallback_bot, chat_id=op.route.chat_id)
        if not candidates:
            raise RuntimeError("No Telegram sender bot available")
        attempt = 0
        last_error: Exception | None = None
        while True:
            for candidate in candidates:
                await self._wait_for_chat_send_slot(op.route.chat_id)
                try:
                    topic = await candidate.create_forum_topic(
                        chat_id=op.route.chat_id,
                        name=op.name,
                        icon_custom_emoji_id=op.icon_custom_emoji_id,
                    )
                    self._note_chat_send_success(op.route.chat_id)
                    return topic
                except RetryAfter as exc:
                    delay = max(float(exc.retry_after), 1.0)
                    attempt += 1
                    if attempt >= _TOPIC_CREATE_MAX_ATTEMPTS:
                        raise RuntimeError(
                            f"Failed to create forum topic '{op.name}' in chat {op.route.chat_id} "
                            f"after {attempt} attempts: {exc}"
                        ) from exc
                    self._chat_next_send_at[op.route.chat_id] = max(
                        self._chat_next_send_at.get(op.route.chat_id, 0.0),
                        time.monotonic() + delay,
                    )
                    self._note_chat_retry_after(op.route.chat_id, delay)
                    logger.warning(
                        "Telegram create_forum_topic rate limit route=%s attempt=%d retry_in=%.1fs",
                        op.route,
                        attempt,
                        delay,
                    )
                    await asyncio.sleep(delay)
                    last_error = exc
                    break
                except TelegramError as exc:
                    attempt += 1
                    if isinstance(exc, BadRequest):
                        raise RuntimeError(
                            f"Failed to create forum topic '{op.name}' in chat {op.route.chat_id}: {exc}. "
                            "AgentTask/ForkTask cannot continue without creating the child topic."
                        ) from exc
                    if attempt >= _TOPIC_CREATE_MAX_ATTEMPTS:
                        raise RuntimeError(
                            f"Failed to create forum topic '{op.name}' in chat {op.route.chat_id} "
                            f"after {attempt} attempts: {exc}"
                        ) from exc
                    delay = min(30.0, 2 ** min(attempt, 5))
                    logger.warning(
                        "Telegram create_forum_topic failed route=%s attempt=%d retry_in=%.1fs: %s",
                        op.route,
                        attempt,
                        delay,
                        exc,
                    )
                    await asyncio.sleep(delay)
                    last_error = exc
                    break
            else:
                if last_error is not None:
                    raise last_error
                raise RuntimeError("All Telegram sender candidates failed for create_topic")

    async def _enqueue_send(
        self,
        *,
        route: TelegramRoute,
        text: str,
        disable_notification: bool,
        parse_mode: ParseMode | None,
        reply_to_message_id: int | None,
        fallback_bot: Any | None,
        priority: int,
        max_attempts: int | None = None,
    ):
        await self._ensure_transport_worker()
        future = asyncio.get_running_loop().create_future()
        self._increment_pending_chat_ops(route.chat_id)
        await self._transport_queue.put(
            _TransportEnvelope(
                priority=priority,
                sequence=self._next_transport_sequence(),
                op=_TransportSendOp(
                    route=route,
                    text=text,
                    disable_notification=disable_notification,
                    parse_mode=parse_mode,
                    reply_to_message_id=reply_to_message_id,
                    fallback_bot=fallback_bot,
                    max_attempts=max_attempts,
                    future=future,
                ),
            )
        )
        try:
            return await future
        except _TopicDeletedError:
            logger.warning(
                "Topic deleted for route=%s — dropping route state and sending bounce-backs",
                route,
            )
            await self._drop_route_state(route, terminal_status="failed")
            await self._send_bounce_backs_for_dead_agent(route)
            return None
        finally:
            await self._maybe_stop_transport_worker()

    async def _enqueue_delete_topic(
        self,
        *,
        route: TelegramRoute,
        fallback_bot: Any | None,
        priority: int = _PRIORITY_SYSTEM,
    ) -> None:
        await self._ensure_transport_worker()
        future = asyncio.get_running_loop().create_future()
        self._increment_pending_chat_ops(route.chat_id)
        await self._transport_queue.put(
            _TransportEnvelope(
                priority=priority,
                sequence=self._next_transport_sequence(),
                op=_TransportDeleteTopicOp(
                    route=route,
                    fallback_bot=fallback_bot,
                    future=future,
                ),
            )
        )
        try:
            await future
        finally:
            await self._maybe_stop_transport_worker()

    async def _enqueue_create_topic(
        self,
        *,
        route: TelegramRoute,
        topic_name: str,
        icon_custom_emoji_id: str | None = None,
        fallback_bot: Any | None,
        priority: int = _PRIORITY_SYSTEM,
    ):
        await self._ensure_transport_worker()
        future = asyncio.get_running_loop().create_future()
        self._increment_pending_chat_ops(route.chat_id)
        await self._transport_queue.put(
            _TransportEnvelope(
                priority=priority,
                sequence=self._next_transport_sequence(),
                op=_TransportCreateTopicOp(
                    route=route,
                    name=topic_name,
                    icon_custom_emoji_id=icon_custom_emoji_id,
                    fallback_bot=fallback_bot,
                    future=future,
                ),
            )
        )
        try:
            return await future
        finally:
            await self._maybe_stop_transport_worker()

    async def _typing_loop(self, chat_id: int) -> None:
        try:
            while self._chat_pending_ops.get(chat_id, 0) > 0:
                next_allowed = self._chat_next_send_at.get(chat_id, 0.0)
                now = time.monotonic()
                if next_allowed > now + 0.5:
                    await asyncio.sleep(min(next_allowed - now, self._typing_action_interval_seconds))
                    continue
                sender = None
                if self._sender_bots:
                    sender = self._sender_candidates(
                        fallback_bot=self._sender_bots[0], chat_id=chat_id
                    )[0]
                for state in self._states_by_route.values():
                    if state.route.chat_id == chat_id and state.last_bot is not None:
                        sender = state.last_bot
                        break
                if sender is not None:
                    try:
                        await sender.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
                    except Exception:
                        logger.debug("typing action failed chat_id=%s", chat_id, exc_info=True)
                remaining = self._typing_action_interval_seconds
                while remaining > 0:
                    if self._chat_pending_ops.get(chat_id, 0) <= 0:
                        break
                    step = min(0.2, remaining)
                    await asyncio.sleep(step)
                    remaining -= step
        finally:
            self._typing_tasks.pop(chat_id, None)

    async def _transport_worker_loop(self) -> None:
        while True:
            try:
                envelope = await self._transport_queue.get()
                op = envelope.op
                try:
                    if isinstance(op, _TransportSendOp):
                        result = await self._execute_send_with_retry(op)
                    elif isinstance(op, _TransportDeleteTopicOp):
                        result = await self._execute_delete_topic_with_retry(op)
                    else:
                        result = await self._execute_create_topic_with_retry(op)
                    if not op.future.done():
                        op.future.set_result(result)
                except Exception as exc:
                    if not op.future.done():
                        op.future.set_exception(exc)
                finally:
                    chat_id = op.route.chat_id
                    self._decrement_pending_chat_ops(chat_id)
                    self._transport_queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("Transport worker loop failed")

    def _route_for_message(self, message) -> TelegramRoute:
        thread_id = getattr(message, "message_thread_id", None)
        if not isinstance(thread_id, int):
            reply_to = getattr(message, "reply_to_message", None)
            if reply_to is not None:
                reply_thread = getattr(reply_to, "message_thread_id", None)
                if isinstance(reply_thread, int):
                    thread_id = reply_thread
        if not isinstance(thread_id, int):
            reply_to = getattr(message, "reply_to", None)
            if reply_to is not None and getattr(reply_to, "forum_topic", False):
                top_id = getattr(reply_to, "reply_to_top_id", None)
                if isinstance(top_id, int):
                    thread_id = top_id
                else:
                    reply_to_msg_id = getattr(reply_to, "reply_to_msg_id", None)
                    if isinstance(reply_to_msg_id, int):
                        thread_id = reply_to_msg_id
        return TelegramRoute(chat_id=message.chat_id, thread_id=thread_id if isinstance(thread_id, int) else None)

    def _default_topic_title(self, route: TelegramRoute) -> str:
        if route.thread_id is None:
            return self._chat_titles.get(route.chat_id) or "General"
        return f"Topic {route.thread_id}"

    @staticmethod
    def _safe_int(value: Any, default: int) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return int(default)

    def _load_settings_payload(self) -> dict[str, Any] | None:
        settings_path = self._config.claude_path / "settings.json"
        if not settings_path.exists():
            return None
        try:
            loaded = json.loads(settings_path.read_text(encoding="utf-8"))
        except Exception:
            logger.warning("Failed parsing settings file at %s", settings_path, exc_info=True)
            return None
        return loaded if isinstance(loaded, dict) else None

    def _load_default_new_chat_hooks(
        self,
        settings: dict[str, Any] | None,
    ) -> dict[str, str] | None:
        if not isinstance(settings, dict):
            return None
        obs = settings.get("obs")
        if not isinstance(obs, dict):
            return None
        sessions = obs.get("sessions")
        if not isinstance(sessions, dict):
            return None
        defaults = sessions.get("defaults")
        if not isinstance(defaults, dict):
            return None
        hooks = defaults.get("hooks")
        if not isinstance(hooks, dict):
            return None

        normalized: dict[str, str] = {}
        for event_name, spec in hooks.items():
            if not isinstance(event_name, str) or not event_name.strip():
                logger.warning("Ignoring obs.sessions.defaults.hooks entry with invalid event name")
                continue
            if not isinstance(spec, str) or not spec.strip():
                logger.warning(
                    "Ignoring obs.sessions.defaults.hooks.%s: hook spec must be a non-empty string",
                    event_name,
                )
                continue
            normalized[event_name.strip()] = spec.strip()
        return normalized or None

    def _load_schedule_retry_policy(self, settings: dict[str, Any] | None) -> tuple[int, int]:
        max_attempts = 0
        delay_seconds = 30
        if not isinstance(settings, dict):
            return max_attempts, delay_seconds
        obs = settings.get("obs")
        if not isinstance(obs, dict):
            return max_attempts, delay_seconds
        scheduling = obs.get("scheduling")
        if not isinstance(scheduling, dict):
            return max_attempts, delay_seconds
        retry = scheduling.get("retry")
        if not isinstance(retry, dict):
            return max_attempts, delay_seconds
        max_attempts = max(self._safe_int(retry.get("max_attempts"), 0), 0)
        delay_seconds = max(self._safe_int(retry.get("delay_seconds"), 30), 1)
        return max_attempts, delay_seconds

    def _parse_default_schedule_template(
        self,
        default_schedule: dict[str, Any],
        *,
        source_label: str,
    ) -> _DefaultScheduleTemplate | None:
        if default_schedule.get("enabled") is False:
            return None
        prompt = str(default_schedule.get("prompt") or "").strip()
        if not prompt:
            logger.warning("Ignoring %s: prompt is required", source_label)
            return None

        schedule_mode = str(default_schedule.get("schedule_mode") or "").strip().lower()
        cron_expr = str(default_schedule.get("cron") or "").strip() or None
        interval_seconds_raw = default_schedule.get("interval_seconds")
        interval_seconds: int | None = None
        if interval_seconds_raw is not None:
            try:
                interval_seconds = int(interval_seconds_raw)
            except (TypeError, ValueError):
                logger.warning("Ignoring %s: interval_seconds must be an integer", source_label)
                return None
            if interval_seconds < 0:
                logger.warning("Ignoring %s: interval_seconds must be non-negative", source_label)
                return None
        if not schedule_mode:
            if interval_seconds is not None:
                schedule_mode = "interval"
            elif cron_expr:
                schedule_mode = "cron"
        if schedule_mode not in {"interval", "cron"}:
            logger.warning("Ignoring %s: schedule_mode must be interval or cron", source_label)
            return None
        if schedule_mode == "interval" and interval_seconds is None:
            logger.warning("Ignoring %s: interval_seconds is required for interval mode", source_label)
            return None
        if schedule_mode == "cron":
            if not cron_expr:
                logger.warning("Ignoring %s: cron is required for cron mode", source_label)
                return None
            if croniter is None:
                logger.warning("Ignoring %s: croniter is required for cron mode", source_label)
                return None
            try:
                self._next_cron_fire_ts(cron_expr=cron_expr, base_ts=time.time())
            except ValueError:
                logger.warning("Ignoring %s: invalid cron expression %s", source_label, cron_expr)
                return None

        reset_session_raw = default_schedule.get("reset_session")
        reset_session = bool(reset_session_raw) if isinstance(reset_session_raw, bool) else False
        if reset_session_raw is None:
            run_mode = str(default_schedule.get("run_mode") or "").strip().lower()
            if run_mode in {"continue", "reset_session"}:
                reset_session = run_mode == "reset_session"
            elif run_mode:
                logger.warning("Ignoring %s: unsupported run_mode %s", source_label, run_mode)
                return None

        max_runs_raw = default_schedule.get("max_runs")
        max_runs: int = 1
        if max_runs_raw is not None:
            try:
                max_runs = int(max_runs_raw)
            except (TypeError, ValueError):
                logger.warning("Ignoring %s: max_runs must be an integer", source_label)
                return None
            if max_runs <= 0:
                logger.warning("Ignoring %s: max_runs must be positive", source_label)
                return None

        from_raw = str(default_schedule.get("from") or "").strip() or None
        until_raw = str(default_schedule.get("until") or "").strip() or None
        try:
            from_ts = self._parse_rfc3339_timestamp(from_raw)
            until_ts = self._parse_rfc3339_timestamp(until_raw)
        except ValueError:
            logger.warning("Ignoring %s: from/until must be RFC3339 timestamp", source_label)
            return None
        if from_ts is not None and until_ts is not None and from_ts > until_ts:
            logger.warning("Ignoring %s: from must be <= until", source_label)
            return None

        inherit_mode = str(default_schedule.get("inherit") or "none").strip().lower() or "none"
        if inherit_mode not in {"none", "fork", "all"}:
            logger.warning("Ignoring %s: inherit must be none, fork, or all", source_label)
            return None

        return _DefaultScheduleTemplate(
            schedule_mode=schedule_mode,
            cron_expr=cron_expr,
            interval_seconds=interval_seconds,
            prompt=prompt,
            reset_session=reset_session,
            recurring=max_runs != 1,
            description=str(default_schedule.get("description") or "").strip() or None,
            max_runs=max_runs,
            from_ts=from_ts,
            until_ts=until_ts,
            inherit_mode=inherit_mode,
            max_retry_attempts=self._schedule_retry_max_attempts,
            retry_delay_seconds=self._schedule_retry_delay_seconds,
        )

    def _load_default_schedule_template(self, settings: dict[str, Any] | None) -> _DefaultScheduleTemplate | None:
        if not isinstance(settings, dict):
            return None

        obs = settings.get("obs")
        if isinstance(obs, dict):
            scheduling = obs.get("scheduling")
            if isinstance(scheduling, dict):
                defaults = scheduling.get("defaults")
                if isinstance(defaults, dict):
                    if defaults.get("auto_create_on_session_start") is False:
                        return None
                    schedule = defaults.get("schedule")
                    if isinstance(schedule, dict):
                        return self._parse_default_schedule_template(
                            schedule,
                            source_label="obs.scheduling.defaults.schedule",
                        )

        obs_agent = settings.get("obs_agent")
        if not isinstance(obs_agent, dict):
            return None
        schedule_defaults = obs_agent.get("schedule_defaults")
        if not isinstance(schedule_defaults, dict):
            return None
        if schedule_defaults.get("auto_create_on_session_start") is False:
            return None
        legacy = schedule_defaults.get("default_interval")
        if not isinstance(legacy, dict):
            return None
        logger.warning(
            "settings.json uses deprecated obs_agent.schedule_defaults; migrate to obs.scheduling.defaults"
        )
        normalized = dict(legacy)
        if "schedule_mode" not in normalized:
            normalized["schedule_mode"] = "interval"
        return self._parse_default_schedule_template(
            normalized,
            source_label="obs_agent.schedule_defaults.default_interval",
        )

    def _maybe_seed_default_schedule(self, *, route: TelegramRoute) -> None:
        template = self._default_schedule_template
        if template is None:
            return
        if self._schedule_ids_by_route.get(route):
            return
        now = time.time()
        trigger_kind = "on_topic_stop"
        if template.schedule_mode == "cron":
            trigger_kind = "cron"
        elif template.interval_seconds and template.interval_seconds > 0:
            trigger_kind = "interval"
        record = _TopicScheduleRecord(
            schedule_id=uuid.uuid4().hex[:8],
            route=route,
            description=template.description,
            schedule_mode=template.schedule_mode,
            cron_expr=template.cron_expr,
            trigger_kind=trigger_kind,
            interval_seconds=template.interval_seconds,
            prompt=template.prompt,
            reset_session=template.reset_session,
            recurring=template.recurring,
            enabled=True,
            run_count=0,
            max_runs=template.max_runs,
            from_ts=template.from_ts,
            until_ts=template.until_ts,
            inherit_mode=template.inherit_mode,
            next_run_at=None,
            max_retry_attempts=template.max_retry_attempts,
            retry_delay_seconds=template.retry_delay_seconds,
            retry_attempt_count=0,
        )
        if record.trigger_kind in {"interval", "cron"}:
            try:
                record.next_run_at = self._next_timed_run_at(record, base_ts=now)
            except ValueError:
                logger.warning(
                    "Skipping default schedule due to invalid timing config route=%s mode=%s",
                    route,
                    record.schedule_mode,
                )
                return
        self._register_topic_schedule(record)
        logger.info(
            "Applied default schedule from settings route=%s mode=%s max_runs=%s",
            route,
            template.schedule_mode,
            template.max_runs,
        )

    def _topic_metadata_for_route(self, route: TelegramRoute) -> _TopicMetadata:
        return self._topic_metadata_by_route.get(route, _TopicMetadata())

    def _persist_state_for_route(self, route: TelegramRoute) -> None:
        state = self._states_by_route.get(route)
        if state is None:
            return
        last_inbound = self._last_inbound_message_id_by_route.get(route)
        session_id = state.session_id if isinstance(state.session_id, str) and state.session_id else None
        topic_title = state.topic_title if isinstance(state.topic_title, str) and state.topic_title else None
        topic_icon = (
            state.topic_icon_custom_emoji_id
            if isinstance(state.topic_icon_custom_emoji_id, str) and state.topic_icon_custom_emoji_id
            else None
        )
        child_fork_base_title = (
            state.child_fork_base_title
            if isinstance(state.child_fork_base_title, str) and state.child_fork_base_title
            else None
        )
        # Serialize user_hooks dict to JSON for persistence
        user_hooks_json: str | None = None
        if state.session_manager.user_hooks:
            try:
                user_hooks_json = json.dumps(state.session_manager.user_hooks, ensure_ascii=True)
            except (TypeError, ValueError):
                user_hooks_json = None
        explicit_env_json: str | None = None
        if state.session_manager.explicit_env_overrides:
            try:
                explicit_env_json = json.dumps(
                    state.session_manager.explicit_env_overrides, ensure_ascii=True, sort_keys=True
                )
            except (TypeError, ValueError):
                explicit_env_json = None
        self._state_store.upsert_route_state(
            chat_id=route.chat_id,
            thread_id=route.thread_id,
            session_id=session_id,
            topic_title=topic_title,
            topic_icon_custom_emoji_id=topic_icon,
            child_fork_count=state.child_fork_count,
            child_fork_base_title=child_fork_base_title,
            notify_on_completion=state.notify_on_completion,
            last_inbound_message_id=last_inbound,
            agent_lineage=state.agent_lineage,
            pending_obs_bootstrap=state.pending_obs_bootstrap,
            model_override=state.session_manager.model_override,
            user_hooks_json=user_hooks_json,
            effort_override=state.session_manager.effort_override,
            explicit_env_json=explicit_env_json,
        )

    def _restore_state_from_store(self) -> None:
        snapshot = self._state_store.load_snapshot()
        # A fresh maintenance marker or crash snapshot (and no kill-switch
        # sentinel) means the previous daemon did not go down by the kill
        # switch. Only then are late parent callbacks owed (vault-u3b.35).
        self._outage_inbox_floor = self._compute_outage_inbox_floor()
        owe_late_callbacks = self._outage_inbox_floor is not None
        # Only runs cut off by *this* outage owe a callback: in flight in the
        # previous daemon (listed by its last marker/snapshot) or launched after
        # that file was written. Children left over from older outages never do
        # (vault-u3b.81).
        owed_scope = self._last_outage_inflight_scope() if owe_late_callbacks else None
        for entry in snapshot.route_states:
            route = TelegramRoute(chat_id=entry.chat_id, thread_id=entry.thread_id)
            if entry.topic_title or entry.topic_icon_custom_emoji_id:
                self._topic_metadata_by_route[route] = _TopicMetadata(
                    title=entry.topic_title,
                    icon_custom_emoji_id=entry.topic_icon_custom_emoji_id,
                )
            state = self._build_session_state(route, topic_title=entry.topic_title)
            state.topic_title = (
                entry.topic_title
                or state.topic_title
                or self._default_topic_title(route)
            )
            state.topic_icon_custom_emoji_id = entry.topic_icon_custom_emoji_id
            state.child_fork_count = max(entry.child_fork_count, 0)
            state.child_fork_base_title = entry.child_fork_base_title
            state.notify_on_completion = entry.notify_on_completion
            state.agent_lineage = entry.agent_lineage
            state.pending_obs_bootstrap = entry.pending_obs_bootstrap
            # Restore model_override and user_hooks for non-Claude sessions
            if entry.model_override:
                state.session_manager.model_override = entry.model_override
            if entry.effort_override:
                from obs_agent.effort import normalize_effort

                try:
                    state.session_manager.effort_override = normalize_effort(entry.effort_override)
                except ValueError:
                    logger.warning("Ignoring invalid persisted effort for route=%s", route)
            if entry.user_hooks_json:
                try:
                    state.session_manager.user_hooks = json.loads(entry.user_hooks_json)
                except (json.JSONDecodeError, TypeError):
                    pass
            if entry.explicit_env_json:
                try:
                    loaded_env = json.loads(entry.explicit_env_json)
                except (json.JSONDecodeError, TypeError):
                    loaded_env = None
                if isinstance(loaded_env, dict):
                    state.session_manager.explicit_env_overrides = {
                        str(key): str(value) for key, value in loaded_env.items()
                    }
                    state.session_manager.set_sdk_env_overrides(
                        dict(state.session_manager.explicit_env_overrides)
                    )
            restored_bootstrap = None
            if entry.pending_obs_bootstrap:
                try:
                    restored_bootstrap = parse_obs_bootstrap_xml(entry.pending_obs_bootstrap)
                except Exception:
                    restored_bootstrap = None
                if (
                    state.agent_lineage is None
                    and restored_bootstrap is not None
                    and restored_bootstrap.lineage
                ):
                    state.agent_lineage = restored_bootstrap.lineage

            # Rebuild stable team identity from persisted bootstrap, environment,
            # or lineage without scanning thousands of historical JSONLs.
            projection = None
            if entry.pending_obs_bootstrap is None and state.agent_lineage and entry.session_id:
                # vault-mngu / obs-15 P5-3: an inline reply-fork adopts the agent's
                # identity without priming a bootstrap, so nothing identity-bearing
                # is persisted for the route. Recover it from the active session's
                # JSONL (its copied history carries the agent's own bootstrap)
                # instead of defaulting to a fresh, current-time root team key.
                # Scoped to these routes only, so restore still avoids scanning
                # every historical JSONL.
                state.session_manager.set_session_id(entry.session_id)
                projection = self._state_inbox_projection(
                    state,
                    allow_jsonl_lookup=True,
                    allow_default_projection=False,
                )
                if projection is not None:
                    logger.info(
                        "[inline_fork] restore: identity recovered from session jsonl "
                        "(route=%s session=%s team=%s agent=%s)",
                        route,
                        entry.session_id,
                        projection[0],
                        projection[1],
                    )
                else:
                    logger.info(
                        "[inline_fork] restore: no identity in session jsonl; default projection "
                        "(route=%s session=%s)",
                        route,
                        entry.session_id,
                    )
            if projection is None:
                projection = self._state_inbox_projection(
                    state,
                    allow_jsonl_lookup=False,
                    allow_default_projection=True,
                )
            if projection is not None:
                state.session_manager.set_sdk_env_overrides(
                    self._with_explicit_env(
                        state,
                        self._build_team_worker_env(
                            team_name=projection[0],
                            agent_name=projection[1],
                        ),
                    )
                )
            if entry.session_id:
                state.session_manager.set_session_id(entry.session_id)
                self._route_by_session_id[entry.session_id] = route
            self._states_by_route[route] = state
            self._upsert_route_inbox_target(
                state,
                allow_jsonl_lookup=False,
                persist_projection_config=False,
            )
            if entry.last_inbound_message_id is not None:
                self._last_inbound_message_id_by_route[route] = entry.last_inbound_message_id

        for entry in snapshot.message_bindings:
            route = TelegramRoute(
                chat_id=entry.route_chat_id,
                thread_id=entry.route_thread_id,
            )
            self._message_map[(entry.chat_id, entry.message_id)] = _TelegramMessageBinding(
                jsonl_uuid=entry.jsonl_uuid,
                session_id=entry.session_id,
                role=entry.role,
                route=route,
            )

        for entry in snapshot.system_messages:
            key = (entry.chat_id, entry.message_id)
            route = TelegramRoute(
                chat_id=entry.route_chat_id,
                thread_id=entry.route_thread_id,
            )
            self._system_message_ids.add(key)
            self._system_message_routes[key] = route

        self._session_heads.update(snapshot.session_heads)

        for entry in snapshot.topic_schedules:
            if str(entry.schedule_id).startswith("reply-wake-"):
                self._state_store.delete_topic_schedule(schedule_id=entry.schedule_id)
                continue
            route = TelegramRoute(chat_id=entry.chat_id, thread_id=entry.thread_id)
            record = _TopicScheduleRecord(
                schedule_id=entry.schedule_id,
                route=route,
                description=entry.description,
                schedule_mode=entry.schedule_mode,
                cron_expr=entry.cron_expr,
                trigger_kind=entry.trigger_kind,
                interval_seconds=entry.interval_seconds,
                prompt=entry.prompt,
                reset_session=(entry.run_mode == "reset_session"),
                recurring=entry.recurring,
                enabled=entry.enabled,
                run_count=entry.run_count,
                max_runs=entry.max_runs,
                from_ts=entry.from_ts,
                until_ts=entry.until_ts,
                inherit_mode=entry.inherit_mode,
                next_run_at=entry.next_run_at,
                last_run_at=entry.last_run_at,
                last_success_at=entry.last_success_at,
                last_error=entry.last_error,
                max_retry_attempts=entry.max_retry_attempts,
                retry_delay_seconds=entry.retry_delay_seconds,
                retry_attempt_count=entry.retry_attempt_count,
                prompt_file=entry.prompt_file,
            )
            if record.last_error and record.last_error.startswith(_SCHEDULE_IN_PROGRESS_PREFIX):
                # ops-29: the previous process died mid-run; this fire is still due and re-fires.
                started = record.last_error[len(_SCHEDULE_IN_PROGRESS_PREFIX):]
                record.last_error = (
                    f"{_SCHEDULE_INTERRUPTED_PREFIX}{started} did not finish before OBS "
                    "restarted; the fire is retried"
                )
                logger.info(
                    "[schedule_interrupted] schedule_id=%s route=%s started=%s next_run_at=%s",
                    record.schedule_id,
                    route,
                    started,
                    entry.next_run_at,
                )
            if record.enabled and not self._schedule_is_exhausted(record, time.time()):
                self._ensure_topic_schedule_owner(record)
            self._topic_schedules_by_id[record.schedule_id] = record
            self._schedule_ids_by_route.setdefault(route, set()).add(record.schedule_id)

        try:
            ownership = _schedule_scope.ScheduleOwnership.load(self._config.vault_path)
            self._schedule_owner_sweep_pending = any("owners map unreadable" in error for error in ownership.load_errors)
        except Exception:
            self._schedule_owner_sweep_pending = True
            logger.warning("Unable to inspect stale schedule ownership during restore", exc_info=True)
        else:
            for sid in ownership.owners.keys() - self._topic_schedules_by_id.keys():
                self._retire_topic_schedule_owner(sid)

        for entry in snapshot.task_handle_states:
            child_route = TelegramRoute(
                chat_id=entry.child_chat_id,
                thread_id=entry.child_thread_id,
            )
            parent_route = TelegramRoute(
                chat_id=entry.parent_chat_id,
                thread_id=entry.parent_thread_id,
            )
            child_state = self._states_by_route.get(child_route)
            if child_state is None:
                child_state = self._build_session_state(child_route)
                self._states_by_route[child_route] = child_state
            if entry.child_session_id and child_state.session_id != entry.child_session_id:
                child_state.session_manager.set_session_id(entry.child_session_id)
                self._route_by_session_id[entry.child_session_id] = child_route

            record = _ForkTaskRecord(
                task_id=entry.task_id,
                parent_route=parent_route,
                parent_session_id_at_launch=entry.parent_session_id_at_launch or entry.child_session_id,
                parent_source_uuid=entry.parent_source_uuid or self._session_heads.get(entry.child_session_id, ""),
                child_route=child_route,
                child_session_id=entry.child_session_id,
                prompt="",
                description=entry.description,
                timeout_ms=entry.timeout_ms,
                max_turns=entry.max_turns,
                status=entry.status or "completed",
                created_at=entry.created_at or time.time(),
                completed_at=entry.completed_at,
                launch_parent_message_id=entry.launch_parent_message_id,
                launch_child_message_id=entry.launch_child_message_id,
                child_completion_message_id=entry.child_completion_message_id,
                parent_callback_message_id=entry.parent_callback_message_id,
                error=entry.error,
                terminal_request=entry.terminal_request,
                result_text=entry.result_text,
                is_fork=entry.is_fork,
                launch_tool_name=entry.launch_tool_name or ("ForkTask" if entry.is_fork else "AgentTask"),
                team_name=entry.team_name,
                agent_name=entry.agent_name,
                idle_ready=entry.idle_ready,
                emit_parent_callback=False,
            )
            record.callback_owed = (
                owed_scope is not None
                and self._restored_record_owes_callback(record)
                and self._record_cut_off_by_last_outage(record, owed_scope)
            )
            if record.callback_owed:
                logger.warning(
                    "[restore] parent callback owed task_id=%s child=%s parent=%s",
                    record.task_id,
                    record.child_route,
                    record.parent_route,
                )
            self._fork_tasks_by_id[record.task_id] = record
            self._fork_task_by_child_route[child_route] = record.task_id
            if record.team_name and record.agent_name:
                child_state.session_manager.set_sdk_env_overrides(
                    self._with_explicit_env(
                        child_state,
                        self._build_team_worker_env(
                            team_name=record.team_name,
                            agent_name=record.agent_name,
                ),
                    )
                )
            self._upsert_route_inbox_target(
                child_state,
                allow_jsonl_lookup=False,
                persist_projection_config=False,
            )
            key = self._team_worker_key(record.team_name, record.agent_name)
            if key is not None:
                self._team_worker_records[key] = record.task_id
                self._register_team_worker_record(record)

        restored_inbox_keys: set[tuple[str, str]] = set()
        for key in self._team_worker_records:
            restored_inbox_keys.add(key)
        for key in self._route_inbox_targets:
            restored_inbox_keys.add(key)

        for entry in snapshot.team_worker_states:
            if entry.task_id in self._fork_tasks_by_id:
                continue
            key = self._team_worker_key(entry.team_name, entry.agent_name)
            if key is None:
                continue
            child_route = TelegramRoute(
                chat_id=entry.child_chat_id,
                thread_id=entry.child_thread_id,
            )
            child_state = self._states_by_route.get(child_route)
            if child_state is None:
                child_state = self._build_session_state(child_route)
                self._states_by_route[child_route] = child_state
            if entry.child_session_id and child_state.session_id != entry.child_session_id:
                child_state.session_manager.set_session_id(entry.child_session_id)
                self._route_by_session_id[entry.child_session_id] = child_route

            restored_idle_ready = entry.idle_ready
            if not restored_idle_ready and entry.status not in {"failed", "stopped"}:
                # Pragmatic restart policy: if we cannot prove terminal shutdown,
                # restore as idle-ready so teammate messages can wake the worker.
                restored_idle_ready = True

            record = _ForkTaskRecord(
                task_id=entry.task_id,
                parent_route=child_route,
                parent_session_id_at_launch=entry.child_session_id,
                parent_source_uuid=self._session_heads.get(entry.child_session_id, ""),
                child_route=child_route,
                child_session_id=entry.child_session_id,
                prompt="",
                description=entry.description,
                status="completed" if restored_idle_ready else entry.status,
                is_fork=False,
                launch_tool_name="AgentTask",
                team_name=entry.team_name,
                agent_name=entry.agent_name,
                idle_ready=restored_idle_ready,
                emit_parent_callback=False,
            )
            self._fork_tasks_by_id[record.task_id] = record
            self._team_worker_records[key] = record.task_id
            self._fork_task_by_child_route[child_route] = record.task_id
            child_state.session_manager.set_sdk_env_overrides(
                self._with_explicit_env(
                    child_state,
                    self._build_team_worker_env(
                        team_name=record.team_name,
                        agent_name=record.agent_name,
                    ),
                )
            )
            self._upsert_route_inbox_target(
                child_state,
                allow_jsonl_lookup=False,
                persist_projection_config=False,
            )
            restored_inbox_keys.add(key)

        self._mark_restored_team_inboxes_read(restored_inbox_keys)

    @staticmethod
    def _restored_record_owes_callback(record: _ForkTaskRecord) -> bool:
        """True when a restored child was cut off mid-run before its parent heard back.

        Persisted status stays ``launched`` until a run finishes; the finish
        path persists the terminal status together with the callback id. An
        inbox wake re-points ``parent_route`` at the child itself, so such runs
        never owed a parent anything.
        """
        return (
            (record.status or "completed") not in {"completed", "failed", "stopped"}
            and not record.terminal_request
            and record.parent_callback_message_id is None
            and record.parent_route != record.child_route
        )

    def _last_outage_inflight_scope(self) -> tuple[set[str], float] | None:
        """Runs in flight when the previous daemon last wrote its marker/snapshot.

        Returns ``(task_ids, written_at)`` from the fresh maintenance marker and,
        unless a kill-switch sentinel exists, the fresh crash snapshot. Both are
        written only by the daemon that just went down (each start consumes the
        previous files), so the set cannot reach back to an older outage.
        """
        max_age = _maint.max_age_from_env()
        markers = [
            _maint.peek_marker(self._shutdown_marker_path(), max_age_seconds=None),
            _maint.peek_marker(self._maintenance_marker_path(), max_age_seconds=max_age),
        ]
        sentinel = os.environ.get(_maint.KILLSWITCH_SENTINEL_ENV)
        if not (sentinel and Path(sentinel).exists()):
            markers.append(_maint.peek_marker(self._crash_snapshot_path(), max_age_seconds=max_age))
        fresh = [marker for marker in markers if marker is not None]
        if not fresh:
            return None
        task_ids: set[str] = set()
        for marker in fresh:
            task_ids.update(marker.inflight_task_ids)
        return task_ids, max(marker.requested_at for marker in fresh)

    @staticmethod
    def _record_cut_off_by_last_outage(
        record: _ForkTaskRecord,
        scope: tuple[set[str], float],
    ) -> bool:
        """True when the run was live in the daemon that just went down.

        Either the previous daemon listed it as in flight (its parent was still
        waiting), or it was launched after that daemon's last snapshot write, so
        no snapshot could list it yet.
        """
        task_ids, written_at = scope
        if record.task_id in task_ids:
            return True
        return float(record.created_at or 0.0) >= written_at

    def _collect_inflight_task_ids(self) -> list[str]:
        """Fork/AgentTask runs whose parent has not heard back yet (for the marker)."""
        task_ids: set[str] = set()
        for state in self._states_by_route.values():
            task_ids.update(state.active_fork_task_ids)
        for task_id, run in self._fork_task_tasks.items():
            if not run.done():
                task_ids.add(task_id)
        return sorted(
            task_id
            for task_id in task_ids
            if (record := self._fork_tasks_by_id.get(task_id)) is not None
            and record.parent_route != record.child_route
            and not record.terminal_request
        )

    def _owed_callback_deliverable(self, record: _ForkTaskRecord) -> bool:
        """An owed callback must not wake a parent that was stopped or is gone."""
        parent_state = self._get_state(record.parent_route, create=False)
        if parent_state is None:
            return False
        if parent_state.hook_state.stop_requested_at is not None:
            return False
        parent_task_id = self._fork_task_by_child_route.get(record.parent_route)
        parent_record = self._fork_tasks_by_id.get(parent_task_id) if parent_task_id else None
        if parent_record is not None and (
            parent_record.terminal_request or parent_record.status == "stopped"
        ):
            # /stop, /stop_branch or /stop_tree reached the parent.
            return False
        return True

    # ------------------------------------------------------------------
    # Opt-in maintenance restart (Daniel 2026-09-25; not the default).
    # Plain restart/stop is the kill switch: without a marker, nothing resumes.
    # ------------------------------------------------------------------

    def _maintenance_marker_path(self) -> Path:
        return _maint.marker_path(Path(self._config.telegram_state_db_path).parent)

    def _shutdown_marker_path(self) -> Path:
        return _maint.shutdown_marker_path(self._state_dir())

    def _state_model_name(self, state: TelegramSessionState) -> str:
        return str(state.session_manager.model_override or self._config.model or "")

    def _collect_maintenance_entries(self, *, allow_jsonl_lookup: bool = True) -> list[_maint.ResumeEntry]:
        """Snapshot every route that is mid-turn right now.

        The periodic crash snapshot passes ``allow_jsonl_lookup=False`` so it
        never scans session JSONLs on the event loop; team/agent names in the
        entry are informational only.
        """
        entries: list[_maint.ResumeEntry] = []
        for route, state in list(self._states_by_route.items()):
            if not (state.busy or state.hook_state.execution_active):
                continue
            task_id = self._fork_task_by_child_route.get(route)
            record = self._fork_tasks_by_id.get(task_id) if task_id else None
            if record is not None and record.terminal_request:
                # /stop, /stop_branch or /stop_tree before the restart wins.
                continue
            if state.hook_state.stop_requested_at is not None or state.hook_state.stop_latched_at is not None:
                # A stop was requested for this turn (also plain trunk /stop),
                # or the route's task was stopped (obs-2).
                continue
            session_id = state.session_id
            inflight_prompt: str | None = None
            if not session_id or state.inflight_first_turn:
                # No transcript to resume yet, or maybe none: a new session's id
                # is known from the CLI's init message (vault-1i53), but until the
                # CLI writes the turn's first rows `--resume` fails. Keep the
                # turn's input so the resume can re-send it into a new session
                # instead of a bare "continue"; it resumes the transcript when
                # there is one.
                inflight_prompt = state.inflight_user_text
                if not inflight_prompt and record is not None and (record.prompt or record.prompt_file_content):
                    inflight_prompt = self._compose_prompt_file_context(
                        prompt=record.prompt,
                        prompt_file=record.prompt_file,
                        prompt_file_content=record.prompt_file_content,
                    )
            model = self._state_model_name(state)
            projection = self._state_inbox_projection(state, allow_jsonl_lookup=allow_jsonl_lookup)
            queued = [
                _maint.QueuedEntry(
                    text=item.text,
                    telegram_message_id=item.telegram_message_id,
                    reply_to_message_id=item.reply_to_message_id,
                )
                for item in (coerce_queued_message(raw) for raw in state.pending_messages)
                if (item.text or "").strip()
            ]
            entries.append(
                _maint.ResumeEntry(
                    chat_id=route.chat_id,
                    thread_id=route.thread_id,
                    session_id=session_id,
                    task_id=record.task_id if record is not None else None,
                    team_name=(record.team_name if record is not None else None)
                    or (projection[0] if projection is not None else None),
                    agent_name=(record.agent_name if record is not None else None)
                    or (projection[1] if projection is not None else None),
                    is_local=_maint.is_local_model(model),
                    model=model or None,
                    jsonl_head_uuid=self._session_heads.get(session_id or ""),
                    topic_title=state.topic_title,
                    queued=queued,
                    crash_resume_count=self._crash_resume_counts.get(route, 0),
                    inflight_prompt=inflight_prompt or None,
                )
            )
        return entries

    def write_maintenance_marker(self, *, source: str) -> tuple[Path, list[_maint.ResumeEntry]]:
        entries = self._collect_maintenance_entries()
        marker = _maint.ResumeMarker(
            requested_at=time.time(),
            source=source,
            entries=entries,
            inflight_task_ids=self._collect_inflight_task_ids(),
        )
        path = _maint.write_marker(self._maintenance_marker_path(), marker)
        logger.warning(
            "[maintenance_restart] marker written path=%s source=%s routes=%d local=%d",
            path,
            source,
            len(entries),
            sum(1 for entry in entries if entry.is_local),
        )
        return path, entries

    def _maintenance_terminate(self) -> None:
        if self._maintenance_exit_fn is not None:
            self._maintenance_exit_fn()
            return
        # Same blast radius as `supervisorctl restart`: the wrapper, this
        # process and every CLI child share the supervisord process group.
        try:
            os.killpg(os.getpgrp(), signal.SIGTERM)
        except OSError:
            os.kill(os.getpid(), signal.SIGTERM)

    async def request_maintenance_restart(self, *, source: str, delay_seconds: float = 1.0) -> int:
        """Write the resume marker, then terminate for supervisord to restart."""
        if self._maintenance_restart_requested:
            return 0
        self._maintenance_restart_requested = True
        _path, entries = self.write_maintenance_marker(source=source)
        if delay_seconds > 0:
            # Let the confirmation message and the marker log line flush.
            await asyncio.sleep(delay_seconds)
        self._maintenance_terminate()
        return len(entries)

    def _state_dir(self) -> Path:
        return Path(self._config.telegram_state_db_path).parent

    def _crash_snapshot_path(self) -> Path:
        return _maint.crash_snapshot_path(self._state_dir())

    @property
    def _inbox_wake_floor(self) -> float:
        """Unread inbox messages at or after this time wake their agent.

        Normally the daemon start (pre-start messages are stale). After a
        maintenance restart or crash it is the previous daemon's last-alive time,
        so messages sent during the outage are not lost (vault-u3b.35).
        """
        if self._outage_inbox_floor is None:
            return self._daemon_started_at
        return min(self._daemon_started_at, self._outage_inbox_floor)

    def _compute_outage_inbox_floor(self) -> float | None:
        """Last-alive time of the previous daemon when its restart was not a kill switch."""
        max_age = _maint.max_age_from_env()
        candidates = [
            _maint.peek_requested_at(self._shutdown_marker_path(), max_age_seconds=None),
            _maint.peek_requested_at(self._maintenance_marker_path(), max_age_seconds=max_age),
        ]
        sentinel = os.environ.get(_maint.KILLSWITCH_SENTINEL_ENV)
        if not (sentinel and Path(sentinel).exists()):
            candidates.append(
                _maint.peek_requested_at(self._crash_snapshot_path(), max_age_seconds=max_age)
            )
        fresh = [value for value in candidates if value is not None]
        if not fresh:
            return None
        # Slack covers messages the old poller had not reached before it died.
        return max(fresh) - 60.0

    def write_crash_snapshot(self) -> Path | None:
        """Refresh crash-resume.json with every mid-turn route (atomic replace)."""
        if self._crash_snapshot_disabled:
            return None
        marker = _maint.ResumeMarker(
            requested_at=time.time(),
            source="periodic",
            entries=self._collect_maintenance_entries(allow_jsonl_lookup=False),
            inflight_task_ids=self._collect_inflight_task_ids(),
        )
        return _maint.write_marker(self._crash_snapshot_path(), marker)

    def discard_crash_snapshot_for_kill_switch(self) -> bool:
        """Kill switch: nothing from the crash snapshot may resume. Signal-safe."""
        self._crash_snapshot_disabled = True
        return _maint.discard_crash_snapshot(self._state_dir())

    def start_crash_snapshot_writer(self) -> asyncio.Task | None:
        interval = _maint.crash_snapshot_interval_from_env()
        if interval <= 0:
            logger.warning("[crash_resume] disabled (OBS_CRASH_RESUME_SNAPSHOT_SECONDS=0)")
            return None
        if self._crash_snapshot_task is None or self._crash_snapshot_task.done():
            self._crash_snapshot_task = asyncio.create_task(self._crash_snapshot_loop(interval))
        return self._crash_snapshot_task

    async def _crash_snapshot_loop(self, interval: float) -> None:
        while True:
            try:
                self.write_crash_snapshot()
            except Exception:
                logger.warning("[crash_resume] snapshot write failed", exc_info=True)
            await asyncio.sleep(interval)

    def start_maintenance_resume(self, *, include_crash: bool = True) -> asyncio.Task | None:
        """Consume a fresh maintenance marker or crash snapshot and resume its routes.

        Both files are renamed before anything acts on them (consume-before-act).
        A maintenance marker wins over a crash snapshot. A kill-switch stop
        recorded by the supervisord wrapper discards the crash snapshot first.
        """
        max_age = _maint.max_age_from_env()
        killswitch = _maint.consume_killswitch_sentinel(
            os.environ.get(_maint.KILLSWITCH_SENTINEL_ENV)
        )
        shutdown, shutdown_reason = _maint.consume_marker(
            self._shutdown_marker_path(), max_age_seconds=None,
        )
        if shutdown is None and shutdown_reason != "no_marker":
            logger.warning("[shutdown_resume] marker ignored reason=%s", shutdown_reason)
        marker, reason = _maint.consume_marker(
            self._maintenance_marker_path(),
            max_age_seconds=max_age,
        )
        if marker is None and reason != "no_marker":
            logger.warning("[maintenance_restart] marker ignored reason=%s", reason)
        if shutdown is not None:
            marker = shutdown
        crash: _maint.ResumeMarker | None = None
        if include_crash:
            if killswitch and _maint.discard_crash_snapshot(self._state_dir()):
                logger.warning("[crash_resume] kill-switch stop recorded; crash snapshot discarded")
            crash, crash_reason = _maint.consume_marker(self._crash_snapshot_path(), max_age_seconds=max_age)
            if crash is None and crash_reason != "no_marker":
                logger.warning("[crash_resume] snapshot ignored reason=%s", crash_reason)
        if marker is not None:
            if crash is not None:
                logger.warning(
                    "[crash_resume] maintenance marker present; crash snapshot not used routes=%d",
                    len(crash.entries),
                )
            kind = "shutdown" if shutdown is not None else "maintenance"
        elif crash is not None:
            limit = _maint.crash_max_consecutive_from_env()
            kept: list[_maint.ResumeEntry] = []
            for entry in crash.entries:
                if entry.crash_resume_count >= limit:
                    logger.warning(
                        "[crash_resume] not resuming route chat=%s thread=%s session=%s: "
                        "crash-resumed %d times in a row (limit %d)",
                        entry.chat_id,
                        entry.thread_id,
                        entry.session_id,
                        entry.crash_resume_count,
                        limit,
                    )
                    continue
                kept.append(entry)
            crash.entries = kept
            marker = crash
            kind = "crash"
        else:
            return None
        logger.warning(
            "[%s] resuming routes=%d source=%s requested_at=%.0f",
            "shutdown_resume" if kind == "shutdown" else "maintenance_restart" if kind == "maintenance" else "crash_resume",
            len(marker.entries),
            marker.source,
            marker.requested_at,
        )
        task = asyncio.create_task(self._run_maintenance_resume(marker, kind=kind))
        self._maintenance_resume_task = task
        return task

    async def _run_maintenance_resume(self, marker: _maint.ResumeMarker, *, kind: str = "maintenance") -> None:
        hosted, local = _maint.split_resume_order(marker.entries)
        stagger = _maint.hosted_stagger_from_env()

        local_wait = _maint.local_resume_wait_from_env()

        async def _local_chain() -> None:
            # Strictly one local route at a time behind the single inference
            # server (vault-u3b.86): the next route starts only after the
            # previous resumed turn ends, errors or is stopped. asyncio.wait
            # never raises for the inner task (incl. cancellation) and never
            # cancels it; the timeout is a logged last resort only.
            for entry in local:
                try:
                    run = await self._resume_maintenance_entry(entry, requested_at=marker.requested_at, kind=kind)
                    if run is None:
                        continue
                    done, _pending = await asyncio.wait({run}, timeout=local_wait if local_wait > 0 else None)
                    if not done:
                        logger.error(
                            "[maintenance_restart] local resume exceeded the %.0fs safety timeout; "
                            "starting next local route (turn not cancelled) entry=%s",
                            local_wait,
                            entry,
                        )
                except Exception:
                    logger.warning("[maintenance_restart] local resume failed entry=%s", entry, exc_info=True)

        local_task = asyncio.create_task(_local_chain()) if local else None
        for index, entry in enumerate(hosted):
            if index and stagger:
                await asyncio.sleep(stagger)
            try:
                await self._resume_maintenance_entry(entry, requested_at=marker.requested_at, kind=kind)
            except Exception:
                logger.warning("[maintenance_restart] hosted resume failed entry=%s", entry, exc_info=True)
        if local_task is not None:
            await local_task

    async def _resume_maintenance_entry(
        self,
        entry: _maint.ResumeEntry,
        *,
        requested_at: float,
        kind: str = "maintenance",
    ) -> asyncio.Task | None:
        """Start one resumed turn; returns the task driving it (or None)."""
        route = TelegramRoute(chat_id=entry.chat_id, thread_id=entry.thread_id)
        state = self._get_state(route, create=False)
        if state is None:
            logger.warning("[maintenance_restart] skip route=%s reason=route_not_restored", route)
            return None
        if entry.session_id and state.session_id != entry.session_id:
            await self._activate_route_session(state, entry.session_id)
        if entry.inflight_prompt and state.session_id and not self._session_resumable(state.session_id):
            # vault-1i53: the first turn was cut off after the CLI reported its
            # session id but before it wrote the turn's first rows, so there is
            # no transcript to --resume. A fresh session gets the original request.
            logger.warning(
                "[maintenance_restart] route=%s session_id=%s has no transcript yet; "
                "re-sending the original request in a fresh session",
                route,
                state.session_id,
            )
            await self._activate_route_session(state, None)
        bot = self._bot_for_state(state)
        if bot is None:
            logger.warning("[maintenance_restart] skip route=%s reason=no_bot", route)
            return None
        state.last_bot = bot
        queued = [
            QueuedMessage(
                text=item.text,
                telegram_message_id=item.telegram_message_id,
                reply_to_message_id=item.reply_to_message_id,
            )
            for item in entry.queued
        ]
        prompt = _maint.build_resume_prompt(
            requested_at=requested_at,
            queued_count=len(queued),
            kind=kind,
            # Only when there is no transcript to continue; otherwise the
            # session already holds the original request.
            original_prompt=entry.inflight_prompt if not state.session_id else None,
        )
        record = self._fork_tasks_by_id.get(entry.task_id or "") if entry.task_id else None
        lock = self._get_route_lock(route)
        async with lock:
            if state.busy:
                logger.warning("[maintenance_restart] skip route=%s reason=already_busy", route)
                return None
            state.busy = True
        try:
            marker_messages = await self._send_system_html_message(
                route=route,
                bot=bot,
                html_text=(
                    "crash recovery: OBS restarted unexpectedly; resuming the turn that was cut off"
                    if kind == "crash"
                    else "shutdown recovery: OBS started again; resuming the saved turn"
                    if kind == "shutdown"
                    else "maintenance restart: resuming the turn that was cut off"
                ),
                disable_notification=True,
                underline=False,
            )
        except _TopicDeletedError:
            state.busy = False
            logger.warning("[maintenance_restart] skip route=%s reason=topic_deleted", route)
            return None
        marker_message_id = self._sent_message_id(marker_messages[0]) if marker_messages else None
        if queued:
            state.pending_messages = list(state.pending_messages) + queued

        if record is not None:
            # Re-arm the parent callback so a waiting parent hears about the
            # resumed child's completion (restore sets it False).
            record.prompt = prompt
            record.prompt_file = None
            record.prompt_file_content = None
            record.status = "launched"
            record.error = None
            record.terminal_request = None
            record.completed_at = None
            record.result_text = None
            record.parent_callback_message_id = None
            record.child_completion_message_id = None
            record.launch_child_message_id = marker_message_id
            record.idle_ready = False
            record.emit_parent_callback = True
            record.callback_owed = False
            parent_state = self._get_state(record.parent_route, create=False)
            if parent_state is not None and parent_state.last_bot is None:
                # Restored parents have no bot yet; the callback needs one.
                parent_state.last_bot = bot
            self._register_team_worker_record(record)
            await self._schedule_fork_task(
                task_id=record.task_id,
                parent_state=state,
                wake_reserved=True,
            )
            run = self._fork_task_tasks.get(record.task_id)
            self._track_crash_resume(route, entry, kind=kind, run=run)
            return run

        async def _runner() -> None:
            try:
                async with self._get_route_lock(route):
                    await self._run_and_send(
                        state=state,
                        user_text=prompt,
                        bot=bot,
                        trigger_message=QueuedMessage(text=prompt, telegram_message_id=marker_message_id),
                    )
            finally:
                state.busy = False

        task = asyncio.create_task(_runner())
        self._detached_wake_tasks.add(task)
        task.add_done_callback(self._on_detached_wake_done)
        self._track_crash_resume(route, entry, kind=kind, run=task)
        return task

    def _session_resumable(self, session_id: str) -> bool:
        """True when the session's JSONL has a conversation row the CLI can resume."""
        try:
            return (
                session_jsonl_has_conversation(session_id=session_id, cwd=self._config.vault_path)
                is True
            )
        except Exception:
            logger.warning("Unable to inspect JSONL before resume session_id=%s", session_id, exc_info=True)
            return True

    def _track_crash_resume(
        self,
        route: TelegramRoute,
        entry: _maint.ResumeEntry,
        *,
        kind: str,
        run: asyncio.Task | None,
    ) -> None:
        """Count consecutive crash resumes of this turn until it ends."""
        if kind != "crash":
            return
        self._crash_resume_counts[route] = entry.crash_resume_count + 1
        if run is None:
            return

        def _clear(_task: asyncio.Task) -> None:
            self._crash_resume_counts.pop(route, None)

        run.add_done_callback(_clear)

    async def handle_maintenance_restart(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /maintenance_restart - snapshot running agents, restart, resume them."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        route = self._route_for_message(update.effective_message)
        if not await self._freeze_allows_restart(
            route=route, bot=context.bot, plain=False, user_id=update.effective_user.id,
            source=f"telegram:/maintenance_restart user={update.effective_user.id}",
        ):
            return
        entries = self._collect_maintenance_entries()
        local_count = sum(1 for entry in entries if entry.is_local)
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=(
                f"maintenance restart: {len(entries)} running agent(s) will resume after restart "
                f"({local_count} local, one at a time). Kill switch instead: /restart plain or /stop_tree."
            ),
            disable_notification=True,
        )
        await self.request_maintenance_restart(source=f"telegram:/maintenance_restart user={update.effective_user.id}")

    async def _freeze_allows_restart(
        self, *, route: TelegramRoute, bot: Any, plain: bool, user_id: int, source: str
    ) -> bool:
        """Freeze guard for a Telegram /restart (ops-47.6). Returns False when the restart must not run.

        Daniel's own command (``telegram_principal_user_id``) is honoured during a covering freeze:
        it only logs a warning and tells him which freeze is active. Any other authorized user -- the
        agent-driven test identity, a second human -- follows the same rule as the CLI path and is
        refused, because Daniel's override is personal to him (re-check 2 G1). Agents that need to
        restart during a freeze use ``maintenance_restart`` with ``OPS_FREEZE_ACK``. Fails open: any
        error in the freeze check is logged and the restart proceeds.
        """
        try:
            result = await asyncio.to_thread(_freeze_guard.check, _maint.freeze_check_command(plain=plain))
        except Exception:
            logger.warning("freeze check could not run for %s; restart not checked", source, exc_info=True)
            return True
        if result.error:
            logger.warning("freeze check unavailable for %s: %s", source, result.error)
        if not result.blocked:
            return True
        lines = (result.message or "").splitlines()
        detail = lines[1] if len(lines) > 1 else (lines[0] if lines else "")
        principal = self._config.telegram_principal_user_id
        if principal is not None and user_id == principal:
            logger.warning("restart during an active shared-service freeze, honoured (principal command): %s; %s",
                           source, detail)
            text = (
                "warning: an active shared-service freeze covers this restart. Restarting anyway "
                f"because you asked.\n{detail}"
            )
            proceed = True
        else:
            logger.warning("restart during an active shared-service freeze, refused (not the principal): %s; %s",
                           source, detail)
            text = (
                "refused: an active shared-service freeze covers this restart, and only Daniel's own "
                "/restart overrides it. Agents restart through maintenance_restart with "
                f"OPS_FREEZE_ACK=<freeze id>.\n{detail}"
            )
            proceed = False
        try:
            await self._send_system_message(route=route, bot=bot, text=text, disable_notification=True)
        except Exception:
            logger.warning("could not post the freeze notice", exc_info=True)
        return proceed

    async def _run_cache_gate(self):
        """Cache-prefix gate for planned restarts (vault-3px5); None if it cannot run."""
        try:
            repo = Path(_cache_gate.__file__).resolve().parents[2]
            return await asyncio.to_thread(_cache_gate.check, repo)
        except Exception:
            logger.warning("cache gate could not run; restart not gated", exc_info=True)
            return None

    async def handle_restart(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /restart [plain] - maintenance restart by default; ``plain`` resumes nothing."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        raw_args = [str(arg).strip() for arg in (context.args or []) if str(arg).strip()]
        args = [arg.lower() for arg in raw_args]
        route = self._route_for_message(update.effective_message)
        bypass_reason: str | None = None
        if args and args[0].lstrip("-\u2014\u2013") == "skip-cache-gate":
            bypass_reason = " ".join(raw_args[1:]).strip()
            if not bypass_reason:
                await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text="usage: /restart skip-cache-gate <reason> (emergency only; the reason is logged)",
                    disable_notification=True,
                )
                return
            args = []
        if args and args != ["plain"]:
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text=(
                    "usage: /restart (resume mid-turn agents), /restart plain (kill switch: resume nothing), "
                    "or /restart skip-cache-gate <reason>"
                ),
                disable_notification=True,
            )
            return
        gate = await self._run_cache_gate()
        if not args:
            if gate is not None and not gate.ok:
                if bypass_reason is None:
                    await self._send_system_message(
                        route=route, bot=context.bot, text=gate.message, disable_notification=True,
                    )
                    return
                _cache_gate.log_bypass(
                    reason=bypass_reason,
                    source=f"telegram:/restart user={update.effective_user.id}",
                    result=gate,
                )
                await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text=f"cache gate bypassed (logged): {bypass_reason}",
                    disable_notification=True,
                )
            await self.handle_maintenance_restart(update, context)
            return
        if gate is not None and not gate.ok:
            _cache_gate.log_bypass(
                reason="plain restart (kill switch, ungated)",
                source=f"telegram:/restart plain user={update.effective_user.id}",
                result=gate,
            )
        if not await self._freeze_allows_restart(
            route=route, bot=context.bot, plain=True, user_id=update.effective_user.id,
            source=f"telegram:/restart plain user={update.effective_user.id}",
        ):
            return
        await self.request_plain_restart(
            route=self._route_for_message(update.effective_message),
            bot=context.bot,
            source=f"telegram:/restart plain user={update.effective_user.id}",
        )

    async def handle_shutdown(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await self._handle_shutdown(update, context, autoresume=False)

    async def handle_shutdown_autoresume(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await self._handle_shutdown(update, context, autoresume=True)

    async def _handle_shutdown(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE, *, autoresume: bool,
    ) -> None:
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        command = "shutdown_autoresume" if autoresume else "shutdown"
        route = self._route_for_message(update.effective_message)
        if context.args:
            await self._send_system_message(
                route=route, bot=context.bot, text=f"usage: /{command}", disable_notification=True,
            )
            return
        await self.request_shutdown(
            route=route, bot=context.bot, autoresume=autoresume,
            source=f"telegram:/{command} user={update.effective_user.id}",
        )

    def _stage_shutdown(self, *, autoresume: bool, source: str, requested_at: float) -> list[_maint.ResumeEntry]:
        entries: list[_maint.ResumeEntry] = []
        if autoresume:
            entries = self._collect_maintenance_entries()
            for entry in entries:
                self._persist_state_for_route(TelegramRoute(entry.chat_id, entry.thread_id))
            marker = _maint.ResumeMarker(
                requested_at=requested_at, source=source, entries=entries,
                inflight_task_ids=self._collect_inflight_task_ids(),
            )
            # Replace in place: the previous checkpoint remains durable until
            # the refreshed checkpoint is successfully written and renamed.
            _maint.write_marker(self._shutdown_marker_path(), marker)
            self._maintenance_marker_path().unlink(missing_ok=True)
        else:
            _maint.discard_resume_markers(self._state_dir())
        self.discard_crash_snapshot_for_kill_switch()
        # The host recovery timer respects this latch. The wrapper clears it
        # on its next explicit start or boot autostart, not on stop.
        _maint.write_marker(
            _maint.shutdown_sentinel_path(self._state_dir()),
            _maint.ResumeMarker(requested_at, source, []),
        )
        return entries

    async def request_shutdown(
        self, *, route: TelegramRoute, bot: Any, autoresume: bool, source: str,
        delay_seconds: float = 1.0,
    ) -> int:
        """Stage an optional durable checkpoint, then leave Supervisor STOPPED."""
        if self._maintenance_restart_requested:
            return 0
        self._maintenance_restart_requested = True
        requested_at = time.time()
        try:
            self._stage_shutdown(autoresume=autoresume, source=source, requested_at=requested_at)
            try:
                await self._send_system_message(
                    route=route, bot=bot,
                    text=(
                        "shutdown: auto-resume staged. Stopping OBS only; the computer stays on. "
                        "Agents still running at shutdown will resume once at the next OBS startup, "
                        "even after a long outage."
                        if autoresume else
                        "shutdown: stopping OBS only; the computer stays on. No running agents will auto-resume."
                    ),
                    disable_notification=True,
                )
            except Exception:
                logger.debug("shutdown notice failed", exc_info=True)
            if delay_seconds > 0:
                await asyncio.sleep(delay_seconds)
            # The notice/delay yielded to running agents and /stop commands.
            # Refresh after all awaits, then synchronously stop: no new turn,
            # completion or explicit stop can slip between checkpoint and stop.
            entries = self._stage_shutdown(autoresume=autoresume, source=source, requested_at=requested_at)
            logger.warning("[shutdown] requested source=%s autoresume=%s routes=%d", source, autoresume, len(entries))
            _maint.stop_daemon()
            return len(entries)
        except Exception:
            _maint.shutdown_sentinel_path(self._state_dir()).unlink(missing_ok=True)
            _maint.discard_resume_markers(self._state_dir())
            self._maintenance_restart_requested = False
            self._crash_snapshot_disabled = False
            logger.exception("[shutdown] preparation or Supervisor stop failed; OBS remains running")
            await self._send_system_message(
                route=route, bot=bot,
                text="shutdown failed; OBS is still running and no auto-resume is staged.",
                disable_notification=True,
            )
            return 0

    async def request_plain_restart(self, *, route: TelegramRoute, bot: Any, source: str, delay_seconds: float = 1.0) -> None:
        """Kill-switch restart from inside the daemon: discard every resume file, then exit."""
        if self._maintenance_restart_requested:
            return
        self._maintenance_restart_requested = True
        _maint.discard_resume_markers(self._state_dir())
        self.discard_crash_snapshot_for_kill_switch()
        logger.warning("[plain_restart] requested source=%s; nothing will be resumed", source)
        try:
            await self._send_system_message(
                route=route,
                bot=bot,
                text="plain restart: OBS restarts and nothing is resumed (kill switch).",
                disable_notification=True,
            )
        except Exception:
            logger.debug("plain restart notice failed", exc_info=True)
        if delay_seconds > 0:
            await asyncio.sleep(delay_seconds)
        self._maintenance_terminate()

    def _mark_restored_team_inboxes_read(self, inbox_keys: set[tuple[str, str]]) -> None:
        for team_name, agent_name in sorted(inbox_keys):
            inbox_path = self._team_inbox_path(team_name, agent_name)
            if not inbox_path.exists():
                continue
            try:
                entries = json.loads(inbox_path.read_text(encoding="utf-8"))
            except Exception:
                logger.debug("Failed reading restored team inbox for startup mark-read: %s", inbox_path, exc_info=True)
                continue
            if not isinstance(entries, list):
                continue
            changed = False
            for item in entries:
                if isinstance(item, dict) and not bool(item.get("read", False)):
                    if self._outage_inbox_floor is not None:
                        # B9: restarting is not a read acknowledgement. A launcher
                        # may not yet have consumed its pre-outage final report.
                        continue
                    message_ts = self._try_parse_rfc3339_timestamp(item.get("timestamp"))
                    if message_ts is not None and message_ts >= self._inbox_wake_floor:
                        # Sent during the outage of a non-kill-switch restart:
                        # leave unread so the inbox poller wakes the agent.
                        continue
                    item["read"] = True
                    changed = True
            if not changed:
                continue
            try:
                inbox_path.write_text(json.dumps(entries, ensure_ascii=True), encoding="utf-8")
                logger.info(
                    "Marked restored team inbox messages read on daemon startup: team=%s agent=%s",
                    team_name,
                    agent_name,
                )
            except Exception:
                logger.debug("Failed writing restored team inbox startup mark-read: %s", inbox_path, exc_info=True)

    def _set_topic_metadata(
        self,
        *,
        route: TelegramRoute,
        title: str | None = None,
        icon_custom_emoji_id: str | None = None,
    ) -> None:
        existing = self._topic_metadata_by_route.get(route, _TopicMetadata())
        next_title = existing.title
        next_icon = existing.icon_custom_emoji_id
        if isinstance(title, str):
            stripped = title.strip()
            next_title = stripped or next_title
        if isinstance(icon_custom_emoji_id, str):
            stripped_icon = icon_custom_emoji_id.strip()
            next_icon = stripped_icon or next_icon
        updated = _TopicMetadata(title=next_title, icon_custom_emoji_id=next_icon)
        self._topic_metadata_by_route[route] = updated

        state = self._get_state(route, create=False)
        if state is not None:
            if updated.title:
                state.topic_title = updated.title
            if updated.icon_custom_emoji_id:
                state.topic_icon_custom_emoji_id = updated.icon_custom_emoji_id
            self._persist_state_for_route(route)

    def _update_topic_metadata_from_message(self, message) -> None:
        route = self._route_for_message(message)
        if route.thread_id is None:
            return
        created = getattr(message, "forum_topic_created", None)
        edited = getattr(message, "forum_topic_edited", None)
        title = None
        icon_custom_emoji_id = None
        if created is not None:
            title = getattr(created, "name", None) or title
            icon_custom_emoji_id = (
                getattr(created, "icon_custom_emoji_id", None) or icon_custom_emoji_id
            )
        if edited is not None:
            title = (
                getattr(edited, "name", None)
                or getattr(edited, "title", None)
                or title
            )
            edited_icon = getattr(edited, "icon_custom_emoji_id", None)
            if isinstance(edited_icon, str):
                icon_custom_emoji_id = edited_icon
        self._set_topic_metadata(
            route=route,
            title=title,
            icon_custom_emoji_id=icon_custom_emoji_id,
        )

    def _active_fork_task_ids(self) -> set[str]:
        """Every task id some route currently lists as an active child, in one pass."""
        active: set[str] = set()
        for state in self._states_by_route.values():
            if state.active_fork_task_ids:
                active.update(state.active_fork_task_ids)
        return active

    def _is_fork_task_running(
        self,
        record: _ForkTaskRecord,
        *,
        completing_task_id: str | None = None,
        active_task_ids: set[str] | None = None,
    ) -> bool:
        """``active_task_ids``: a ``_active_fork_task_ids()`` result taken with no
        await since, for callers that test many records (obs-54: testing each of
        ~11k records against ~7k routes blocked the event loop 2-7 s per idle
        sweep)."""
        if record.task_id == completing_task_id:
            return False
        task = self._fork_task_tasks.get(record.task_id)
        if task is not None and not task.done():
            return True
        if active_task_ids is not None:
            return record.task_id in active_task_ids
        return any(record.task_id in state.active_fork_task_ids for state in self._states_by_route.values())

    def _idle_claude_process_candidates(
        self,
        *,
        completing_task_id: str | None = None,
        skip_reasons: dict[str, int] | None = None,
    ) -> list[_IdleClaudeProcessCandidate]:
        def skip(reason: str) -> None:
            if skip_reasons is not None:
                skip_reasons[reason] = skip_reasons.get(reason, 0) + 1

        candidates: list[_IdleClaudeProcessCandidate] = []
        active_task_ids = self._active_fork_task_ids()
        for record in self._fork_tasks_by_id.values():
            if not record.idle_ready:
                skip("not_idle_ready")
                continue
            if not (record.team_name or "").strip() or not (record.agent_name or "").strip():
                skip("missing_team_or_agent")
                continue
            if self._is_fork_task_running(
                record, completing_task_id=completing_task_id, active_task_ids=active_task_ids,
            ):
                skip("running")
                continue
            child_state = self._states_by_route.get(record.child_route)
            if child_state is None:
                skip("missing_child_state")
                continue
            if child_state.busy:
                skip("busy")
                continue
            if child_state.hook_state.execution_active:
                skip("execution_active")
                continue
            if not child_state.session_manager.has_connected_client():
                skip("no_connected_client")
                continue
            candidates.append(
                _IdleClaudeProcessCandidate(
                    record=record,
                    state=child_state,
                    idle_at=record.completed_at or record.created_at,
                )
            )
        candidates.sort(key=lambda candidate: (candidate.idle_at, candidate.record.task_id))
        return candidates

    async def _prune_idle_claude_processes(
        self,
        *,
        completing_task_id: str | None = None,
    ) -> int:
        skip_reasons: dict[str, int] = {}
        candidates = self._idle_claude_process_candidates(
            completing_task_id=completing_task_id,
            skip_reasons=skip_reasons,
        )
        cap = self._config.claude_idle_process_cap
        kill_on_idle = self._config.claude_kill_on_idle
        mode = "disabled"
        overage = 0
        to_prune: list[_IdleClaudeProcessCandidate] = []

        if kill_on_idle:
            mode = "kill_on_idle"
            to_prune = candidates
            overage = len(candidates)
        else:
            if cap is not None:
                mode = "cap"
                overage = len(candidates) - max(cap, 0)
                if overage > 0:
                    to_prune = candidates[:overage]
            evict_after = float(getattr(self._config, "claude_idle_evict_seconds", 0.0) or 0.0)
            if evict_after > 0:
                # vault-u3b.78: age-based eviction on top of any cap.
                now = time.time()
                selected = {id(candidate) for candidate in to_prune}
                aged = [
                    candidate
                    for candidate in candidates
                    if id(candidate) not in selected and now - candidate.idle_at >= evict_after
                ]
                to_prune = to_prune + aged
                mode = "cap+age" if mode == "cap" else "age"
                overage = max(overage, 0) + len(aged)

        if mode == "disabled":
            logger.debug(
                "Claude idle process pruning skipped mode=%s cap=%s kill_on_idle=%s candidates=%d overage=%d skips=%s completing_task_id=%s",
                mode,
                cap,
                kill_on_idle,
                len(candidates),
                overage,
                skip_reasons,
                completing_task_id,
            )
            return 0
        if not to_prune:
            logger.info(
                "Claude idle process pruning skipped mode=%s cap=%s kill_on_idle=%s candidates=%d overage=%d skips=%s completing_task_id=%s",
                mode,
                cap,
                kill_on_idle,
                len(candidates),
                overage,
                skip_reasons,
                completing_task_id,
            )
            return 0

        selected_task_ids = [candidate.record.task_id for candidate in to_prune]
        pruned = 0
        prune_skip_reasons: dict[str, int] = {}
        for candidate in to_prune:
            if self._is_fork_task_running(candidate.record, completing_task_id=completing_task_id):
                prune_skip_reasons["became_running"] = prune_skip_reasons.get("became_running", 0) + 1
                continue
            if candidate.state.busy:
                prune_skip_reasons["became_busy"] = prune_skip_reasons.get("became_busy", 0) + 1
                continue
            if candidate.state.hook_state.execution_active:
                prune_skip_reasons["became_execution_active"] = prune_skip_reasons.get("became_execution_active", 0) + 1
                continue
            if await candidate.state.session_manager.disconnect_idle_client(direct_kill=True):
                pruned += 1
            else:
                prune_skip_reasons["disconnect_no_client"] = prune_skip_reasons.get("disconnect_no_client", 0) + 1

        logger.info(
            "Claude idle process pruning mode=%s cap=%s kill_on_idle=%s candidates=%d selected=%d pruned=%d overage=%d skips=%s prune_skips=%s selected_task_ids=%s completing_task_id=%s",
            mode,
            cap,
            kill_on_idle,
            len(candidates),
            len(to_prune),
            pruned,
            overage,
            skip_reasons,
            prune_skip_reasons,
            selected_task_ids,
            completing_task_id,
        )
        return pruned

    def _build_session_state(
        self,
        route: TelegramRoute,
        *,
        topic_title: str | None = None,
    ) -> TelegramSessionState:
        hook_state = HookState()
        state = TelegramSessionState(
            route=route,
            hook_state=hook_state,
            session_manager=SessionManager(config=self._config, hook_state=hook_state),
            topic_title=topic_title
            or self._topic_metadata_for_route(route).title
            or self._default_topic_title(route),
            topic_icon_custom_emoji_id=self._topic_metadata_for_route(route).icon_custom_emoji_id,
        )
        hook_state.fork_task_launcher = self._make_fork_task_launcher(route)
        hook_state.fork_task_outputter = self._make_fork_task_outputter(route)
        hook_state.fork_task_stopper = self._make_fork_task_stopper(route)
        hook_state.cron_creator = self._make_cron_creator(route)
        hook_state.cron_lister = self._make_cron_lister(route)
        hook_state.cron_deleter = self._make_cron_deleter(route)
        hook_state.inbox_recipient_validator = self._make_inbox_recipient_validator(route)
        hook_state.inbox_message_notifier = self._make_inbox_message_notifier(route)
        hook_state.stop_event_notifier = self._make_stop_event_notifier(route)
        hook_state.context_snapshot_provider = self._make_context_snapshot_provider(route)
        hook_state.team_status_provider = self._make_team_status_provider(route)
        hook_state.vault_path = self._config.vault_path
        return state

    def _get_state(
        self,
        route: TelegramRoute,
        *,
        create: bool = True,
        topic_title: str | None = None,
        apply_default_new_chat_hooks: bool = True,
    ) -> TelegramSessionState | None:
        state = self._states_by_route.get(route)
        if state is None and create:
            state = self._build_session_state(route, topic_title=topic_title)
            if apply_default_new_chat_hooks and self._default_new_chat_hooks is not None:
                state.session_manager.user_hooks = dict(self._default_new_chat_hooks)
            new_effort = getattr(self._config, "new_session_effort_level", None)
            if new_effort and state.session_manager.effort_override is None:
                # Saved per route: restored sessions never reach this branch.
                state.session_manager.effort_override = new_effort
            self._states_by_route[route] = state
            self._persist_state_for_route(route)
            self._maybe_seed_default_schedule(route=route)
        if state is not None and topic_title:
            if not state.topic_title:
                state.topic_title = topic_title
            self._set_topic_metadata(route=route, title=topic_title)
        return state

    def _bind_state_session(self, state: TelegramSessionState) -> None:
        session_id = state.session_id
        if session_id:
            self._route_by_session_id[session_id] = state.route
            self._upsert_route_inbox_target(state)
            self._persist_state_for_route(state.route)
            self._record_task_session(state, session_id)

    def _record_task_session(self, state: TelegramSessionState, session_id: str) -> None:
        """Put the route's current session id on its AgentTask handle, durably (vault-1i53).

        Runs on every event of a run, so a fresh child's handle names its session
        from the CLI's init message on, not from its first wake or resume:
        AgentTaskOutput, AgentTaskStop, the rounds watchdog and crash recovery
        can find a child that is still in, or died in, its first turn.
        """
        record = self._find_task_by_child_route(state.route)
        if record is None or record.child_session_id == session_id:
            return
        previous = record.child_session_id
        record.child_session_id = session_id
        self._persist_task_handle_record(record)
        self._persist_team_worker_record(record)
        logger.info(
            "[agent_task] session recorded task_id=%s agent=%s session_id=%s previous=%s route=%s",
            record.task_id,
            record.agent_name,
            session_id,
            previous or None,
            state.route,
        )

    def _unbind_route_sessions(self, route: TelegramRoute) -> None:
        stale = [session_id for session_id, mapped_route in self._route_by_session_id.items() if mapped_route == route]
        for session_id in stale:
            self._route_by_session_id.pop(session_id, None)

    def _get_route_lock(self, route: TelegramRoute) -> asyncio.Lock:
        lock = self._route_locks.get(route)
        if lock is None:
            lock = asyncio.Lock()
            self._route_locks[route] = lock
        return lock

    def _make_fork_task_launcher(self, route: TelegramRoute):
        async def _launch(args: dict[str, Any]) -> dict[str, Any]:
            return await self._launch_fork_task(route=route, args=args)

        return _launch

    def _make_fork_task_outputter(self, route: TelegramRoute):
        async def _output(args: dict[str, Any]) -> dict[str, Any]:
            return await self._fork_task_output(route=route, args=args)

        return _output

    def _make_fork_task_stopper(self, route: TelegramRoute):
        async def _stop(args: dict[str, Any]) -> dict[str, Any]:
            return await self._fork_task_stop(route=route, args=args)

        return _stop

    def _make_cron_creator(self, route: TelegramRoute):
        async def _create(args: dict[str, Any]) -> dict[str, Any]:
            return await self._cron_create(route=route, args=args)

        return _create

    def _make_cron_lister(self, route: TelegramRoute):
        async def _list(args: dict[str, Any]) -> dict[str, Any]:
            _ = args
            return await self._cron_list(route=route)

        return _list

    def _make_cron_deleter(self, route: TelegramRoute):
        async def _delete(args: dict[str, Any]) -> dict[str, Any]:
            return await self._cron_delete(route=route, args=args)

        return _delete

    def _make_inbox_message_notifier(self, route: TelegramRoute):
        async def _notify(payload: dict[str, Any]) -> dict[str, Any] | None:
            return await self._handle_inbox_message_notification(
                sender_route=route,
                payload=payload,
            )

        return _notify

    @staticmethod
    def _notification_failure_reason(exc: Exception) -> str:
        if isinstance(exc, _TopicDeletedError):
            return "recipient topic was deleted"
        message = str(exc).strip()
        if "child_state is none" in message.lower():
            return "recipient has no current route binding"
        return message or "recipient wake failed"

    def _make_inbox_recipient_validator(self, route: TelegramRoute):
        async def _validate(payload: dict[str, Any]) -> dict[str, Any]:
            _ = route
            team_name = str(payload.get("team_name") or "").strip() or None
            agent_name = str(payload.get("recipient") or "").strip() or None
            status = self._recipient_delivery_status(team_name=team_name, agent_name=agent_name)
            if not status.get("deliverable") or payload.get("allow_cold_wake"):
                return status
            readiness = self._recipient_cache_readiness(team_name=team_name, agent_name=agent_name)
            if readiness is not None and readiness.cold:
                logger.info(
                    "[cache_readiness] blocked inbox wake team=%s recipient=%s idle=%.0fs family=%s",
                    team_name,
                    agent_name,
                    readiness.idle_seconds or 0,
                    readiness.family,
                )
                return {
                    "deliverable": False,
                    "cold": True,
                    "reason": _cache_readiness.cold_warning(
                        readiness, action="message to", target=agent_name or "recipient"
                    ),
                    "transcript": str(readiness.jsonl_path) if readiness.jsonl_path else None,
                }
            return status

        return _validate

    def _fork_source_model(
        self,
        *,
        state: TelegramSessionState,
        source_session_id: str | None,
        source_jsonl_path: Path | None,
        explicit: bool,
    ) -> "_fork_model.SourceModel":
        """Model and effort of the session a fork copies (fork_model.py)."""
        if not explicit or not source_session_id or source_session_id == state.session_id:
            return _fork_model.SourceModel(
                state.session_manager.effective_model,
                state.session_manager.effective_effort,
                "launcher",
            )
        route = self._route_by_session_id.get(source_session_id)
        owner = self._get_state(route, create=False) if route is not None else None
        if owner is not None and owner.session_id == source_session_id:
            return _fork_model.SourceModel(
                owner.session_manager.effective_model,
                owner.session_manager.effective_effort,
                "route",
            )
        jsonl_path = source_jsonl_path or find_session_jsonl(
            session_id=source_session_id, cwd=self._config.vault_path
        )
        model = _fork_model.jsonl_model(jsonl_path)
        if model:
            return _fork_model.SourceModel(model, None, "jsonl")
        raise _fork_model.ForkModelError(
            f"cannot determine the model of session_source {source_session_id}: no live route owns "
            "it and its transcript has no model record. Pass model explicitly."
        )

    def _state_cache_readiness(
        self,
        *,
        state: TelegramSessionState | None,
        session_id: str | None,
    ) -> "_cache_readiness.Readiness | None":
        """Read-only cache-readiness of a target session (vault-vokl); None when unknown."""
        session_id = session_id or (state.session_id if state is not None else None)
        if not session_id:
            return None
        running = bool(state is not None and (state.busy or state.hook_state.execution_active))
        model_hint = None
        if state is not None:
            try:
                model_hint = state.session_manager.effective_model
                if callable(model_hint):
                    model_hint = model_hint()
            except Exception:
                model_hint = None
        try:
            jsonl_path = find_session_jsonl(session_id=session_id, cwd=self._config.vault_path)
            return _cache_readiness.assess(
                jsonl_path=jsonl_path,
                model_hint=model_hint if isinstance(model_hint, str) else None,
                running=running,
            )
        except Exception:
            logger.debug("cache readiness check failed session=%s", session_id, exc_info=True)
            return None

    def _recipient_cache_readiness(
        self,
        *,
        team_name: str | None,
        agent_name: str | None,
    ) -> "_cache_readiness.Readiness | None":
        record = self._resolve_team_worker_record(team_name=team_name, agent_name=agent_name)
        if record is not None:
            state = self._get_state(record.child_route, create=False)
            return self._state_cache_readiness(
                state=state,
                session_id=(state.session_id if state is not None else None) or record.child_session_id,
            )
        state = self._resolve_route_inbox_target(team_name=team_name, agent_name=agent_name)
        if state is None:
            return None
        return self._state_cache_readiness(state=state, session_id=state.session_id)

    def _make_stop_event_notifier(self, route: TelegramRoute):
        async def _notify(payload: dict[str, Any]) -> None:
            self._schedule_stop_events.put_nowait((route, payload))

        return _notify

    def _make_context_snapshot_provider(self, route: TelegramRoute):
        def _snapshot(**_: Any) -> dict[str, Any]:
            return self._build_hook_context_snapshot(route)

        return _snapshot

    def _make_team_status_provider(self, route: TelegramRoute):
        _ = route

        def _status(*, team_name: str | None = None, **_: Any) -> dict[tuple[str, str], dict[str, Any]]:
            requested_team = (team_name or "").strip()
            records: dict[tuple[str, str], dict[str, Any]] = {}
            active_task_ids = self._active_fork_task_ids()
            for record in self._fork_tasks_by_id.values():
                record_team = (record.team_name or "").strip()
                record_agent = (record.agent_name or "").strip()
                if not record_team or not record_agent or (requested_team and record_team != requested_team):
                    continue
                running = self._is_fork_task_running(record, active_task_ids=active_task_ids)
                child_state = self._states_by_route.get(record.child_route)
                if child_state is not None:
                    running = running or child_state.busy or child_state.hook_state.execution_active
                if running:
                    runtime_status = "running"
                elif record.idle_ready:
                    runtime_status = "idle"
                elif record.status in {"completed", "failed", "stopped"}:
                    runtime_status = record.status
                else:
                    runtime_status = "unknown"
                payload: dict[str, Any] = {
                    "team_name": record_team,
                    "agent_name": record_agent,
                    "session_id": record.child_session_id,
                    "running": running,
                    "runtime_status": runtime_status,
                    "task_status": record.status,
                    "idle_ready": record.idle_ready,
                    "created_at": record.created_at,
                }
                if record.completed_at is not None:
                    payload["completed_at"] = record.completed_at
                if child_state is not None and child_state.session_manager.last_activity is not None:
                    payload["last_activity"] = child_state.session_manager.last_activity
                records[(record_team, record_agent)] = payload
            for state in self._states_by_route.values():
                projection = self._state_inbox_projection(state, allow_jsonl_lookup=False)
                if projection is None or (requested_team and projection[0] != requested_team):
                    continue
                state_team, state_agent = projection
                payload = records.setdefault(
                    (state_team, state_agent),
                    {
                        "team_name": state_team,
                        "agent_name": state_agent,
                        "session_id": state.session_id,
                    },
                )
                running = bool(state.busy or state.hook_state.execution_active)
                payload["running"] = running
                payload["runtime_status"] = "running" if running else payload.get("runtime_status", "unknown")
                if state.session_manager.last_activity is not None:
                    payload["last_activity"] = state.session_manager.last_activity
            return records

        return _status

    def _is_authorized(self, user_id: int) -> bool:
        # SECURITY: empty allowed list = NO ONE can use the bot (deny by default)
        allowed = self._config.telegram_allowed_user_ids
        return bool(allowed) and user_id in allowed

    def _route_has_active_fork_tasks(self, state: TelegramSessionState) -> bool:
        return bool(state.active_fork_task_ids)

    def _should_emit_completion_summary(self, state: TelegramSessionState) -> bool:
        # Keep completion markers consistent across user topics, forks, and
        # delegated workers. Per-route suppression caused missing terminal
        # markers in child topics while scheduled runs still emitted summaries.
        _ = state
        return True

    def _current_topic_base(self, state: TelegramSessionState) -> str:
        return (state.topic_title or self._default_topic_title(state.route)).strip()

    def _current_topic_title(self, route: TelegramRoute) -> str:
        state = self._get_state(route, create=False)
        if state is None:
            return self._default_topic_title(route)
        return self._current_topic_base(state)

    def _build_hook_context_snapshot(self, route: TelegramRoute) -> dict[str, Any]:
        state = self._get_state(route, create=False)
        route_payload: dict[str, Any] = {
            "chat_id": route.chat_id,
            "thread_id": route.thread_id,
        }
        topic_metadata = self._topic_metadata_for_route(route)
        topic_title = (
            state.topic_title
            if state is not None and state.topic_title
            else topic_metadata.title
            or self._default_topic_title(route)
        )
        topic_payload: dict[str, Any] = {"title": topic_title}
        if topic_metadata.icon_custom_emoji_id:
            topic_payload["icon_custom_emoji_id"] = topic_metadata.icon_custom_emoji_id
        session_payload: dict[str, Any] = {
            "session_id": state.session_id if state is not None else None,
        }
        if state is not None:
            head = self._session_heads.get(state.session_id or "")
            if head:
                session_payload["head_uuid"] = head
        team_payload: dict[str, Any] | None = None
        if state is not None:
            projection = self._state_inbox_projection(state)
            if projection is not None:
                lineage = state.agent_lineage
                bootstrap = None
                if state.pending_obs_bootstrap:
                    try:
                        bootstrap = parse_obs_bootstrap_xml(state.pending_obs_bootstrap)
                    except Exception:
                        bootstrap = None
                if not lineage and bootstrap is not None and bootstrap.lineage:
                    lineage = bootstrap.lineage
                team_payload = {
                    "team_name": projection[0],
                    "agent_name": projection[1],
                    "lineage": list(lineage or ()),
                }
        effective_model = None
        if state is not None:
            effective_model = state.session_manager.model_override or self._config.model
        return {
            "route": route_payload,
            "team": team_payload,
            "session": session_payload,
            "topic": topic_payload,
            "effective_model": effective_model or self._config.model,
        }

    def _next_auto_child_alias(self, state: TelegramSessionState) -> str:
        base = self._current_topic_base(state)
        if state.child_fork_base_title != base:
            state.child_fork_base_title = base
            state.child_fork_count = 0
        state.child_fork_count += 1
        self._persist_state_for_route(state.route)
        return f"F{state.child_fork_count}"

    def _child_topic_title_from_alias(self, state: TelegramSessionState, alias: str) -> str:
        _ = state
        label = normalize_lineage_name(alias)
        return (label or "F").strip()[:128]

    def _next_auto_child_title(self, state: TelegramSessionState) -> str:
        return self._child_topic_title_from_alias(state, self._next_auto_child_alias(state))

    def _next_topic_alias_and_title(
        self,
        state: TelegramSessionState,
        explicit: str | None,
    ) -> tuple[str, str]:
        alias = normalize_lineage_name(explicit)
        if alias:
            return alias, self._child_topic_title_from_alias(state, alias)
        alias = self._next_auto_child_alias(state)
        return alias, self._child_topic_title_from_alias(state, alias)

    def _ensure_state_lineage(
        self,
        state: TelegramSessionState,
        *,
        session_id: str | None = None,
    ) -> tuple[str, ...]:
        if state.agent_lineage:
            return state.agent_lineage
        if state.pending_obs_bootstrap:
            try:
                pending_bootstrap = parse_obs_bootstrap_xml(state.pending_obs_bootstrap)
            except Exception:
                pending_bootstrap = None
            if pending_bootstrap is not None and pending_bootstrap.lineage:
                state.agent_lineage = pending_bootstrap.lineage
                return pending_bootstrap.lineage
        bootstrap = find_latest_obs_bootstrap_for_session(
            session_id=session_id or state.session_id,
            cwd=self._config.vault_path,
        )
        if bootstrap is not None and bootstrap.lineage:
            state.agent_lineage = bootstrap.lineage
            return bootstrap.lineage
        root_name = normalize_lineage_name(self._current_topic_base(state)) or "General"
        state.agent_lineage = (root_name,)
        return state.agent_lineage

    def _default_team_projection(
        self,
        lineage: tuple[str, ...],
    ) -> tuple[str, str]:
        team_key = root_team_key_for_lineage(lineage)
        if len(lineage) <= 1:
            # Trunk: agent_name = team_key (they must be identical)
            return team_key, team_key
        return team_key, agent_name_for_lineage(lineage)

    def _get_parent_team_key(self, state: TelegramSessionState) -> str | None:
        """Extract the root_team_key from a state's SDK env overrides or bootstrap."""
        env = state.session_manager.sdk_env_overrides
        team = env.get("CLAUDE_CODE_TEAM_NAME", "").strip()
        if team:
            return team
        # Fallback: check pending bootstrap
        if state.pending_obs_bootstrap:
            try:
                bootstrap = parse_obs_bootstrap_xml(state.pending_obs_bootstrap)
                if bootstrap.root_team_key:
                    return bootstrap.root_team_key
            except Exception:
                pass
        return None

    def _state_inbox_projection(
        self,
        state: TelegramSessionState,
        *,
        allow_jsonl_lookup: bool = True,
        allow_default_projection: bool = True,
    ) -> tuple[str, str] | None:
        bootstrap = None
        if state.pending_obs_bootstrap:
            try:
                bootstrap = parse_obs_bootstrap_xml(state.pending_obs_bootstrap)
            except Exception:
                bootstrap = None
        lineage = state.agent_lineage
        if not lineage and bootstrap is not None and bootstrap.lineage:
            lineage = bootstrap.lineage
        session_bootstrap = (
            find_latest_obs_bootstrap_for_session(
                session_id=state.session_id,
                cwd=self._config.vault_path,
            )
            if allow_jsonl_lookup
            else None
        )
        if session_bootstrap is not None and not lineage and session_bootstrap.lineage:
            lineage = session_bootstrap.lineage
        if not lineage:
            return None
        env = state.session_manager.sdk_env_overrides
        team_name = (
            bootstrap.root_team_key
            if bootstrap is not None and bootstrap.root_team_key
            else None
        ) or env.get("CLAUDE_CODE_TEAM_NAME", "").strip() or (
            session_bootstrap.root_team_key if session_bootstrap is not None else ""
        )
        agent_name = (
            bootstrap.agent_name
            if bootstrap is not None and bootstrap.agent_name
            else None
        ) or env.get("CLAUDE_CODE_AGENT_NAME", "").strip() or (
            session_bootstrap.agent_name if session_bootstrap is not None else ""
        )
        if allow_default_projection and (not team_name or not agent_name):
            default_team_name, default_agent_name = self._default_team_projection(lineage)
            team_name = team_name or default_team_name
            if not agent_name:
                agent_name = team_name if len(lineage) <= 1 else default_agent_name
        key = self._team_worker_key(team_name, agent_name)
        if key is None:
            return None
        return key

    def _remove_route_inbox_target(self, route: TelegramRoute) -> None:
        existing_key = self._route_inbox_target_keys_by_route.pop(route, None)
        if existing_key is None:
            return
        mapped_route = self._route_inbox_targets.get(existing_key)
        if mapped_route == route:
            self._route_inbox_targets.pop(existing_key, None)

    def _upsert_route_inbox_target(
        self,
        state: TelegramSessionState,
        *,
        allow_jsonl_lookup: bool = True,
        persist_projection_config: bool = True,
    ) -> None:
        key = self._state_inbox_projection(
            state,
            allow_jsonl_lookup=allow_jsonl_lookup,
            allow_default_projection=True,
        )
        if key is None:
            self._remove_route_inbox_target(state.route)
            return
        bootstrap = None
        if state.pending_obs_bootstrap:
            try:
                bootstrap = parse_obs_bootstrap_xml(state.pending_obs_bootstrap)
            except Exception:
                bootstrap = None
        lineage = state.agent_lineage
        if (not lineage) and bootstrap is not None and bootstrap.lineage:
            lineage = bootstrap.lineage
        obs_metadata = self._build_team_projection_obs_metadata(
            lineage=lineage,
            team_name=key[0],
            agent_name=key[1],
            route=state.route,
            parent_agent_name=bootstrap.parent_agent_name if bootstrap is not None else None,
            parent_display_name=bootstrap.parent_display_name if bootstrap is not None else None,
        )
        self._remove_route_inbox_target(state.route)
        self._route_inbox_targets[key] = state.route
        self._route_inbox_target_keys_by_route[state.route] = key
        if not persist_projection_config:
            return
        self._upsert_team_projection_config(
            team_name=key[0],
            agent_name=key[1],
            child_session_id=state.session_id,
            obs_metadata=obs_metadata,
        )

    def _prime_obs_bootstrap(
        self,
        state: TelegramSessionState,
        *,
        lineage: tuple[str, ...],
        origin: str,
        is_fork: bool,
        agent_id: str | None = None,
        parent_session_id: str | None = None,
        team_name: str | None = None,
        agent_name: str | None = None,
        session_id: str | None = None,
    ) -> str:
        normalized_lineage = tuple(
            item
            for item in (normalize_lineage_name(value) for value in lineage)
            if item
        )
        state.agent_lineage = normalized_lineage
        resolved_team_name = (team_name or "").strip() or None
        resolved_agent_name = (agent_name or "").strip() or None
        if resolved_team_name is None or resolved_agent_name is None:
            default_team_name, default_agent_name = self._default_team_projection(normalized_lineage)
            resolved_team_name = resolved_team_name or default_team_name
            resolved_agent_name = resolved_agent_name or default_agent_name
        parent_agent_name: str | None = None
        parent_display_name: str | None = None
        if len(normalized_lineage) > 1:
            parent_lineage = normalized_lineage[:-1]
            parent_display_name = parent_lineage[-1]
            if len(parent_lineage) == 1:
                parent_display_name = format_root_display_name(
                    resolved_team_name,
                    parent_display_name,
                )
            parent_agent_name = agent_name_for_lineage(
                parent_lineage,
                team_key=resolved_team_name,
            )
        bootstrap_xml = build_obs_bootstrap_xml(
            lineage=normalized_lineage,
            origin=origin,
            is_fork=is_fork,
            session_id=session_id or state.session_id,
            agent_id=agent_id,
            parent_session_id=parent_session_id,
            root_team_key=resolved_team_name,
            agent_name=resolved_agent_name,
            parent_agent_name=parent_agent_name,
            parent_display_name=parent_display_name,
        )
        bootstrap_env = {
            **state.session_manager.sdk_env_overrides,
            **self._build_team_worker_env(
                team_name=resolved_team_name,
                agent_name=resolved_agent_name,
            ),
        }
        state.session_manager.set_sdk_env_overrides(bootstrap_env)
        self._upsert_team_projection_config(
            team_name=resolved_team_name,
            agent_name=resolved_agent_name,
            child_session_id=session_id or state.session_id,
            obs_metadata=self._build_team_projection_obs_metadata(
                lineage=normalized_lineage,
                team_name=resolved_team_name,
                agent_name=resolved_agent_name,
                route=state.route,
                parent_agent_name=parent_agent_name,
                parent_display_name=parent_display_name,
            ),
        )
        state.pending_obs_bootstrap = bootstrap_xml
        # Also store in hook_state so session_lineage can find it on first turn
        # (before the JSONL has the bootstrap written).
        if state.hook_state is not None:
            state.hook_state.pending_obs_bootstrap_xml = bootstrap_xml
        self._upsert_route_inbox_target(state)
        self._persist_state_for_route(state.route)
        return bootstrap_xml

    @staticmethod
    def _cron_error_result(text: str) -> dict[str, Any]:
        return {
            "content": [{"type": "text", "text": text}],
            "tool_use_result": {"error": text},
            "is_error": True,
        }

    @staticmethod
    def _cron_ok_result(payload: dict[str, Any]) -> dict[str, Any]:
        return {
            "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=True)}],
            "tool_use_result": payload,
        }

    @staticmethod
    def _parse_supported_cron_interval_seconds(expr: str) -> int | None:
        normalized = expr.strip().lower()
        if normalized == "@hourly":
            return 60 * 60
        if normalized == "@daily":
            return 24 * 60 * 60
        parts = normalized.split()
        if len(parts) != 5:
            return None
        minute, hour, day_of_month, month, day_of_week = parts

        def _step_value(token: str) -> int | None:
            if not token.startswith("*/"):
                return None
            raw = token[2:]
            if not raw.isdigit():
                return None
            value = int(raw)
            if value <= 0:
                return None
            return value

        if (
            (minutes := _step_value(minute)) is not None
            and hour == "*"
            and day_of_month == "*"
            and month == "*"
            and day_of_week == "*"
        ):
            return minutes * 60
        if (
            minute == "0"
            and (hours := _step_value(hour)) is not None
            and day_of_month == "*"
            and month == "*"
            and day_of_week == "*"
        ):
            return hours * 60 * 60
        if (
            minute == "0"
            and hour == "0"
            and (days := _step_value(day_of_month)) is not None
            and month == "*"
            and day_of_week == "*"
        ):
            return days * 24 * 60 * 60
        return None

    @staticmethod
    def _parse_rfc3339_timestamp(raw_value: str | None) -> float | None:
        if raw_value is None:
            return None
        normalized = raw_value.strip()
        if not normalized:
            return None
        if normalized.endswith("Z"):
            normalized = f"{normalized[:-1]}+00:00"
        parsed = datetime.fromisoformat(normalized)
        return parsed.timestamp()

    @staticmethod
    def _try_parse_rfc3339_timestamp(raw_value: object) -> float | None:
        if not isinstance(raw_value, str):
            return None
        try:
            return TelegramBot._parse_rfc3339_timestamp(raw_value)
        except Exception:
            return None

    # Schedule overlap validation removed — multiple schedules coexist freely.
    # Shorter intervals fire first; after max_runs exhaustion, longer ones take over.

    def _next_cron_fire_ts(
        self,
        *,
        cron_expr: str,
        base_ts: float,
        not_before_ts: float | None = None,
    ) -> float:
        if croniter is None:
            raise ValueError("croniter is not installed")
        # Explicit per-schedule UTC survives persistence and fresh-context repairs.
        # Plain expressions retain the ordinary user-timezone behavior.
        schedule_timezone = self._user_timezone
        if cron_expr.startswith("CRON_TZ=UTC "):
            cron_expr = cron_expr[len("CRON_TZ=UTC "):].strip()
            schedule_timezone = timezone.utc
        anchor = datetime.fromtimestamp(base_ts, timezone.utc).astimezone(schedule_timezone)
        try:
            itr = croniter(cron_expr, anchor)
            candidate = float(itr.get_next(float))
        except Exception as exc:
            raise ValueError(str(exc)) from exc
        if not_before_ts is not None and candidate < not_before_ts:
            anchor_nb = datetime.fromtimestamp(
                not_before_ts - 1.0, timezone.utc
            ).astimezone(schedule_timezone)
            try:
                itr = croniter(cron_expr, anchor_nb)
                candidate = float(itr.get_next(float))
            except Exception as exc:
                raise ValueError(str(exc)) from exc
        return candidate

    def _persist_topic_schedule(self, record: _TopicScheduleRecord) -> None:
        self._state_store.upsert_topic_schedule(
            schedule_id=record.schedule_id,
            chat_id=record.route.chat_id,
            thread_id=record.route.thread_id,
            description=record.description,
            schedule_mode=record.schedule_mode,
            cron_expr=record.cron_expr,
            trigger_kind=record.trigger_kind,
            interval_seconds=record.interval_seconds,
            prompt=record.prompt,
            run_mode="reset_session" if record.reset_session else "continue",
            recurring=record.recurring,
            enabled=record.enabled,
            run_count=record.run_count,
            max_runs=record.max_runs,
            from_ts=record.from_ts,
            until_ts=record.until_ts,
            inherit_mode=record.inherit_mode,
            next_run_at=record.next_run_at,
            last_run_at=record.last_run_at,
            last_success_at=record.last_success_at,
            last_error=record.last_error,
            max_retry_attempts=record.max_retry_attempts,
            retry_delay_seconds=record.retry_delay_seconds,
            retry_attempt_count=record.retry_attempt_count,
            prompt_file=record.prompt_file,
        )

    def _ensure_topic_schedule_owner(self, record: _TopicScheduleRecord, *, inherited_from=None):
        try:
            return self._resolve_topic_schedule_owner(record, inherited_from=inherited_from, background=False)
        except Exception:
            logger.warning("Schedule owner deferred; registration continues schedule_id=%s",
                           record.schedule_id, exc_info=True)
            if not hasattr(self, "_pending_schedule_owners"):
                self._pending_schedule_owners = {}
            prior_parent = self._pending_schedule_owners.get(record.schedule_id, (None, None))[1]
            self._pending_schedule_owners[record.schedule_id] = (record, inherited_from or prior_parent)
            return {"bead": None, "source": "pending", "pending": True,
                    "note": "Schedule registered; ownership repair queued off the event loop"}

    def _retire_topic_schedule_owner(self, sid):
        try:
            _schedule_scope.retire_schedule_owner(vault=self._config.vault_path, schedule_id=sid)
        except Exception:
            logger.warning("Schedule owner retirement deferred schedule_id=%s", sid, exc_info=True)
            if not hasattr(self, "_pending_schedule_owner_retirements"):
                self._pending_schedule_owner_retirements = set()
            self._pending_schedule_owner_retirements.add(sid)

    async def _repair_pending_schedule_owners(self):
        if self._schedule_owner_sweep_pending:
            ownership = await asyncio.to_thread(_schedule_scope.ScheduleOwnership.load, self._config.vault_path)
            if not any("owners map unreadable" in error for error in ownership.load_errors):
                self._pending_schedule_owner_retirements.update(
                    ownership.owners.keys() - self._topic_schedules_by_id.keys())
                self._schedule_owner_sweep_pending = False
        for sid in list(getattr(self, "_pending_schedule_owner_retirements", ())):
            try:
                await asyncio.to_thread(_schedule_scope.retire_schedule_owner,
                                        vault=self._config.vault_path, schedule_id=sid, blocking=True)
            except Exception:
                logger.warning("Schedule owner retirement remains pending schedule_id=%s", sid, exc_info=True)
            else:
                self._pending_schedule_owner_retirements.discard(sid)
        for sid, (record, inherited_from) in list(self._pending_schedule_owners.items()):
            if not self._owns_topic_schedule_record(record):
                self._pending_schedule_owners.pop(sid, None)
                self._retire_topic_schedule_owner(sid)
                continue
            try:
                await asyncio.to_thread(self._resolve_topic_schedule_owner, record,
                                        inherited_from=inherited_from, background=True)
            except Exception:
                logger.warning("Schedule ownership repair remains pending schedule_id=%s", sid, exc_info=True)
            else:
                self._pending_schedule_owners.pop(sid, None)
            finally:
                if not self._owns_topic_schedule_record(record):
                    self._retire_topic_schedule_owner(sid)

    def _resolve_topic_schedule_owner(self, record: _TopicScheduleRecord, *, inherited_from=None,
                                      background=False):
        owners = _schedule_scope.ScheduleOwnership.load(self._config.vault_path)
        bead, _ = owners.owner_of(schedule_id=record.schedule_id, description=record.description)
        if bead in owners.beads and owners.beads[bead].get("status") != "closed":
            return None
        state = self._get_state(record.route, create=False)
        if state is not None:
            team, agent, contexts = self._schedule_owner_contexts(state)
        else:
            team, agent = self._route_inbox_target_keys_by_route.get(
                record.route, (f"route-{record.route.chat_id}", f"route-{record.route.chat_id}-{record.route.thread_id}"))
            contexts = []
        if inherited_from is not None:
            parent_bead, parent_entry = owners.owner_of(
                schedule_id=inherited_from.schedule_id, description=inherited_from.description)
            if not parent_entry:
                parent_entry = owners.retired.get(inherited_from.schedule_id) or {}
                if parent_bead not in owners.beads or owners.beads[parent_bead].get("status") == "closed":
                    parent_bead = parent_entry.get("bead")
            if parent_bead in owners.beads and owners.beads[parent_bead].get("status") != "closed":
                contexts.insert(0, {"agent": parent_entry.get("owner_agent") or agent,
                                   "texts": [f"Task bead: {parent_bead}"], "source": "inherited-owner"})
                if state is None:
                    team = parent_entry.get("owner_team") or team
        texts = [record.prompt]
        if record.prompt_file:
            try:
                texts.append(self._read_schedule_prompt_file(record.prompt_file))
            except OSError:
                pass  # The existing fire-time prompt-file error remains separate from ownership.
        contexts.append({"agent": agent, "texts": texts, "source": "schedule-prompt"})
        return _schedule_scope.assign_creation_owner(
            vault=self._config.vault_path, schedule_id=record.schedule_id, description=record.description,
            team=team, agent=agent, session_id=state.session_id if state is not None else None, contexts=contexts,
            allow_create=background, blocking=background)

    def _register_topic_schedule(self, record: _TopicScheduleRecord) -> None:
        previous = self._topic_schedules_by_id.get(record.schedule_id)
        if previous is None:
            self._ensure_topic_schedule_owner(record)
        if previous is not None and previous.route != record.route:
            schedule_ids = self._schedule_ids_by_route.get(previous.route)
            if schedule_ids is not None:
                schedule_ids.discard(record.schedule_id)
                if not schedule_ids:
                    self._schedule_ids_by_route.pop(previous.route, None)
        self._topic_schedules_by_id[record.schedule_id] = record
        self._schedule_ids_by_route.setdefault(record.route, set()).add(record.schedule_id)
        self._persist_topic_schedule(record)

    def _delete_topic_schedule(self, schedule_id: str) -> None:
        record = self._topic_schedules_by_id.pop(schedule_id, None)
        if record is not None:
            schedule_ids = self._schedule_ids_by_route.get(record.route)
            if schedule_ids is not None:
                schedule_ids.discard(schedule_id)
                if not schedule_ids:
                    self._schedule_ids_by_route.pop(record.route, None)
        self._state_store.delete_topic_schedule(schedule_id=schedule_id)
        getattr(self, "_pending_schedule_owners", {}).pop(schedule_id, None)
        self._retire_topic_schedule_owner(schedule_id)

    def _owns_topic_schedule_record(self, record: _TopicScheduleRecord) -> bool:
        """Return True when *record* is still the registered schedule instance."""
        return self._topic_schedules_by_id.get(record.schedule_id) is record

    def _delete_topic_schedules_for_route(self, route: TelegramRoute) -> None:
        for schedule_id in list(self._schedule_ids_by_route.get(route, set())):
            self._delete_topic_schedule(schedule_id)
        self._schedule_ids_by_route.pop(route, None)
        self._state_store.delete_topic_schedules_for_route(
            chat_id=route.chat_id,
            thread_id=route.thread_id,
        )

    def _schedule_should_inherit(self, *, record: _TopicScheduleRecord, is_fork: bool) -> bool:
        mode = (record.inherit_mode or "none").strip().lower()
        if mode == "all":
            return True
        if mode == "fork":
            return is_fork
        return False

    def _inherit_topic_schedules(
        self,
        *,
        parent_route: TelegramRoute,
        child_route: TelegramRoute,
        is_fork: bool,
    ) -> None:
        now = time.time()
        parent_records = [
            self._topic_schedules_by_id[schedule_id]
            for schedule_id in sorted(self._schedule_ids_by_route.get(parent_route, set()))
            if schedule_id in self._topic_schedules_by_id
        ]
        for parent_record in parent_records:
            if not parent_record.enabled:
                continue
            if self._schedule_is_exhausted(parent_record, now):
                continue
            if not self._schedule_should_inherit(record=parent_record, is_fork=is_fork):
                continue
            child_record = _TopicScheduleRecord(
                schedule_id=uuid.uuid4().hex[:8],
                route=child_route,
                description=parent_record.description,
                schedule_mode=parent_record.schedule_mode,
                cron_expr=parent_record.cron_expr,
                trigger_kind=parent_record.trigger_kind,
                interval_seconds=parent_record.interval_seconds,
                prompt=parent_record.prompt,
                prompt_file=parent_record.prompt_file,
                reset_session=parent_record.reset_session,
                recurring=parent_record.recurring,
                enabled=True,
                run_count=0,
                max_runs=parent_record.max_runs,
                from_ts=parent_record.from_ts,
                until_ts=parent_record.until_ts,
                inherit_mode=parent_record.inherit_mode,
                next_run_at=None,
                last_run_at=None,
                last_success_at=None,
                last_error=None,
                max_retry_attempts=parent_record.max_retry_attempts,
                retry_delay_seconds=parent_record.retry_delay_seconds,
                retry_attempt_count=0,
            )
            if child_record.trigger_kind in {"interval", "cron"}:
                try:
                    child_record.next_run_at = self._next_timed_run_at(child_record, base_ts=now)
                except ValueError:
                    logger.debug(
                        "Skipping inherited schedule with invalid timed config parent=%s child=%s",
                        parent_record.schedule_id,
                        child_route,
                        exc_info=True,
                    )
                    continue
            self._ensure_topic_schedule_owner(child_record, inherited_from=parent_record)
            self._register_topic_schedule(child_record)

    def _schedule_summary_payload(self, record: _TopicScheduleRecord) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "id": record.schedule_id,
            "description": record.description,
            "schedule_mode": record.schedule_mode,
            "trigger_kind": record.trigger_kind,
            "interval_seconds": record.interval_seconds,
            "cron": record.cron_expr,
            "trigger": self._schedule_trigger_label(record),
            "reset_session": record.reset_session,
            "enabled": record.enabled,
            "run_count": record.run_count,
            "max_runs": record.max_runs,
            "from": self._schedule_iso_timestamp(record.from_ts),
            "until": self._schedule_iso_timestamp(record.until_ts),
            "next_run_at": self._schedule_iso_timestamp(record.next_run_at),
            "inherit": record.inherit_mode,
        }
        if record.prompt_file:
            payload["prompt_file"] = record.prompt_file
        if record.last_error:
            payload["last_error"] = record.last_error
        return payload

    def _schedule_owner_contexts(self, state: TelegramSessionState):
        context = self._current_tree_context(state)
        if context is None:
            team = agent = f"route-{state.route.chat_id}-{state.route.thread_id}"
            lineage = ()
        else:
            team, agent, lineage = context
        names = [agent] + [agent_name_for_lineage(lineage[:n], team_key=team)
                           for n in range(len(lineage) - 1, 0, -1)]
        contexts = []
        for name in dict.fromkeys(names):
            current = state if name == agent else self._resolve_existing_tree_state(
                team_name=team, agent_name=name)
            record = self._resolve_team_worker_record(team_name=team, agent_name=name)
            sid = current.session_id if current is not None else (record.child_session_id if record else None)
            texts = []
            if current is not None and current.inflight_user_text:
                texts.append(current.inflight_user_text)
            if record is not None:
                texts.extend(text for text in (record.prompt, record.prompt_file_content) if text)
            contexts.append({"agent": name, "session_id": sid, "texts": texts,
                             "jsonl": find_session_jsonl(session_id=sid, cwd=self._config.vault_path) if sid else None})
        return team, agent, contexts

    async def _cron_create(
        self,
        *,
        route: TelegramRoute,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        state = self._get_state(route, create=False)
        if state is None:
            return self._cron_error_result("CronCreate is only available inside an active Telegram topic")

        prompt = str(args.get("prompt") or "").strip()
        prompt_file = str(args.get("prompt_file") or "").strip() or None
        if not prompt and not prompt_file:
            return self._cron_error_result("CronCreate failed: prompt is required unless prompt_file is given")
        if prompt_file:
            try:
                self._read_schedule_prompt_file(prompt_file)
            except OSError as exc:
                return self._cron_error_result(f"CronCreate failed: cannot read prompt_file: {exc}")
        schedule_mode = str(args.get("schedule_mode") or "").strip().lower()
        cron_expr = str(args.get("cron") or "").strip()
        if not schedule_mode:
            if args.get("interval_seconds") is not None:
                schedule_mode = "interval"
            elif cron_expr:
                schedule_mode = "cron"
        if schedule_mode not in {"interval", "cron"}:
            return self._cron_error_result(
                "CronCreate failed: schedule_mode must be interval or cron"
            )
        if schedule_mode == "cron" and not cron_expr:
            return self._cron_error_result(
                "CronCreate failed: cron is required for schedule_mode=cron"
            )

        interval_override = args.get("interval_seconds")
        interval_seconds: int | None
        trigger_kind: str
        if schedule_mode == "interval":
            if interval_override is None:
                return self._cron_error_result(
                    "CronCreate failed: interval_seconds is required for schedule_mode=interval"
                )
            try:
                parsed_override = int(interval_override)
            except (TypeError, ValueError):
                return self._cron_error_result("CronCreate failed: interval_seconds must be an integer")
            if parsed_override < 0:
                return self._cron_error_result("CronCreate failed: interval_seconds must be non-negative")
            if parsed_override == 0:
                trigger_kind = "on_topic_stop"
                interval_seconds = None
            else:
                trigger_kind = "interval"
                interval_seconds = parsed_override
        else:
            if croniter is None:
                return self._cron_error_result(
                    "CronCreate failed: cron mode unavailable because croniter is not installed"
                )
            trigger_kind = "cron"
            interval_seconds = None

        max_runs = args.get("max_runs")
        if max_runs is not None:
            try:
                max_runs = int(max_runs)
            except (TypeError, ValueError):
                return self._cron_error_result("CronCreate failed: max_runs must be an integer")
            if max_runs <= 0:
                return self._cron_error_result("CronCreate failed: max_runs must be positive")
        else:
            max_runs = 1

        reset_session = args.get("reset_session")
        if reset_session is None:
            run_mode = str(args.get("run_mode") or "").strip().lower()
            if run_mode and run_mode not in {"continue", "reset_session"}:
                return self._cron_error_result(
                    "CronCreate failed: run_mode must be continue or reset_session"
                )
            reset_session = run_mode == "reset_session"
        elif not isinstance(reset_session, bool):
            return self._cron_error_result("CronCreate failed: reset_session must be boolean")

        from_raw = str(args.get("from") or "").strip() or None
        until_raw = str(args.get("until") or "").strip() or None
        try:
            from_ts = self._parse_rfc3339_timestamp(from_raw)
            until_ts = self._parse_rfc3339_timestamp(until_raw)
        except ValueError:
            return self._cron_error_result(
                "CronCreate failed: from/until must be RFC3339 timestamp"
            )
        if from_ts is not None and until_ts is not None and from_ts > until_ts:
            return self._cron_error_result(
                "CronCreate failed: from must be <= until"
            )

        inherit_mode = str(args.get("inherit") or "none").strip().lower() or "none"
        if inherit_mode not in {"none", "fork", "all"}:
            return self._cron_error_result(
                "CronCreate failed: inherit must be none, fork, or all"
            )

        now = time.time()
        schedule_id = uuid.uuid4().hex[:8]
        record = _TopicScheduleRecord(
            schedule_id=schedule_id,
            route=route,
            description=str(args.get("description") or "").strip() or None,
            schedule_mode=schedule_mode,
            cron_expr=cron_expr,
            trigger_kind=trigger_kind,
            interval_seconds=interval_seconds,
            prompt=prompt,
            prompt_file=prompt_file,
            reset_session=bool(reset_session),
            recurring=max_runs != 1,
            enabled=True,
            run_count=0,
            max_runs=max_runs,
            from_ts=from_ts,
            until_ts=until_ts,
            inherit_mode=inherit_mode,
            next_run_at=None,
            max_retry_attempts=self._schedule_retry_max_attempts,
            retry_delay_seconds=self._schedule_retry_delay_seconds,
            retry_attempt_count=0,
        )
        if record.trigger_kind in {"interval", "cron"}:
            try:
                record.next_run_at = self._next_timed_run_at(record, base_ts=now)
            except ValueError as exc:
                return self._cron_error_result(f"CronCreate failed: invalid cron expression: {exc}")
        owner_assignment = await asyncio.to_thread(self._ensure_topic_schedule_owner, record)
        self._register_topic_schedule(record)

        bot = self._bot_for_state(state)
        if bot is not None:
            try:
                await self._send_system_message(
                    route=route,
                    bot=bot,
                    text=(
                        "schedule created: "
                        f"{self._schedule_display_name(record)} "
                        f"({self._schedule_trigger_label(record)})"
                    ),
                    disable_notification=True,
                )
            except Exception:
                logger.debug("Failed sending schedule create marker route=%s", route, exc_info=True)

        warnings = _schedule_scope.ScheduleOwnership.load(self._config.vault_path).creation_warnings(
            schedule_id=record.schedule_id, description=record.description)
        for warning in warnings:
            logger.warning("[schedule_ownership] %s", warning)
        payload = {
            "schedule": self._schedule_summary_payload(record),
            "warnings": warnings,
            "owner_assignment": owner_assignment,
        }
        return self._cron_ok_result(payload)

    async def _cron_list(self, *, route: TelegramRoute) -> dict[str, Any]:
        schedules = [
            self._topic_schedules_by_id[schedule_id]
            for schedule_id in sorted(self._schedule_ids_by_route.get(route, set()))
            if schedule_id in self._topic_schedules_by_id
        ]
        payload = {"schedules": [self._schedule_summary_payload(record) for record in schedules]}
        return self._cron_ok_result(payload)

    async def _cron_delete(
        self,
        *,
        route: TelegramRoute,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        schedule_id = str(args.get("id") or "").strip()
        if not schedule_id:
            return self._cron_error_result("CronDelete failed: id is required")
        record = self._topic_schedules_by_id.get(schedule_id)
        if record is None or record.route != route:
            return self._cron_ok_result({"deleted": False, "id": schedule_id})
        self._delete_topic_schedule(schedule_id)
        state = self._get_state(route, create=False)
        bot = self._bot_for_state(state) if state is not None else self._primary_bot
        if bot is not None:
            try:
                await self._send_system_message(
                    route=route,
                    bot=bot,
                    text=f"schedule deleted: {schedule_id}",
                    disable_notification=True,
                )
            except Exception:
                logger.debug("Failed sending schedule delete marker route=%s", route, exc_info=True)
        return self._cron_ok_result({"deleted": True, "id": schedule_id})

    def _schedule_is_exhausted(self, record: _TopicScheduleRecord, now: float) -> bool:
        if record.max_runs is not None and record.run_count >= record.max_runs:
            return True
        if record.until_ts is not None and now >= record.until_ts:
            return True
        return False

    def _schedule_window_not_started(self, record: _TopicScheduleRecord, now: float) -> bool:
        return record.from_ts is not None and now < record.from_ts

    def _next_timed_run_at(self, record: _TopicScheduleRecord, *, base_ts: float) -> float | None:
        if record.trigger_kind == "interval":
            if record.interval_seconds is None:
                return None
            anchor = max(base_ts, record.from_ts or base_ts)
            return anchor + record.interval_seconds
        if record.trigger_kind == "cron":
            cron_expr = (record.cron_expr or "").strip()
            if not cron_expr:
                raise ValueError("missing cron expression")
            return self._next_cron_fire_ts(
                cron_expr=cron_expr,
                base_ts=base_ts,
                not_before_ts=record.from_ts,
            )
        return None

    def _reanchor_interval_schedules_for_route(
        self,
        *,
        route: TelegramRoute,
        base_ts: float | None = None,
    ) -> None:
        now = base_ts if base_ts is not None else time.time()
        schedule_ids = sorted(self._schedule_ids_by_route.get(route, set()))
        for schedule_id in schedule_ids:
            record = self._topic_schedules_by_id.get(schedule_id)
            if record is None or not record.enabled:
                continue
            if record.trigger_kind != "interval" or record.interval_seconds is None:
                continue
            if self._schedule_is_exhausted(record, now):
                record.enabled = False
                record.next_run_at = None
                self._register_topic_schedule(record)
                continue
            if self._schedule_window_not_started(record, now):
                continue
            try:
                record.next_run_at = self._next_timed_run_at(record, base_ts=now)
            except ValueError as exc:
                record.enabled = False
                record.last_error = f"schedule config error: {exc}"
                record.next_run_at = None
            hold_until = self._route_credit_limit_until.get(route)
            if (
                hold_until is not None
                and record.next_run_at is not None
                and record.next_run_at < hold_until
            ):
                record.next_run_at = hold_until
            self._register_topic_schedule(record)

    def _note_route_credit_limit(
        self,
        *,
        route: TelegramRoute,
        failed: bool,
        error_text: str | None,
        assistant_text: str | None = None,
        now: float | None = None,
    ) -> float | None:
        """Record (or clear) the route's credit-limit hold from one finished turn (vault-ns5)."""
        limit_text = _credit_limit.turn_limit_text(
            failed=failed, error_text=error_text, assistant_text=assistant_text
        )
        if limit_text is None:
            if not failed:
                self._route_credit_limit_until.pop(route, None)
            return None
        ts = now if now is not None else time.time()
        limit = _credit_limit.parse_credit_limit(limit_text, ts)
        if limit is None:
            return None
        hold_until = _credit_limit.rearm_at(limit, now=ts, consecutive_limit_fires=1)
        previous = self._route_credit_limit_until.get(route)
        if previous is None or previous < hold_until:
            self._route_credit_limit_until[route] = hold_until
        logger.info(
            "[credit_limit_hold] route=%s hold_until=%s reset_parsed=%s error=%.120s",
            route,
            self._schedule_iso_timestamp(self._route_credit_limit_until[route]),
            limit.reset_at is not None,
            limit.text,
        )
        return self._route_credit_limit_until[route]

    async def _defer_schedule_for_credit_limit(
        self,
        *,
        record: _TopicScheduleRecord,
        limit: _credit_limit.CreditLimit,
        now_after: float,
        bot: Any,
    ) -> None:
        """A fire that hit a credit limit: do not count it; re-arm it after the reset."""
        streak = self._schedule_limit_streak.get(record.schedule_id, 0) + 1
        self._schedule_limit_streak[record.schedule_id] = streak
        rearm = _credit_limit.rearm_at(limit, now=now_after, consecutive_limit_fires=streak)
        route_hold = self._route_credit_limit_until.get(record.route)
        if route_hold is None or route_hold < rearm:
            self._route_credit_limit_until[record.route] = rearm
        else:
            rearm = route_hold
        record.retry_attempt_count = 0
        record.last_error = (
            f"credit limit; fire not counted; retry at {self._schedule_iso_timestamp(rearm)}: "
            f"{limit.text}"
        )
        if not self._owns_topic_schedule_record(record):
            return
        past_window = record.until_ts is not None and rearm > float(record.until_ts)
        if self._schedule_is_exhausted(record, now_after) or past_window:
            record.enabled = False
            record.next_run_at = None
        elif record.trigger_kind in {"interval", "cron"}:
            record.next_run_at = rearm
        self._register_topic_schedule(record)
        logger.info(
            "[schedule_limit_deferred] schedule_id=%s route=%s streak=%d next_run_at=%s run_count=%d",
            record.schedule_id,
            record.route,
            streak,
            self._schedule_iso_timestamp(record.next_run_at),
            record.run_count,
        )
        if record.enabled and record.next_run_at is not None:
            when = self._format_schedule_timestamp(ts=record.next_run_at, record=record, now_ts=now_after)
            text = (
                f"schedule deferred: {self._schedule_display_name(record)}: credit limit; "
                f"this fire was not counted; next try {when}"
            )
        else:
            text = (
                f"schedule ended: {self._schedule_display_name(record)}: credit limit "
                "and the schedule window has closed"
            )
        try:
            await self._send_system_message(
                route=record.route,
                bot=bot,
                text=text,
                disable_notification=True,
            )
        except Exception:
            logger.debug(
                "Failed sending schedule deferred marker route=%s schedule_id=%s",
                record.route,
                record.schedule_id,
                exc_info=True,
            )

    async def _execute_topic_schedule(
        self,
        *,
        record: _TopicScheduleRecord,
        trigger_kind: str,
    ) -> bool:
        if not record.enabled:
            return False
        now = time.time()
        if self._schedule_is_exhausted(record, now):
            record.enabled = False
            record.next_run_at = None
            self._register_topic_schedule(record)
            return False
        if self._schedule_window_not_started(record, now):
            if record.trigger_kind in {"interval", "cron"}:
                try:
                    record.next_run_at = self._next_timed_run_at(record, base_ts=now)
                except ValueError as exc:
                    record.enabled = False
                    record.last_error = f"schedule config error: {exc}"
                    record.next_run_at = None
                self._register_topic_schedule(record)
            return False
        hold_until = self._route_credit_limit_until.get(record.route)
        if hold_until is not None and now < hold_until:
            # vault-ns5: the route is inside a known credit-limit outage. Do not run (the
            # prompt would only append a limit error to the session and poison its tail,
            # forking a fresh session at the next wake) and do not count; fire after reset.
            if record.trigger_kind in {"interval", "cron"} and (
                record.next_run_at is None or record.next_run_at < hold_until
            ):
                record.next_run_at = hold_until
                self._register_topic_schedule(record)
            logger.info(
                "[schedule_limit_hold] schedule_id=%s route=%s hold_until=%s",
                record.schedule_id,
                record.route,
                self._schedule_iso_timestamp(hold_until),
            )
            return False

        state = self._get_state(record.route, create=False)
        if state is None:
            if is_reply_wake_schedule(record):
                record.enabled = False
                record.next_run_at = None
                self._register_topic_schedule(record)
            return False
        bot = self._bot_for_state(state)
        if bot is None:
            if is_reply_wake_schedule(record):
                record.enabled = False
                record.next_run_at = None
                self._register_topic_schedule(record)
            return False
        lock = self._get_route_lock(record.route)
        if lock.locked() or state.busy:
            if is_reply_wake_schedule(record):
                try:
                    record.next_run_at = self._next_timed_run_at(record, base_ts=now)
                except ValueError as exc:
                    record.enabled = False
                    record.last_error = f"schedule config error: {exc}"
                    record.next_run_at = None
                self._register_topic_schedule(record)
            return False

        now_after = now
        run_succeeded = False
        run_failed = False
        failure_text: str | None = None

        async def _emit_post_schedule_summary() -> None:
            try:
                await self._send_system_message(
                    route=record.route,
                    bot=bot,
                    text=self._build_completion_summary(
                        state,
                        triggered_schedule_id=record.schedule_id,
                    ),
                    disable_notification=False,
                )
            except Exception:
                logger.debug(
                    "Failed sending post-schedule summary route=%s schedule_id=%s",
                    record.route,
                    record.schedule_id,
                    exc_info=True,
                )

        self._schedule_running_by_route.add(record.route)
        self._active_schedule_execution_by_route[record.route] = record.schedule_id
        try:
            async with lock:
                if state.busy:
                    return False
                # vault-wlh: read the prompt file BEFORE any session reset, so an
                # unreadable file fails this fire without discarding the session.
                composed_schedule_prompt = self._compose_schedule_prompt(record)
                if record.reset_session:
                    await self._reset_route_state(state)
                    state.last_bot = bot
                try:
                    await self._send_system_message(
                        route=record.route,
                        bot=bot,
                        text=self._schedule_trigger_line(record, now_ts=time.time()),
                        disable_notification=True,
                    )
                except Exception:
                    logger.debug(
                        "Failed sending schedule trigger marker route=%s schedule_id=%s",
                        record.route,
                        record.schedule_id,
                        exc_info=True,
                    )
                scheduled_prompt = (
                    "(System: scheduled execution.)\n\n"
                    f"{composed_schedule_prompt}"
                )
                record.last_run_at = time.time()
                # ops-29: persist the start, so a fire cut off by a restart is visible
                # (the scheduler re-fires it because next_run_at only advances on completion).
                record.last_error = (
                    f"{_SCHEDULE_IN_PROGRESS_PREFIX}"
                    f"{self._schedule_iso_timestamp(record.last_run_at)}"
                )
                if self._owns_topic_schedule_record(record):
                    self._persist_topic_schedule(record)
                self._schedule_stop_suppress_until[record.route] = (
                    time.time() + _SCHEDULE_STOP_SUPPRESS_SECONDS
                )
                self._clear_stop_latch(state, "schedule")
                state.hook_state.schedule_run_active = True
                state.hook_state.triggered_schedule_id = record.schedule_id
                state.hook_state.active_schedule = self._schedule_summary_payload(record)
                try:
                    outcome = await self._run_and_send(
                        state=state,
                        user_text=scheduled_prompt,
                        bot=bot,
                        trigger_message=None,
                        triggered_schedule_id=record.schedule_id,
                        suppress_completion_summary=True,
                    )
                    now_after = time.time()
                    silent_limit = (
                        None
                        if outcome.failed
                        else _credit_limit.turn_limit_text(
                            failed=False,
                            error_text=None,
                            assistant_text=outcome.assistant_text,
                        )
                    )
                    if outcome.failed:
                        run_failed = True
                        failure_text = outcome.error or "scheduled run failed"
                    elif silent_limit is not None:
                        # vault-ns5: the reply is only the provider's limit line; it ran nothing.
                        run_failed = True
                        failure_text = silent_limit
                    else:
                        run_succeeded = True
                finally:
                    state.hook_state.schedule_run_active = False
                    state.hook_state.triggered_schedule_id = None
                    state.hook_state.active_schedule = None
        except asyncio.CancelledError:
            if record.last_error and record.last_error.startswith(_SCHEDULE_IN_PROGRESS_PREFIX):
                started = record.last_error[len(_SCHEDULE_IN_PROGRESS_PREFIX):]
                record.last_error = (
                    f"{_SCHEDULE_INTERRUPTED_PREFIX}{started} was cancelled before it "
                    "finished; the fire is retried"
                )
                if self._owns_topic_schedule_record(record):
                    try:
                        self._persist_topic_schedule(record)
                    except Exception:
                        logger.debug("Failed persisting interrupted schedule", exc_info=True)
            raise
        except Exception as exc:
            now_after = time.time()
            run_failed = True
            failure_text = f"{type(exc).__name__}: {exc}"
            logger.debug(
                "Scheduled run failed schedule_id=%s route=%s",
                record.schedule_id,
                record.route,
                exc_info=True,
            )
        finally:
            self._schedule_running_by_route.discard(record.route)
            self._active_schedule_execution_by_route.pop(record.route, None)

        limit = (
            _credit_limit.parse_credit_limit(failure_text, now_after) if run_failed else None
        )
        if run_succeeded:
            record.run_count += 1
            record.retry_attempt_count = 0
            record.last_error = None
            record.last_success_at = now_after
            self._schedule_limit_streak.pop(record.schedule_id, None)
        elif limit is not None:
            await self._defer_schedule_for_credit_limit(
                record=record,
                limit=limit,
                now_after=now_after,
                bot=bot,
            )
            await _emit_post_schedule_summary()
            return False
        elif run_failed:
            record.last_error = failure_text or "scheduled run failed"
            if (
                record.max_retry_attempts > 0
                and record.retry_attempt_count < record.max_retry_attempts
            ):
                record.retry_attempt_count += 1
                if record.trigger_kind in {"interval", "cron"}:
                    retry_delay = max(int(record.retry_delay_seconds), 1)
                    record.next_run_at = now_after + retry_delay
                if self._owns_topic_schedule_record(record):
                    self._register_topic_schedule(record)
                await _emit_post_schedule_summary()
                return False
            record.retry_attempt_count = 0
            record.run_count += 1
            try:
                await self._send_system_message(
                    route=record.route,
                    bot=bot,
                    text=(
                        "schedule failed: "
                        f"{self._schedule_display_name(record)}: "
                        f"{record.last_error}"
                    ),
                    disable_notification=False,
                )
            except Exception:
                logger.debug(
                    "Failed sending schedule failure marker route=%s schedule_id=%s",
                    record.route,
                    record.schedule_id,
                    exc_info=True,
                )

        if not self._owns_topic_schedule_record(record):
            await _emit_post_schedule_summary()
            return run_succeeded

        if self._schedule_is_exhausted(record, now_after):
            record.enabled = False
        if record.enabled and record.trigger_kind in {"interval", "cron"}:
            try:
                record.next_run_at = self._next_timed_run_at(record, base_ts=now_after)
            except ValueError as exc:
                record.enabled = False
                record.last_error = f"schedule config error: {exc}"
                record.next_run_at = None
        elif record.trigger_kind in {"interval", "cron"}:
            record.next_run_at = None
        self._register_topic_schedule(record)
        await _emit_post_schedule_summary()
        return run_succeeded

    def _cleanup_finished_schedule_tasks(self) -> None:
        for schedule_id, task in list(self._schedule_execution_tasks.items()):
            if task.done():
                self._schedule_execution_tasks.pop(schedule_id, None)

    def _start_topic_schedule_task(self, record: _TopicScheduleRecord) -> bool:
        self._cleanup_finished_schedule_tasks()
        task = self._schedule_execution_tasks.get(record.schedule_id)
        if task is not None and not task.done():
            return False
        task = asyncio.create_task(
            self._execute_topic_schedule(record=record, trigger_kind=record.trigger_kind)
        )
        self._schedule_execution_tasks[record.schedule_id] = task

        def _discard(done_task: asyncio.Task) -> None:
            if self._schedule_execution_tasks.get(record.schedule_id) is done_task:
                self._schedule_execution_tasks.pop(record.schedule_id, None)
            try:
                done_task.result()
            except asyncio.CancelledError:
                pass
            except Exception:
                logger.debug(
                    "Scheduled task crashed outside execution handler schedule_id=%s route=%s",
                    record.schedule_id,
                    record.route,
                    exc_info=True,
                )

        task.add_done_callback(_discard)
        return True

    async def _run_due_interval_schedules(self) -> None:
        now = time.time()
        due_records = [
            record
            for record in self._topic_schedules_by_id.values()
            if record.enabled
            and record.trigger_kind in {"interval", "cron"}
            and record.next_run_at is not None
            and record.next_run_at <= now
        ]
        due_records.sort(key=lambda record: float(record.next_run_at or now))
        for record in due_records:
            self._start_topic_schedule_task(record)

    async def _process_stop_schedule_events(self) -> None:
        events: list[tuple[TelegramRoute, dict[str, Any]]] = []
        while not self._schedule_stop_events.empty():
            try:
                events.append(self._schedule_stop_events.get_nowait())
            except asyncio.QueueEmpty:
                break

        now = time.time()
        expired_routes = [
            route
            for route, until in self._schedule_stop_suppress_until.items()
            if now >= until
        ]
        for route in expired_routes:
            self._schedule_stop_suppress_until.pop(route, None)

        deferred_by_route: dict[TelegramRoute, dict[str, Any]] = {}

        def _defer_stop_event(route: TelegramRoute, payload: dict[str, Any]) -> None:
            raw_count = payload.get("_defer_count")
            if isinstance(raw_count, (int, float)):
                defer_count = int(raw_count)
            else:
                defer_count = 0
            if defer_count >= _SCHEDULE_STOP_MAX_DEFERS:
                logger.debug(
                    "Dropping deferred stop event after max defers route=%s payload=%s",
                    route,
                    payload,
                )
                return
            deferred_payload = dict(payload)
            # Replayed events should run after the active turn drains.
            deferred_payload["execution_active"] = False
            deferred_payload["schedule_run_active"] = False
            deferred_payload["_defer_count"] = defer_count + 1
            deferred_by_route[route] = deferred_payload

        for route, payload in events:
            if bool(payload.get("schedule_run_active")):
                continue
            if bool(payload.get("execution_active")):
                _defer_stop_event(route, payload)
                continue
            suppress_until = self._schedule_stop_suppress_until.get(route, 0.0)
            if now < suppress_until:
                continue
            state = self._get_state(route, create=False)
            if state is None:
                continue
            lock = self._get_route_lock(route)
            if state.busy or lock.locked() or route in self._schedule_running_by_route:
                _defer_stop_event(route, payload)
                continue
            session_id = payload.get("session_id")
            if (
                isinstance(session_id, str)
                and session_id
                and session_id in self._route_by_session_id
                and self._route_by_session_id.get(session_id) != route
            ):
                continue
            records = [
                self._topic_schedules_by_id[schedule_id]
                for schedule_id in sorted(self._schedule_ids_by_route.get(route, set()))
                if schedule_id in self._topic_schedules_by_id
            ]
            for record in records:
                if not record.enabled:
                    continue
                if self._schedule_is_exhausted(record, now):
                    record.enabled = False
                    record.next_run_at = None
                    self._register_topic_schedule(record)
                    continue
                if record.trigger_kind == "interval" and record.interval_seconds is not None:
                    if self._schedule_window_not_started(record, now):
                        continue
                    try:
                        record.next_run_at = self._next_timed_run_at(record, base_ts=now)
                    except ValueError as exc:
                        record.enabled = False
                        record.last_error = f"schedule config error: {exc}"
                        record.next_run_at = None
                    self._register_topic_schedule(record)
                    continue
                if record.trigger_kind != "on_topic_stop":
                    continue
                if self._schedule_window_not_started(record, now):
                    continue
                ran = await self._execute_topic_schedule(record=record, trigger_kind="on_topic_stop")
                if not ran and (state.busy or lock.locked() or route in self._schedule_running_by_route):
                    _defer_stop_event(route, payload)
                    break

        for route, payload in deferred_by_route.items():
            self._schedule_stop_events.put_nowait((route, payload))

    def _build_fork_task_topic_name(
        self,
        *,
        state: TelegramSessionState,
        alias: str | None,
    ) -> str:
        normalized_alias = normalize_lineage_name(alias)
        if normalized_alias:
            return self._child_topic_title_from_alias(state, normalized_alias)
        return self._next_auto_child_title(state)

    def _build_team_worker_env(
        self,
        *,
        team_name: str | None,
        agent_name: str | None = None,
    ) -> dict[str, str]:
        """Build team identity env, not route-dependent tool configuration.

        CACHE-PREFIX WARNING: forked JSONL replays the parent's messages. Tool schemas precede those
        messages in the cache prefix, so child-only defaults would invalidate
        the entire shared prefix. Global CLI defaults belong in SessionManager.
        """
        normalized_team = (team_name or "").strip()
        if not normalized_team:
            return {}
        env = {
            "CLAUDE_CODE_ENABLE_TASKS": "1",
            "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1",
            "CLAUDE_CODE_TASK_LIST_ID": normalized_team,
            "CLAUDE_CODE_TEAM_NAME": normalized_team,
        }
        normalized_agent = (agent_name or "").strip()
        if normalized_agent:
            env["CLAUDE_CODE_AGENT_NAME"] = normalized_agent
        return env

    @staticmethod
    def _with_explicit_env(
        state: TelegramSessionState,
        team_env: dict[str, str],
    ) -> dict[str, str]:
        """Overlay the session's persisted explicit launch env on a rebuilt team env.

        Restore and resume rebuild the team-identity env from scratch; without
        this overlay the AgentTask ``env`` a child was launched with (compaction
        policy, thresholds, backend URL, ...) silently disappears (vault-u3b.20).
        Explicit keys win, matching launch-time precedence.
        """
        explicit = state.session_manager.explicit_env_overrides or {}
        return {**team_env, **explicit}

    def _build_team_projection_obs_metadata(
        self,
        *,
        lineage: tuple[str, ...] | None,
        team_name: str | None,
        agent_name: str | None,
        route: TelegramRoute | None = None,
        parent_agent_name: str | None = None,
        parent_display_name: str | None = None,
    ) -> dict[str, Any] | None:
        normalized_lineage = tuple(
            item
            for item in (normalize_lineage_name(value) for value in (lineage or ()))
            if item
        )
        normalized_team = (team_name or "").strip()
        normalized_agent = (agent_name or "").strip()
        if not normalized_lineage or not normalized_team or not normalized_agent:
            return None
        resolved_parent_display = (parent_display_name or "").strip() or None
        resolved_parent_agent = (parent_agent_name or "").strip() or None
        if len(normalized_lineage) > 1:
            if resolved_parent_display is None:
                resolved_parent_display = normalized_lineage[-2]
            if len(normalized_lineage) == 2:
                resolved_parent_display = format_root_display_name(
                    normalized_team,
                    resolved_parent_display,
                )
            if resolved_parent_agent is None:
                resolved_parent_agent = agent_name_for_lineage(
                    normalized_lineage[:-1],
                    team_key=normalized_team,
                )
        resolved_display_name = normalized_lineage[-1]
        if len(normalized_lineage) == 1:
            resolved_display_name = format_root_display_name(
                normalized_team,
                resolved_display_name,
            )
        payload = {
            "root_team_key": normalized_team,
            "agent_name": normalized_agent,
            "display_name": resolved_display_name,
            "parent_agent_name": resolved_parent_agent,
            "parent_display_name": resolved_parent_display,
            "lineage": list(normalized_lineage),
            "lineage_length": len(normalized_lineage),
            "updated_at": int(time.time() * 1000),
        }
        if route is not None:
            payload["topic_chat_id"] = route.chat_id
            payload["topic_thread_id"] = route.thread_id
        return payload

    def _load_team_projection_metadata(
        self,
        team_name: str,
    ) -> dict[str, dict[str, Any]]:
        config_path = Path.home() / ".claude" / "teams" / team_name / "config.json"
        if not config_path.exists():
            return {}
        try:
            payload = json.loads(config_path.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed to parse team config %s", config_path, exc_info=True)
            return {}
        members = payload.get("members")
        if not isinstance(members, list):
            return {}
        metadata: dict[str, dict[str, Any]] = {}
        for member in members:
            if not isinstance(member, dict):
                continue
            agent_name = str(member.get("name") or "").strip()
            if not agent_name or agent_name == "team-lead":
                continue
            obs = member.get("obs")
            if not isinstance(obs, dict):
                continue
            entry: dict[str, Any] = {"agent_name": agent_name}
            for text_key in (
                "display_name",
                "parent_agent_name",
                "parent_display_name",
                "root_team_key",
            ):
                value = obs.get(text_key)
                if isinstance(value, str) and value.strip():
                    entry[text_key] = value.strip()
            lineage = obs.get("lineage")
            if isinstance(lineage, list):
                normalized_lineage = [
                    str(item).strip()
                    for item in lineage
                    if isinstance(item, str) and str(item).strip()
                ]
                if normalized_lineage:
                    entry["lineage"] = normalized_lineage
                    entry["lineage_length"] = len(normalized_lineage)
            if isinstance(obs.get("lineage_length"), int):
                entry["lineage_length"] = int(obs["lineage_length"])
            for int_key in ("topic_chat_id", "topic_thread_id", "updated_at"):
                value = obs.get(int_key)
                if isinstance(value, int):
                    entry[int_key] = value
            metadata[agent_name] = entry
        return metadata

    def _upsert_team_projection_config(
        self,
        *,
        team_name: str | None,
        agent_name: str | None,
        child_session_id: str | None,
        obs_metadata: dict[str, Any] | None = None,
    ) -> None:
        normalized_team = (team_name or "").strip()
        normalized_agent = (agent_name or "").strip()
        if not normalized_team or not normalized_agent:
            return

        team_dir = Path.home() / ".claude" / "teams" / normalized_team
        config_path = team_dir / "config.json"
        # obs-54: this ran on every stream event of every run (_bind_state_session),
        # re-reading and rewriting team configs of up to 1.5 MB on the event loop.
        # Skip it while the same member data was written within the refresh
        # interval; only the joinedAt/updated_at stamps would differ. OBS's other
        # upserts read-modify-write and keep every member, so the config only
        # grows; a smaller file than this process last wrote means a member was
        # removed outside OBS, and the entry is written again at once.
        memo_key = (normalized_team, normalized_agent)
        fingerprint = self._team_projection_fingerprint(child_session_id, obs_metadata)
        written = self._team_projection_written.get(memo_key)
        if (
            written is not None
            and written[0] == fingerprint
            and time.monotonic() - written[1] < _TEAM_PROJECTION_REFRESH_SECONDS
            and (team_dir / "inboxes" / f"{normalized_agent}.json").exists()
        ):
            try:
                if config_path.stat().st_size >= written[2]:
                    return
            except OSError:
                pass
        team_dir.mkdir(parents=True, exist_ok=True)

        payload: dict[str, Any] = {}
        if config_path.exists():
            try:
                loaded = json.loads(config_path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    payload = loaded
            except Exception:
                logger.debug("Failed to parse team config %s; recreating", config_path, exc_info=True)

        now_ms = int(time.time() * 1000)
        if not isinstance(payload.get("name"), str) or not str(payload.get("name")).strip():
            payload["name"] = normalized_team
        if not isinstance(payload.get("createdAt"), int):
            payload["createdAt"] = now_ms
        lead_agent_id = str(payload.get("leadAgentId") or f"team-lead@{normalized_team}")
        payload["leadAgentId"] = lead_agent_id
        if child_session_id and (not isinstance(payload.get("leadSessionId"), str) or not payload.get("leadSessionId")):
            payload["leadSessionId"] = child_session_id

        members_raw = payload.get("members")
        members: list[dict[str, Any]] = [
            member for member in members_raw
            if isinstance(member, dict)
        ] if isinstance(members_raw, list) else []

        def _upsert_member(member: dict[str, Any]) -> None:
            member_id = str(member.get("agentId") or "").strip()
            if not member_id:
                return
            for idx, existing in enumerate(members):
                if str(existing.get("agentId") or "").strip() == member_id:
                    merged = dict(existing)
                    merged.update(member)
                    members[idx] = merged
                    return
            members.append(member)

        _upsert_member(
            {
                "agentId": lead_agent_id,
                "name": "team-lead",
                "agentType": "team-lead",
                "model": getattr(self._config, "model", "claude-opus-4-7"),
                "joinedAt": now_ms,
                "tmuxPaneId": "",
                "cwd": str(self._config.vault_path),
                "subscriptions": [],
            }
        )

        worker_agent_id = f"{normalized_agent}@{normalized_team}"
        _upsert_member(
            {
                "agentId": worker_agent_id,
                "name": normalized_agent,
                "agentType": "general-purpose",
                "model": getattr(self._config, "model", "claude-opus-4-7"),
                "joinedAt": now_ms,
                "tmuxPaneId": "in-process",
                "cwd": str(self._config.vault_path),
                "subscriptions": [],
                "backendType": "in-process",
                **({"obs": obs_metadata} if obs_metadata else {}),
            }
        )

        payload["members"] = members
        serialized = json.dumps(payload, indent=2, ensure_ascii=True)
        config_path.write_text(serialized, encoding="utf-8")

        inbox_dir = team_dir / "inboxes"
        inbox_dir.mkdir(parents=True, exist_ok=True)
        inbox_path = inbox_dir / f"{normalized_agent}.json"
        if not inbox_path.exists():
            inbox_path.write_text("[]", encoding="utf-8")
        # ensure_ascii output: characters are bytes.
        self._team_projection_written[memo_key] = (fingerprint, time.monotonic(), len(serialized))

    @staticmethod
    def _team_projection_fingerprint(
        child_session_id: str | None,
        obs_metadata: dict[str, Any] | None,
    ) -> str:
        stable = {key: value for key, value in (obs_metadata or {}).items() if key != "updated_at"}
        return json.dumps([child_session_id, stable], sort_keys=True, default=str)

    def _child_session_path(self, session_id: str) -> str | None:
        path = find_session_jsonl(
            session_id=session_id,
            cwd=self._config.vault_path,
        )
        return str(path) if path is not None else None

    def _persisted_jsonl_uuids(self, path: Path | str) -> list[str]:
        jsonl_path = Path(path).expanduser()
        uuids: list[str] = []
        seen: set[str] = set()
        try:
            with jsonl_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    raw = line.strip()
                    if not raw:
                        continue
                    try:
                        entry = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(entry, dict):
                        continue
                    entry_uuid = entry.get("uuid")
                    if isinstance(entry_uuid, str) and entry_uuid and entry_uuid not in seen:
                        seen.add(entry_uuid)
                        uuids.append(entry_uuid)
        except OSError:
            return []
        return uuids

    def _persisted_session_uuids(self, session_id: str) -> list[str]:
        path = find_session_jsonl(
            session_id=session_id,
            cwd=self._config.vault_path,
        )
        if path is None:
            return []
        return self._persisted_jsonl_uuids(path)

    def _resolve_safe_jsonl_target(
        self,
        *,
        session_id: str,
        preferred_uuid: str | None,
        purpose: str,
    ) -> tuple[str | None, JsonlSessionHealth | None]:
        target = resolve_safe_jsonl_target(
            session_id=session_id,
            cwd=self._config.vault_path,
            preferred_uuid=preferred_uuid,
        )
        if target is None:
            persisted = self._persisted_session_uuids(session_id)
            if preferred_uuid and preferred_uuid in persisted:
                return preferred_uuid, None
            if persisted:
                return persisted[-1], None
            return preferred_uuid, None
        if target.changed:
            logger.warning(
                "[jsonl_health] purpose=%s session_id=%s preferred_uuid=%s "
                "resolved_uuid=%s reason=%s first_unsafe=%s first_poison=%s safe_line=%s",
                purpose,
                session_id,
                preferred_uuid,
                target.target_uuid,
                target.reason,
                target.health.first_unsafe_tail_uuid,
                target.health.first_poison_uuid,
                target.health.safe_recovery_line,
            )
        return target.target_uuid, target.health

    # CACHE-PREFIX WARNING: restart/idle recovery must use a complete
    # JSONL-visible prefix; bootstraps, inbox/task notices and resume notes append.
    # A break is silent: no error, the API just re-bills the whole conversation.
    # Live check: scripts/cache_regression.py queued_resume recovery_multi resume_new_proc (docs/cache-proxy-safety.md).
    async def _recover_route_session_if_needed(
        self,
        *,
        state: TelegramSessionState,
        source: str,
    ) -> str | None:
        session_id = state.session_id
        if not session_id:
            return None
        preferred_uuid = self._session_heads.get(session_id)
        target = resolve_safe_jsonl_target(
            session_id=session_id,
            cwd=self._config.vault_path,
            preferred_uuid=preferred_uuid,
        )
        if target is not None and is_stale_session_head(target.health, preferred_uuid):
            # vault-1bc2: a head the pre-fix analyzer pinned before a since-recovered
            # API-error row. Resolve as if no head were known (latest safe boundary)
            # instead of rolling the session back to the pin.
            target = resolve_safe_jsonl_target(
                session_id=session_id,
                cwd=self._config.vault_path,
                preferred_uuid=None,
            )
            logger.warning(
                "[session_head] stale_head route=%s session_id=%s stale_uuid=%s resolved_uuid=%s",
                state.route,
                session_id,
                preferred_uuid,
                target.target_uuid if target is not None else None,
            )
            if target is not None and target.target_uuid and not target.health.needs_recovery:
                self._set_session_head(session_id=session_id, jsonl_uuid=target.target_uuid)
        if target is None or not target.health.needs_recovery or not target.target_uuid:
            return None
        # obs-52: a content refusal is driven by what the context holds, so a
        # recovery re-sends it and is refused again (2026-10-25: nine recoveries
        # of the proc-work trunk in 18 minutes, one per wake, none answered).
        # A refused session that answered nothing of its own was a futile retry
        # of that context; after _CONTENT_REFUSAL_FUTILE_LIMIT of them in a row
        # stop and tell the route. The count so far is recorded for each
        # recovery fork made here, so restarts keep it and later work in the
        # source session cannot change it; every other session (/clear, a
        # reply forking from an earlier message) starts its own count.
        # Nothing is reworded; any answer resets it.
        refusal, futile = futile_refusal_streak(target.health, target.target_uuid)
        if refusal is not None and futile >= _CONTENT_REFUSAL_FUTILE_LIMIT:
            logger.warning(
                "[refusal_loop] route=%s source=%s session_id=%s kind=%s futile=%d "
                "recovery_uuid=%s: not recovering into the same context again",
                state.route, source, session_id, refusal, futile, target.target_uuid,
            )
            raise ContentRefusalLoopError(session_id=session_id, kind=refusal, futile=futile)

        old_model_override = state.session_manager.model_override
        old_effort_override = state.session_manager.effort_override
        old_user_hooks = (
            dict(state.session_manager.user_hooks)
            if state.session_manager.user_hooks is not None
            else None
        )
        old_env = state.session_manager.sdk_env_overrides
        old_explicit_env = state.session_manager.explicit_env_overrides
        old_lineage = self._ensure_state_lineage(state, session_id=session_id)
        old_projection = self._state_inbox_projection(state)

        try:
            recovery_session_id = fork_session_jsonl(
                session_id=session_id,
                target_uuid=target.target_uuid,
                cwd=self._config.vault_path,
                new_session_id=str(uuid.uuid4()),
            )
        except Exception as exc:
            # Dead-topic diagnostics (2026-10-12): a failed recovery fork aborts
            # every run on this route, so record the full recovery context.
            logger.error(
                "[jsonl_recovery_failed] route=%s source=%s session_id=%s "
                "preferred_uuid=%s recovery_uuid=%s target_reason=%s reason=%s "
                "first_unsafe=%s first_poison=%s safe_line=%s error=%s: %s",
                state.route,
                source,
                session_id,
                preferred_uuid,
                target.target_uuid,
                target.reason,
                target.health.unsafe_tail_reason,
                target.health.first_unsafe_tail_uuid,
                target.health.first_poison_uuid,
                target.health.safe_recovery_line,
                type(exc).__name__,
                exc,
            )
            raise
        logger.warning(
            "[jsonl_recovery] route=%s source=%s old_session_id=%s "
            "new_session_id=%s recovery_uuid=%s reason=%s first_unsafe=%s first_poison=%s",
            state.route,
            source,
            session_id,
            recovery_session_id,
            target.target_uuid,
            target.health.unsafe_tail_reason,
            target.health.first_unsafe_tail_uuid,
            target.health.first_poison_uuid,
        )
        if refusal is not None:
            try:
                record_refusal_streak(recovery_session_id, futile_before=futile, kind=refusal,
                                      source_session_id=session_id)
            except OSError as exc:
                logger.warning("[refusal_loop] could not record the streak for session_id=%s: %s",
                               recovery_session_id, exc)

        self._set_session_head(session_id=session_id, jsonl_uuid=target.target_uuid)
        self._set_session_head(session_id=recovery_session_id, jsonl_uuid=target.target_uuid)
        await self._activate_route_session(state, recovery_session_id)
        state.session_manager.model_override = old_model_override
        state.session_manager.effort_override = old_effort_override
        state.session_manager.user_hooks = old_user_hooks
        state.session_manager.explicit_env_overrides = old_explicit_env
        state.session_manager.set_sdk_env_overrides(old_env)

        self._prime_obs_bootstrap(
            state,
            lineage=old_lineage,
            origin="session_recovery",
            is_fork=True,
            parent_session_id=session_id,
            session_id=recovery_session_id,
            team_name=old_projection[0] if old_projection is not None else None,
            agent_name=old_projection[1] if old_projection is not None else None,
        )

        record = self._find_task_by_child_route(state.route)
        if record is not None:
            record.child_session_id = recovery_session_id
            record.parent_source_uuid = target.target_uuid
            self._persist_team_worker_record(record)
            self._persist_task_handle_record(record)

        self._persist_state_for_route(state.route)
        return recovery_session_id

    # CACHE-PREFIX WARNING: same as _resolve_fork_source for persisted fork records.
    # A break is silent: no error, the API just re-bills the whole conversation.
    # Live check: scripts/cache_regression.py recovery parallel_fork (docs/cache-proxy-safety.md).
    def _resolve_persisted_fork_source(
        self,
        *,
        session_id: str,
        preferred_uuid: str,
        preferred_route: TelegramRoute,
    ) -> tuple[str, TelegramRoute, int | None]:
        resolved_uuid, _health = self._resolve_safe_jsonl_target(
            session_id=session_id,
            preferred_uuid=preferred_uuid,
            purpose="fork_source",
        )
        if not resolved_uuid:
            return preferred_uuid, preferred_route, None
        located = self._find_bound_message_id(
            session_id=session_id,
            jsonl_uuid=resolved_uuid,
            preferred_route=preferred_route,
        )
        if located is None:
            return resolved_uuid, preferred_route, None
        resolved_route, message_id = located
        return resolved_uuid, resolved_route, message_id

    def _find_task_by_child_route(self, route: TelegramRoute) -> _ForkTaskRecord | None:
        task_id = self._fork_task_by_child_route.get(route)
        if not task_id:
            return None
        return self._fork_tasks_by_id.get(task_id)

    @staticmethod
    def _team_worker_key(team_name: str | None, agent_name: str | None) -> tuple[str, str] | None:
        team = (team_name or "").strip().lower()
        agent = (agent_name or "").strip().lower()
        if not team or not agent:
            return None
        return team, agent

    def _remove_team_worker_mappings_for_task(self, task_id: str) -> None:
        stale = [key for key, mapped in self._team_worker_records.items() if mapped == task_id]
        for key in stale:
            self._team_worker_records.pop(key, None)
        self._state_store.delete_team_worker_state_by_task_id(task_id=task_id)

    def _sweep_route_team_worker_mappings(
        self,
        route: TelegramRoute,
        *,
        terminal_status: str | None = None,
    ) -> None:
        """Hard-unbind any worker projection that still points at a dropped route.

        Live topic deletion can bypass the normal task-cancel path when the
        route disappears under the transport. In that case the route_state can
        be gone while the team_worker binding still survives, which then blocks
        same-alias respawn. This sweep makes route teardown authoritative.
        """
        for task_id, record in list(self._fork_tasks_by_id.items()):
            if record.child_route != route:
                continue
            if terminal_status and record.terminal_request is None:
                record.terminal_request = terminal_status
            if terminal_status and record.status not in {"completed", "failed", "stopped"}:
                record.status = terminal_status
            record.idle_ready = False
            record.wake_requested = False
            if terminal_status and record.completed_at is None:
                record.completed_at = time.time()
            self._fork_task_by_child_route.pop(record.child_route, None)
            self._remove_team_worker_mappings_for_task(task_id)
            self._persist_task_handle_record(record)

    def _persist_team_worker_record(self, record: _ForkTaskRecord) -> None:
        team = (record.team_name or "").strip()
        agent = (record.agent_name or "").strip()
        if not team or not agent:
            self._state_store.delete_team_worker_state_by_task_id(task_id=record.task_id)
            return
        self._state_store.upsert_team_worker_state(
            team_name=team,
            agent_name=agent,
            task_id=record.task_id,
            child_chat_id=record.child_route.chat_id,
            child_thread_id=record.child_route.thread_id,
            child_session_id=record.child_session_id,
            description=record.description,
            status=record.status,
            idle_ready=record.idle_ready,
        )

    def _persist_task_handle_record(self, record: _ForkTaskRecord) -> None:
        self._state_store.upsert_task_handle_state(
            task_id=record.task_id,
            parent_chat_id=record.parent_route.chat_id,
            parent_thread_id=record.parent_route.thread_id,
            parent_session_id_at_launch=record.parent_session_id_at_launch or None,
            parent_source_uuid=record.parent_source_uuid or None,
            child_chat_id=record.child_route.chat_id,
            child_thread_id=record.child_route.thread_id,
            child_session_id=record.child_session_id,
            description=record.description,
            status=record.status,
            is_fork=record.is_fork,
            launch_tool_name=record.launch_tool_name,
            team_name=record.team_name,
            agent_name=record.agent_name,
            idle_ready=record.idle_ready,
            terminal_request=record.terminal_request,
            result_text=record.result_text,
            error=record.error,
            timeout_ms=record.timeout_ms,
            max_turns=record.max_turns,
            launch_parent_message_id=record.launch_parent_message_id,
            launch_child_message_id=record.launch_child_message_id,
            child_completion_message_id=record.child_completion_message_id,
            parent_callback_message_id=record.parent_callback_message_id,
            created_at=record.created_at,
            completed_at=record.completed_at,
        )

    def _register_team_worker_record(self, record: _ForkTaskRecord) -> None:
        self._remove_team_worker_mappings_for_task(record.task_id)
        self._persist_task_handle_record(record)
        key = self._team_worker_key(record.team_name, record.agent_name)
        if key is not None:
            self._team_worker_records[key] = record.task_id
            child_state = self._get_state(record.child_route, create=False)
            obs_metadata = None
            if child_state is not None:
                bootstrap = None
                if child_state.pending_obs_bootstrap:
                    try:
                        bootstrap = parse_obs_bootstrap_xml(child_state.pending_obs_bootstrap)
                    except Exception:
                        bootstrap = None
                lineage = child_state.agent_lineage
                if (not lineage) and bootstrap is not None and bootstrap.lineage:
                    lineage = bootstrap.lineage
                obs_metadata = self._build_team_projection_obs_metadata(
                    lineage=lineage,
                    team_name=record.team_name,
                    agent_name=record.agent_name,
                    route=record.child_route,
                    parent_agent_name=bootstrap.parent_agent_name if bootstrap is not None else None,
                    parent_display_name=bootstrap.parent_display_name if bootstrap is not None else None,
                )
            self._upsert_team_projection_config(
                team_name=record.team_name,
                agent_name=record.agent_name,
                child_session_id=record.child_session_id,
                obs_metadata=obs_metadata,
            )
            self._persist_team_worker_record(record)

    def _resolve_task_record(
        self,
        *,
        task_id: str | None = None,
        team_name: str | None = None,
        agent_name: str | None = None,
        caller_route: TelegramRoute | None = None,
    ) -> _ForkTaskRecord | None:
        """Resolve an internal handle or stable identity within caller access."""
        normalized_task_id = (task_id or "").strip()
        if normalized_task_id:
            return self._fork_tasks_by_id.get(normalized_task_id)
        key = self._team_worker_key(team_name, agent_name)
        if key is None:
            return None
        if caller_route is not None and not self._is_task_team_accessible(caller_route, key[0]):
            return None
        active_task_id = self._team_worker_records.get(key)
        if active_task_id:
            active_record = self._fork_tasks_by_id.get(active_task_id)
            if active_record is not None:
                return active_record
        matches = [
            record
            for record in self._fork_tasks_by_id.values()
            if self._team_worker_key(record.team_name, record.agent_name) == key
        ]
        return max(matches, key=lambda record: (record.created_at, record.task_id), default=None)

    def _caller_team_name(self, route: TelegramRoute) -> str | None:
        state = self._get_state(route, create=False)
        if state is None:
            return None
        bootstrap = None
        if state.pending_obs_bootstrap:
            try:
                bootstrap = parse_obs_bootstrap_xml(state.pending_obs_bootstrap)
            except Exception:
                return None
        env_team = state.session_manager.sdk_env_overrides.get("CLAUDE_CODE_TEAM_NAME", "").strip()
        bootstrap_team = bootstrap.root_team_key.strip() if bootstrap and bootstrap.root_team_key else ""
        persisted_bootstrap = None
        if state.session_id:
            persisted_bootstrap = find_latest_obs_bootstrap_for_session(
                session_id=state.session_id,
                cwd=self._config.vault_path,
            )
        persisted_team = (
            persisted_bootstrap.root_team_key.strip()
            if persisted_bootstrap and persisted_bootstrap.root_team_key
            else ""
        )
        candidates: set[str] = set()
        for value in (env_team, bootstrap_team, persisted_team):
            if not value:
                continue
            try:
                normalized = self._normalize_task_identity(value, field_name="team_name")
            except ValueError:
                return None
            if normalized is not None:
                candidates.add(normalized.lower())
        if len(candidates) != 1:
            return None
        candidate = next(iter(candidates))

        # A process environment value is a caller identity source, but it must
        # not contradict an already-bound route or task record for this route.
        bound_teams: set[str] = set()
        inbox_key = self._route_inbox_target_keys_by_route.get(route)
        if inbox_key is not None:
            bound_teams.add(inbox_key[0])
        for record in self._fork_tasks_by_id.values():
            if record.child_route != route and record.parent_route != route:
                continue
            record_team = (record.team_name or "").strip().lower()
            if record_team:
                bound_teams.add(record_team)
        if bound_teams and candidate not in bound_teams:
            return None
        return candidate

    def _is_task_team_accessible(self, route: TelegramRoute, target_team_name: str) -> bool:
        caller_team = self._caller_team_name(route)
        return caller_team is not None and caller_team == target_team_name.strip().lower()

    def _resolve_task_lookup(
        self,
        *,
        route: TelegramRoute,
        task_id: str | None,
        team_name: str | None,
        agent_name: str | None,
    ) -> _ForkTaskRecord | None:
        caller_team = self._caller_team_name(route)
        if task_id:
            record = self._resolve_task_record(task_id=task_id)
            if record is None:
                return None
            if not record.team_name:
                return record
            if caller_team is None or record.team_name.strip().lower() != caller_team:
                return None
            return record
        resolved_team = (team_name or caller_team or "").strip().lower()
        if not resolved_team:
            return None
        if caller_team is None or resolved_team != caller_team:
            return None
        return self._resolve_task_record(
            team_name=resolved_team,
            agent_name=agent_name,
            caller_route=route,
        )

    def _resolve_team_worker_record(
        self,
        *,
        team_name: str | None,
        agent_name: str | None,
    ) -> _ForkTaskRecord | None:
        """Resolve only the currently registered worker for inbox delivery."""
        key = self._team_worker_key(team_name, agent_name)
        if key is None:
            return None
        task_id = self._team_worker_records.get(key)
        if not task_id:
            return None
        record = self._fork_tasks_by_id.get(task_id)
        if record is None:
            self._remove_team_worker_mappings_for_task(task_id)
            return None
        return record

    def _resolve_route_inbox_target(
        self,
        *,
        team_name: str | None,
        agent_name: str | None,
    ) -> TelegramSessionState | None:
        key = self._team_worker_key(team_name, agent_name)
        if key is None:
            return None
        route = self._route_inbox_targets.get(key)
        if route is None:
            return None
        state = self._get_state(route, create=False)
        if state is None:
            self._remove_route_inbox_target(route)
            return None
        return state

    def _recipient_delivery_status(
        self,
        *,
        team_name: str | None,
        agent_name: str | None,
    ) -> dict[str, Any]:
        """Check whether a recipient currently has a live route binding.

        This function MUST NOT have side effects. It answers one question only:
        can the runtime currently route a message to this agent identity?
        """
        record = self._resolve_team_worker_record(
            team_name=team_name,
            agent_name=agent_name,
        )
        if record is not None:
            child_state = self._get_state(record.child_route, create=False)
            if child_state is not None:
                return {"deliverable": True}
            return {
                "deliverable": False,
                "reason": "recipient has no current route binding",
            }
        state = self._resolve_route_inbox_target(
            team_name=team_name,
            agent_name=agent_name,
        )
        if state is not None:
            return {"deliverable": True}
        return {
            "deliverable": False,
            "reason": "recipient has no current route binding",
        }

    def _mark_task_terminal_request(self, route: TelegramRoute, status: str) -> None:
        for record in self._fork_tasks_by_id.values():
            if record.child_route != route and record.parent_route != route:
                continue
            if record.terminal_request is None:
                record.terminal_request = status

    def _mark_child_task_terminal_request(self, route: TelegramRoute, status: str) -> None:
        """Mark delegated tasks running in this child route as terminal."""
        for record in self._fork_tasks_by_id.values():
            if record.child_route != route:
                continue
            if record.terminal_request is None:
                record.terminal_request = status

    def _resolve_existing_tree_state(
        self,
        *,
        team_name: str,
        agent_name: str,
        member: dict[str, Any] | None = None,
    ) -> TelegramSessionState | None:
        record = self._resolve_team_worker_record(
            team_name=team_name,
            agent_name=agent_name,
        )
        if record is not None:
            state = self._get_state(record.child_route, create=False)
            if state is not None:
                return state

        state = self._resolve_route_inbox_target(
            team_name=team_name,
            agent_name=agent_name,
        )
        if state is not None:
            return state

        if isinstance(member, dict):
            topic_chat_id = member.get("topic_chat_id")
            topic_thread_id = member.get("topic_thread_id")
            if isinstance(topic_chat_id, int) and (
                topic_thread_id is None or isinstance(topic_thread_id, int)
            ):
                return self._get_state(
                    TelegramRoute(chat_id=topic_chat_id, thread_id=topic_thread_id),
                    create=False,
                )
        return None

    def _tree_stop_snapshot(
        self,
        *,
        state: TelegramSessionState,
        scope: str,
    ) -> tuple[list[TelegramSessionState], int, tuple[str, ...] | None]:
        context_tuple = self._current_tree_context(state)
        if context_tuple is None:
            return [], 0, None
        team_name, current_agent_name, current_lineage = context_tuple
        members = self._load_tree_members(
            team_name=team_name,
            current_agent_name=current_agent_name,
            current_lineage=current_lineage,
            current_route=state.route,
        )
        member_names = set(members)
        member_names.update(
            agent_name
            for team, agent_name in self._route_inbox_targets
            if team == team_name
        )
        member_names.update(
            agent_name
            for team, agent_name in self._team_worker_records
            if team == team_name
        )
        member_names.add(current_agent_name)

        targets: list[TelegramSessionState] = []
        seen_routes: set[TelegramRoute] = set()
        stale = 0
        for agent_name in sorted(member_names):
            member = members.get(agent_name) or {}
            lineage = member.get("lineage")
            if not isinstance(lineage, list):
                candidate = self._resolve_existing_tree_state(
                    team_name=team_name,
                    agent_name=agent_name,
                    member=member,
                )
                lineage = list(candidate.agent_lineage) if candidate is not None and candidate.agent_lineage else None
            normalized_lineage = tuple(
                normalize_lineage_name(item)
                for item in (lineage or ())
                if isinstance(item, str) and normalize_lineage_name(item)
            )
            if scope == "branch":
                if agent_name != current_agent_name and normalized_lineage[: len(current_lineage)] != current_lineage:
                    continue
            candidate = state if agent_name == current_agent_name else self._resolve_existing_tree_state(
                team_name=team_name,
                agent_name=agent_name,
                member=member,
            )
            if candidate is None:
                stale += 1
                continue
            if candidate.route in seen_routes:
                continue
            seen_routes.add(candidate.route)
            targets.append(candidate)

        if state.route not in seen_routes:
            targets.insert(0, state)
        return targets, stale, current_lineage

    async def _interrupt_scoped_states(
        self,
        *,
        states: list[TelegramSessionState],
        bot: Any,
    ) -> dict[str, int]:
        counts = {"interrupted": 0, "already_inactive": 0, "failed": 0}
        seen_routes: set[TelegramRoute] = set()
        for state in states:
            if state.route in seen_routes:
                continue
            seen_routes.add(state.route)
            state.last_bot = bot
            was_active = bool(state.busy or state.hook_state.execution_active)
            try:
                sent = await self._request_route_interrupt(state)
                self._mark_child_task_terminal_request(state.route, "stopped")
                if sent:
                    counts["interrupted"] += 1
                elif was_active:
                    counts["failed"] += 1
                else:
                    counts["already_inactive"] += 1
            except Exception:
                counts["failed"] += 1
                logger.debug("Scoped route interrupt failed route=%s", state.route, exc_info=True)
        return counts

    def _mark_stop_requested(self, state: TelegramSessionState, *, stamp: float | None = None) -> None:
        """Record a stop for the running turn and arm the kill escalation (vault-u3b.65).

        While set, a CLI exit ends the turn instead of reconnecting with
        "Resume the interrupted response", and the route is left out of crash and
        maintenance snapshots.
        """
        if not (state.busy or state.hook_state.execution_active):
            return
        stamp = time.time() if stamp is None else stamp
        state.hook_state.stop_requested_at = stamp
        grace = _stop_kill_grace_seconds()
        if grace <= 0:
            return
        client = state.session_manager._client
        process = getattr(getattr(client, "_transport", None), "_process", None)
        pid = getattr(process, "pid", None)
        owned: dict[int, int] = {}
        if _is_killable_cli_pid(pid):
            try:
                # Capture before yielding or publishing the active-stop receipt: the
                # CLI can exit immediately on interrupt/SIGTERM and lose its ancestry.
                owned = _maint.capture_process_tree(pid)
            except (OSError, ValueError):
                logger.debug("Stop tree capture unavailable pid=%s", pid, exc_info=True)
        else:
            pid = None
        task = asyncio.create_task(
            self._escalate_stop(state, stamp=stamp, grace=grace, client=client, pid=pid, owned=owned)
        )
        self._stop_escalation_tasks.add(task)
        task.add_done_callback(self._stop_escalation_tasks.discard)

    def _latch_task_stop(self, state: TelegramSessionState) -> None:
        """Stop a task's route durably (obs-2): AgentTaskStop and task-scoped stops.

        Unlike a plain turn stop, the latch outlives the running turn. Queued
        work that was waiting when the stop landed is discarded (the /stop
        policy), later queued items are not auto-delivered, the route is left
        out of restart snapshots and the running turn, if any, gets the stop
        mark and kill escalation. Explicit new input clears the latch
        (``_clear_stop_latch``): agents stay idle, not dead.
        """
        hook_state = state.hook_state
        stamp = time.time()
        hook_state.stop_latched_at = stamp
        hook_state.interrupt_flag = True
        active = bool(state.busy or hook_state.execution_active)
        if active:
            # Discard the runner's leftover batch at turn end, like /stop.
            hook_state.interrupt_requested = True
        discarded = len(_drain_queue(hook_state.message_queue)) + len(state.pending_messages)
        state.pending_messages = []
        state.inbox_wake_pending = False  # a wake queued before the stop
        self._mark_stop_requested(state, stamp=stamp)
        logger.info(
            "[task_stop] latched route=%s active=%s discarded_queued=%d",
            state.route,
            active,
            discarded,
        )

    @staticmethod
    def _clear_stop_latch(state: TelegramSessionState | None, reason: str) -> None:
        if state is None or state.hook_state.stop_latched_at is None:
            return
        state.hook_state.stop_latched_at = None
        logger.info("[task_stop] latch cleared route=%s reason=%s", state.route, reason)

    async def _interrupt_live_client(self, state: TelegramSessionState) -> None:
        """Interrupt the route's running CLI without starting one for an idle route."""
        session_mgr = state.session_manager
        client = session_mgr._client
        if client is None or not session_mgr._connected:
            return
        try:
            await client.interrupt()
        except Exception:
            logger.debug("Task stop interrupt failed route=%s", state.route, exc_info=True)

    async def _escalate_stop(
        self, state: TelegramSessionState, *, stamp: float, grace: float,
        client: Any, pid: object, owned: dict[int, int],
    ) -> None:
        deadline = asyncio.get_running_loop().time() + grace
        while True:
            stopped_turn_active = (
                state.hook_state.stop_requested_at == stamp
                and bool(state.busy or state.hook_state.execution_active)
                and state.session_manager._client is client
            )
            if not stopped_turn_active:
                # A new turn may reuse this CLI; only the old tool identities
                # remain ours to reap, not that CLI or its new tool children.
                owned.pop(pid, None)
            if owned:
                # Do not yield between the turn check, ancestry refresh and reap:
                # a replacement turn must not donate its new tools to this stop.
                owned = _maint.refresh_process_tree(owned)
            remaining = deadline - asyncio.get_running_loop().time()
            root_alive = pid in owned and _maint.process_identity_matches(pid, owned[pid])
            if not stopped_turn_active or (owned and not root_alive) or remaining <= 0:
                break
            await asyncio.sleep(min(0.1, remaining))
        if owned:
            try:
                killed = _maint.kill_process_identities(owned)
                logger.warning("[stop_escalation] killed retained pids=%s route=%s", killed, state.route)
            except Exception:
                logger.warning("[stop_escalation] retained tree kill failed route=%s", state.route, exc_info=True)
        if not stopped_turn_active:
            return
        logger.warning("[stop_escalation] disconnecting stopped CLI pid=%s route=%s", pid, state.route)
        session_mgr = state.session_manager
        try:
            async with asyncio.timeout(10.0):
                async with session_mgr._lock:
                    # Lock acquisition can outlive this turn. Revalidate at
                    # actuation, including a new turn reusing the SAME client.
                    if (
                        state.hook_state.stop_requested_at == stamp
                        and bool(state.busy or state.hook_state.execution_active)
                        and session_mgr._client is client
                    ):
                        await session_mgr._direct_kill_client_process_unlocked()
        except Exception:
            # The owned OS tree was already reaped above. Bypassing this lock
            # could instead kill a replacement client or clobber its reference.
            logger.warning("[stop_escalation] stopped client teardown unavailable route=%s", state.route, exc_info=True)

    async def _request_route_interrupt(self, state: TelegramSessionState) -> bool:
        """Set interrupt intent and attempt SDK interrupt for one route."""
        state.hook_state.interrupt_flag = True
        state.hook_state.interrupt_requested = bool(
            state.busy or state.hook_state.execution_active
        )
        state.hook_state.interrupt_notice_pending = True
        self._mark_stop_requested(state)
        session_mgr = state.session_manager
        if session_mgr._client is None or not session_mgr._connected:
            return False
        try:
            await session_mgr._client.interrupt()
            return True
        except Exception:
            logger.debug("Route interrupt failed route=%s", state.route, exc_info=True)
            return False

    async def _cancel_route_fork_tasks(self, route: TelegramRoute, status: str) -> None:
        for task_id, record in list(self._fork_tasks_by_id.items()):
            if record.child_route != route and record.parent_route != route:
                continue
            await self._cancel_fork_task_record(task_id, record, status)

    async def _cancel_running_fork_tasks(self, status: str) -> int:
        """Cancel every AgentTask child whose task is still running, in every tree (/stop all)."""
        cancelled = 0
        for task_id, record in list(self._fork_tasks_by_id.items()):
            task = self._fork_task_tasks.get(task_id)
            if task is None or task.done():
                continue
            await self._cancel_fork_task_record(task_id, record, status)
            cancelled += 1
        return cancelled

    async def _cancel_fork_task_record(self, task_id: str, record: Any, status: str) -> None:
        if record.terminal_request is None:
            record.terminal_request = status
        if record.status not in {"completed", "failed", "stopped"}:
            record.status = status
        record.idle_ready = False
        record.wake_requested = False
        if record.completed_at is None:
            record.completed_at = time.time()

        parent_state = self._get_state(record.parent_route, create=False)
        if parent_state is not None:
            parent_state.active_fork_task_ids.discard(task_id)

        child_state = self._get_state(record.child_route, create=False)
        if child_state is not None:
            self._latch_task_stop(child_state)
            await self._interrupt_live_client(child_state)

        task = self._fork_task_tasks.get(task_id)
        if task is not None and not task.done():
            task.cancel()

        self._fork_task_by_child_route.pop(record.child_route, None)
        self._remove_team_worker_mappings_for_task(task_id)
        self._persist_task_handle_record(record)

    def _task_lookup_error_result(self, message: str) -> dict[str, Any]:
        text = f"Invalid task lookup: {message}"
        return {
            "content": [{"type": "text", "text": f"<tool_use_error>{html.escape(text)}</tool_use_error>"}],
            "tool_use_result": f"Error: {text}",
            "is_error": True,
        }

    def _task_not_found_result(self, task_id: str) -> dict[str, Any]:
        if "/" not in task_id:
            text = f"No task found with ID: {task_id}"
        else:
            text = f"No task found with ID or stable identity: {task_id}"
        return {
            "content": [
                {
                    "type": "text",
                    "text": f"<tool_use_error>{text}</tool_use_error>",
                }
            ],
            "tool_use_result": f"Error: {text}",
            "is_error": True,
        }

    def _task_not_running_result(self, task_id: str, *, status: str) -> dict[str, Any]:
        text = f"Task {task_id} is not running (status: {status})"
        return {
            "content": [{"type": "text", "text": f"<tool_use_error>{text}</tool_use_error>"}],
            "tool_use_result": f"Error: {text}",
            "is_error": True,
        }

    def _record_output_file(self, record: _ForkTaskRecord) -> str | None:
        if not record.child_session_id:
            return None
        return self._child_session_path(record.child_session_id)

    def _record_lineage_for_record(self, record: _ForkTaskRecord) -> tuple[str, ...]:
        state = self._get_state(record.child_route, create=False)
        if state is not None and state.agent_lineage:
            return tuple(state.agent_lineage)
        metadata = self._load_team_projection_metadata(record.team_name or "")
        entry = metadata.get(record.agent_name or "", {})
        lineage = entry.get("lineage")
        if isinstance(lineage, list):
            return tuple(str(item).strip() for item in lineage if str(item).strip())
        return ()

    def _record_output_snapshot(self, record: _ForkTaskRecord) -> str:
        output_file = self._record_output_file(record)
        if output_file is None:
            return ""
        try:
            with Path(output_file).open("rb") as handle:
                handle.seek(0, 2)
                size = handle.tell()
                handle.seek(max(size - _TASK_OUTPUT_SCAN_BYTES, 0))
                raw = handle.read(_TASK_OUTPUT_SCAN_BYTES)
        except OSError:
            return ""
        lines = raw.decode("utf-8", errors="replace").splitlines()
        if size > _TASK_OUTPUT_SCAN_BYTES and lines:
            lines = lines[1:]
        texts: list[str] = []
        for line in lines:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(entry, dict):
                continue
            entry_type = str(entry.get("type") or "").strip().lower()
            candidates: list[str] = []
            if entry_type == "assistant":
                message = entry.get("message")
                content = message.get("content") if isinstance(message, dict) else None
                if isinstance(content, str):
                    candidates.append(content)
                elif isinstance(content, list):
                    for block in content:
                        if (
                            isinstance(block, dict)
                            and block.get("type") == "text"
                            and isinstance(block.get("text"), str)
                        ):
                            candidates.append(block["text"])
                            if len(candidates) >= _TASK_OUTPUT_MAX_TEXTS_PER_RECORD:
                                break
            elif entry_type == "progress":
                data = entry.get("data")
                if isinstance(data, dict):
                    for key in ("message", "text", "summary"):
                        value = data.get(key)
                        if isinstance(value, str):
                            candidates.append(value)
                            if len(candidates) >= _TASK_OUTPUT_MAX_TEXTS_PER_RECORD:
                                break
            else:
                continue
            record_texts: list[str] = []
            seen_texts: set[str] = set()
            for text in candidates[:_TASK_OUTPUT_MAX_TEXTS_PER_RECORD]:
                normalized = text.strip()
                if normalized and normalized not in seen_texts:
                    seen_texts.add(normalized)
                    record_texts.append(normalized[:_TASK_OUTPUT_MAX_RECORD_CHARS])
            if record_texts:
                texts.append("\n".join(record_texts))
        texts = texts[-_TASK_OUTPUT_MAX_RECORDS:]
        snapshot = "\n".join(texts)
        if len(snapshot) > _TASK_OUTPUT_MAX_CHARS:
            snapshot = "[truncated to the most recent output]\n" + snapshot[-_TASK_OUTPUT_MAX_CHARS:]
        return snapshot

    @staticmethod
    def _normalize_task_identity(value: Any, *, field_name: str) -> str | None:
        normalized = str(value or "").strip()
        if not normalized:
            return None
        pattern = _SAFE_TEAM_IDENTITY_RE if field_name == "team_name" else _SAFE_AGENT_IDENTITY_RE
        if len(normalized) > _TASK_IDENTITY_MAX_CHARS or not pattern.fullmatch(normalized.lower()):
            raise ValueError(f"{field_name} must be a hash-prefixed stable identity")
        return normalized

    def _task_lookup_args(self, args: dict[str, Any]) -> tuple[str | None, str | None, str | None]:
        task_id = str(args.get("task_id") or "").strip() or None
        team_name = self._normalize_task_identity(args.get("team_name"), field_name="team_name")
        agent_name = self._normalize_task_identity(args.get("agent_name"), field_name="agent_name")
        if task_id and (team_name or agent_name):
            raise ValueError("task_id cannot be combined with team_name or agent_name")
        if team_name and not agent_name:
            raise ValueError("team_name requires agent_name")
        if not task_id and not agent_name:
            raise ValueError("task_id or agent_name is required")
        return task_id, team_name, agent_name

    def _record_status_for_notification(self, record: _ForkTaskRecord) -> str:
        if record.status == "completed":
            return "idle"
        if record.status == "stopped":
            return "stopped"
        return "failed"

    def _record_status_label(self, record: _ForkTaskRecord) -> str:
        if record.status == "completed":
            return "went idle"
        if record.status == "stopped":
            return "stopped"
        if record.status == "failed" and record.error == "timed out":
            return "timed out"
        return record.status

    def _record_summary(self, record: _ForkTaskRecord) -> str:
        label = record.description or self._current_topic_title(record.child_route)
        status = self._record_status_label(record)
        task_noun = "Fork" if record.is_fork else "Agent task"
        if label:
            return f'{task_noun} "{label}" {status}'
        return f"{task_noun} {status}"

    def _build_fork_task_notification_xml(self, record: _ForkTaskRecord) -> str:
        lines = [
            "<task-notification>",
            f"  <task-id>{html.escape(record.task_id)}</task-id>",
        ]
        if record.tool_use_id:
            lines.append(f"  <tool-use-id>{html.escape(record.tool_use_id)}</tool-use-id>")
        lines.extend(
            [
                f"  <status>{html.escape(self._record_status_for_notification(record))}</status>",
                f"  <summary>{html.escape(self._record_summary(record))}</summary>",
                "  <result>",
                html.escape(record.result_text or record.error or ""),
                "  </result>",
                "  <usage>",
                f"    <total_tokens>{record.usage_total_tokens or 0}</total_tokens>",
                f"    <tool_uses>{record.usage_tool_uses or 0}</tool_uses>",
                f"    <duration_ms>{record.usage_duration_ms or 0}</duration_ms>",
                "  </usage>",
                "</task-notification>",
            ]
        )
        output_file = self._record_output_file(record)
        if output_file:
            lines.append(f"Full transcript available at: {output_file}")
        child_link = None
        if record.child_completion_message_id is not None:
            child_link = self._build_message_link(
                record.child_route, record.child_completion_message_id
            )
        if child_link:
            lines.append(f"Telegram topic: {child_link}")
        return "\n".join(lines)

    def _build_fork_task_output_text(
        self,
        *,
        record: _ForkTaskRecord,
        retrieval_status: str,
        status: str,
        output: str | None,
        output_file: str | None = None,
    ) -> str:
        if output and len(output) > _TASK_OUTPUT_MAX_CHARS:
            output = "[truncated to the most recent output]\n" + output[-_TASK_OUTPUT_MAX_CHARS:]
        parts = [f"<retrieval_status>{retrieval_status}</retrieval_status>"]
        parts.append("")
        parts.append(f"<task_id>{record.task_id}</task_id>")
        parts.append("<task_id_scope>deprecated_internal_compatibility</task_id_scope>")
        if record.team_name:
            parts.append(f"<team_name>{html.escape(record.team_name)}</team_name>")
        if record.agent_name:
            parts.append(f"<agent_name>{html.escape(record.agent_name)}</agent_name>")
        lineage = self._record_lineage_for_record(record)
        parts.append(f"<lineage>{html.escape(' / '.join(lineage) if lineage else '<unavailable>')}</lineage>")
        if record.child_session_id:
            parts.append(f"<session_id>{html.escape(record.child_session_id)}</session_id>")
        if output_file:
            parts.append(
                f"<output_file scope=\"trusted_internal_record_derived\">"
                f"{html.escape(output_file)}</output_file>"
            )
        parts.append("")
        parts.append("<task_type>local_agent</task_type>")
        parts.append("")
        parts.append(f"<status>{status}</status>")
        if output:
            parts.append("")
            parts.append("<output>")
            parts.append(output)
            parts.append("</output>")
        return "\n".join(parts)

    def _build_fork_task_output_result(
        self,
        *,
        record: _ForkTaskRecord,
        retrieval_status: str,
        status: str,
        output: str | None,
        output_file: str | None = None,
    ) -> dict[str, Any]:
        bounded_output = output
        if bounded_output and len(bounded_output) > _TASK_OUTPUT_MAX_CHARS:
            bounded_output = "[truncated to the most recent output]\n" + bounded_output[-_TASK_OUTPUT_MAX_CHARS:]
        task = {
            "task_id": record.task_id,
            "task_id_scope": "deprecated_internal_compatibility",
            "lineage": list(self._record_lineage_for_record(record)),
            "team_name": record.team_name,
            "agent_name": record.agent_name,
            "session_id": record.child_session_id or None,
            "task_type": "local_agent",
            "status": status,
            "result": bounded_output or "",
        }
        if record.description:
            task["description"] = record.description
        if bounded_output:
            task["output"] = bounded_output
        if output_file:
            task["output_file"] = output_file
            task["output_file_scope"] = "trusted_internal_record_derived"
        return {
            "content": [
                {
                    "type": "text",
                    "text": self._build_fork_task_output_text(
                        record=record,
                        retrieval_status=retrieval_status,
                        status=status,
                        output=output,
                        output_file=output_file,
                    ),
                }
            ],
            "tool_use_result": {"retrieval_status": retrieval_status, "task": task},
        }

    def _build_fork_task_callback_payload(self, record: _ForkTaskRecord) -> str:
        return self._build_fork_task_notification_xml(record)

    def _build_fork_task_terminal_html(
        self,
        *,
        record: _ForkTaskRecord,
        parent_callback_link: str | None,
    ) -> str:
        task_prefix = "fork task" if record.is_fork else "agent task"
        lines = [f"{task_prefix} {html.escape(self._record_status_label(record))}"]
        if parent_callback_link:
            lines.append(
                f'returned to <a href="{html.escape(parent_callback_link)}">parent topic</a>'
            )
        return "\n".join(lines)

    def _coerce_timeout_ms(self, value: Any) -> int | None:
        # No timeout by default — agents run until they finish naturally.
        # timeout_ms is hidden from MCP schema; only set internally if needed.
        if value is None:
            return None
        parsed = max(int(value), 1)
        return parsed

    def _coerce_max_turns(self, value: Any) -> int | None:
        if value is None:
            return None
        parsed = int(value)
        return parsed if parsed > 0 else None

    # CACHE-PREFIX WARNING: picks the JSONL point a fork/recovery copies from; a
    # mid-message or in-flight target makes the forked history differ (M5).
    # A break is silent: no error, the API just re-bills the whole conversation.
    # Live check: scripts/cache_regression.py recovery recovery_multi parallel_fork (docs/cache-proxy-safety.md).
    def _resolve_fork_source(
        self,
        *,
        state: TelegramSessionState,
        reply_message_id: int | None = None,
    ) -> tuple[str | None, str | None, TelegramRoute, int | None]:
        source_binding = (
            self._message_map.get((state.route.chat_id, reply_message_id))
            if isinstance(reply_message_id, int)
            else None
        )
        if source_binding is not None:
            return (
                source_binding.session_id,
                source_binding.jsonl_uuid,
                source_binding.route,
                reply_message_id,
            )

        source_session_id = state.session_id
        source_uuid = self._session_heads.get(source_session_id or "")
        source_route = state.route
        if source_session_id and not source_uuid:
            # Tool callbacks can race slightly ahead of session-head bookkeeping.
            # Fall back to the latest safe persisted UUID for this session.
            safe_uuid, _health = self._resolve_safe_jsonl_target(
                session_id=source_session_id,
                preferred_uuid=None,
                purpose="missing_head",
            )
            if safe_uuid:
                source_uuid = safe_uuid
        located = (
            self._find_bound_message_id(
                session_id=source_session_id,
                jsonl_uuid=source_uuid,
                preferred_route=state.route,
            )
            if source_session_id and source_uuid
            else None
        )
        source_message_id = located[1] if located else None
        if source_session_id and source_uuid:
            resolved_uuid, resolved_route, resolved_message_id = self._resolve_persisted_fork_source(
                session_id=source_session_id,
                preferred_uuid=source_uuid,
                preferred_route=source_route,
            )
            if resolved_uuid != source_uuid:
                logger.info(
                    "[fork_source] falling back to persisted uuid route=%s session_id=%s head_uuid=%s persisted_uuid=%s",
                    state.route,
                    source_session_id,
                    source_uuid,
                    resolved_uuid,
                )
                source_uuid = resolved_uuid
                source_route = resolved_route
                source_message_id = resolved_message_id
        return source_session_id, source_uuid, source_route, source_message_id

    async def _ensure_background_poller(self, bot: Any | None) -> None:
        if bot is not None:
            self._primary_bot = bot
        if not self._enable_background_poller:
            return
        try:
            from obs_agent.loop_monitor import ensure_loop_stall_monitor

            ensure_loop_stall_monitor()
        except Exception:
            logger.debug("[loop_stall] monitor start failed", exc_info=True)
        if self._background_task is None or self._background_task.done():
            self._background_task = asyncio.create_task(self._background_poller_loop())
        if self._schedule_poller_task is None or self._schedule_poller_task.done():
            self._schedule_poller_task = asyncio.create_task(self._schedule_poller_loop())
        if (
            float(getattr(self._config, "claude_idle_evict_seconds", 0.0) or 0.0) > 0
            and (self._idle_evict_task is None or self._idle_evict_task.done())
        ):
            self._idle_evict_task = asyncio.create_task(self._idle_evict_loop())
        if _cli_hang_watchdog_seconds() > 0 and (self._cli_hang_task is None or self._cli_hang_task.done()):
            self._cli_hang_task = asyncio.create_task(self._cli_hang_watchdog_loop())
        if (
            self._control_server is None
            and (self._control_start_task is None or self._control_start_task.done())
            and (os.environ.get("OBS_CONTROL_DISABLE") or "").strip().lower() not in ("1", "true", "yes", "on")
        ):
            self._control_start_task = asyncio.create_task(self._start_control_server())

    async def _start_control_server(self) -> None:
        """Start the external control socket (vault-h667); a failure never affects the bot."""
        from obs_agent.control import ControlServer

        server = ControlServer(self._control_dispatch)
        try:
            await server.start()
        except Exception:
            logger.warning("external control channel failed to start", exc_info=True)
            return
        self._control_server = server
        logger.info("external control channel listening")

    def _control_agent_state(self, team_name: str, agent_name: str) -> TelegramSessionState | None:
        record = self._resolve_team_worker_record(team_name=team_name, agent_name=agent_name)
        if record is not None:
            state = self._get_state(record.child_route, create=False)
            if state is not None:
                return state
        return self._resolve_route_inbox_target(team_name=team_name, agent_name=agent_name)

    def _control_tools(self, *, hook_state: HookState, session_id: str | None) -> dict[str, Any]:
        """The agent tool handlers, so external actions take the exact agent code paths."""
        from obs_agent.tools import create_obs_tools

        tools = create_obs_tools(self._config, lambda: session_id, hook_state=hook_state, return_tools=True)
        return {tool.name: tool.handler for tool in tools}

    async def _control_dispatch(self, op: str, caller: str, args: dict[str, Any]) -> dict[str, Any]:
        from obs_agent.control import tool_result_to_control

        label = f"external:{caller}"
        if op == "message":
            hook_state = HookState()
            sentinel = TelegramRoute(chat_id=0, thread_id=None)
            hook_state.inbox_recipient_validator = self._make_inbox_recipient_validator(sentinel)
            hook_state.inbox_message_notifier = self._make_inbox_message_notifier(sentinel)
            tools = self._control_tools(hook_state=hook_state, session_id=None)
            result = await tools["SendInboxMessage"]({
                "team_name": str(args["team_name"]).strip(),
                "recipient": str(args["recipient"]).strip(),
                "content": str(args["content"]),
                "summary": str(args.get("summary") or "").strip() or f"from {label}",
                "sender": label,
                "allow_cold_wake": bool(args.get("allow_cold_wake")),
            })
            return tool_result_to_control(result)
        if op == "stop":
            return await self._control_stop_child(args)
        if op == "launch":
            parent = self._control_agent_state(str(args["parent_team"]).strip(), str(args["parent_agent"]).strip())
            if parent is None:
                return {"ok": False, "error": "parent agent has no current route binding"}
            fork = bool(args.get("fork", True))
            allow_cold_wake = bool(args.get("allow_cold_wake"))
            if fork and not args.get("session_source") and not allow_cold_wake:
                # Forking the parent's head re-reads its whole context, like a wake (vault-vokl).
                readiness = self._state_cache_readiness(state=parent, session_id=parent.session_id)
                if readiness is not None and readiness.cold:
                    return {
                        "ok": False,
                        "cold": True,
                        "error": _cache_readiness.cold_warning(
                            readiness, action="fork of", target=str(args["parent_agent"])
                        ),
                    }
            parent_hooks = parent.hook_state
            hook_state = HookState()
            hook_state.session_id = parent.session_id
            hook_state.pending_obs_bootstrap_xml = parent_hooks.pending_obs_bootstrap_xml
            hook_state.sdk_env_overrides = dict(parent_hooks.sdk_env_overrides)
            hook_state.fork_task_launcher = self._make_fork_task_launcher(parent.route)
            prompt = str(args.get("prompt") or "")
            payload: dict[str, Any] = {
                "display_name": str(args["display_name"]),
                "prompt": f"[external trigger: {caller}]\n{prompt}".rstrip(),
                "fork": fork,
                "allow_cold_wake": allow_cold_wake,
            }
            for key in ("prompt_file", "model", "effort", "hooks", "session_source"):
                if args.get(key):
                    payload[key] = args[key]
            tools = self._control_tools(hook_state=hook_state, session_id=parent.session_id)
            return tool_result_to_control(await tools["AgentTask"](payload))
        if op == "new_tree":
            return await self._control_new_tree(caller=caller, args=args)
        return {"ok": False, "error": f"unsupported op {op}"}

    async def _control_stop_child(self, args: dict[str, Any]) -> dict[str, Any]:
        """Stop one pinned child generation without waking a model; retain cleanup evidence."""
        from obs_agent.control import control_dir, tool_result_to_control

        parent = self._control_agent_state(str(args["parent_team"]).strip(), str(args["parent_agent"]).strip())
        if parent is None:
            return {"ok": False, "error": "parent agent has no current route binding"}
        task_id = str(args["expected_task_id"])
        raw_generation = args["expected_launch_parent_message_id"]
        # obs-54: runs whose parent notice never reached Telegram get a negative
        # synthetic generation (_run_generation). Records written before that, or
        # by other paths, may still hold None; obs-agentctl and the rounds watchdog
        # spell it "None". It matches only a record whose generation is None.
        generation = (
            None if raw_generation is None or str(raw_generation).strip() in ("None", "null")
            else int(raw_generation)
        )
        key = hashlib.sha256(json.dumps([args["parent_team"], args["parent_agent"], task_id, generation]).encode()).hexdigest()
        locks = self.__dict__.setdefault("_control_stop_locks", {})
        async with locks.setdefault(key, asyncio.Lock()):
            record = self._resolve_task_lookup(route=parent.route, task_id=task_id, team_name=None, agent_name=None)
            if (record is None or record.parent_route != parent.route
                    or record.team_name != args["team_name"] or record.agent_name != args["agent_name"]):
                return {"ok": False, "error": "stop target does not match the recorded direct child of this parent"}
            # Owed maintenance wakes keep the original PARENT launch binding even while
            # their session/child-message/callback flags change. Explicit resume replaces
            # that binding; unrelated inbox turns reparent the record to its own route.
            if record.launch_parent_message_id != generation:
                return {"ok": False, "error": "stop generation mismatch; the old timer does not own this turn"}
            child = self._get_state(record.child_route, create=False)
            def capture_current():
                client = child.session_manager._client if child is not None else None
                pid = getattr(getattr(client, "_transport", None), "_process", None)
                pid = getattr(pid, "pid", None)
                error = None
                try:
                    owned = _maint.capture_process_tree(pid) if _is_killable_cli_pid(pid) else {}
                except (OSError, ValueError) as exc:
                    owned, error = {}, type(exc).__name__
                active = child is not None and bool(child.busy or child.hook_state.execution_active)
                return {"root_pid": pid, "owned": owned, "capture_error": error,
                        "capture_known": error is None and (bool(owned) or
                            (child is not None and not active and record.terminal_request != "stopped"))}

            path = control_dir() / f"stop-{key}.json"
            try:
                receipt = json.loads(path.read_text())
            except FileNotFoundError:
                receipt = {"task_id": task_id, "launch_parent_message_id": generation,
                           **capture_current(), "intent_at": time.time(), "stop_requested_at": None}

            def persist():
                path.parent.mkdir(parents=True, exist_ok=True)
                tmp = path.with_suffix(".tmp")
                tmp.write_text(json.dumps(receipt))
                tmp.replace(path)

            # A crash between intent and callback is retried; a confirmed native stop is not
            # repeated (relatching it would restart the existing escalation grace).
            persist()
            if not args.get("observe_only"):
                latch = child.hook_state.stop_latched_at if child is not None else None
                if record.terminal_request != "stopped" and latch is None:
                    callbacks = self.__dict__.setdefault("_control_stop_callbacks", {})
                    callback = callbacks.get(key)
                    if callback is None:
                        async def stop_current_generation():
                            current = self._resolve_task_lookup(route=parent.route, task_id=task_id, team_name=None, agent_name=None)
                            if (current is not record or current.parent_route != parent.route
                                    or current.launch_parent_message_id != generation
                                    or current.team_name != args["team_name"] or current.agent_name != args["agent_name"]):
                                return self._task_lookup_error_result("stop generation changed before native dispatch")
                            # No yield between generation validation, latest ownership capture,
                            # durable merge and the native callback's latch. A pre-stop intent
                            # may have survived maintenance onto another CLI of this SAME item.
                            fresh = capture_current()
                            history = receipt.setdefault("ownership_snapshots", [{
                                "at": receipt["intent_at"], "root_pid": receipt["root_pid"],
                                "owned": dict(receipt["owned"]), "capture_known": receipt["capture_known"],
                                "capture_error": receipt.get("capture_error")}])
                            history.append({"at": time.time(), **fresh})
                            merged = {int(pid): int(start) for pid, start in receipt["owned"].items()}
                            for pid, start in fresh["owned"].items():
                                if pid in merged and merged[pid] != start:
                                    receipt.setdefault("retired_owned_identities", []).append([pid, merged[pid]])
                                merged[pid] = start
                            receipt["owned"] = merged
                            receipt["root_pid"] = fresh["root_pid"]
                            receipt["capture_known"] = receipt["capture_known"] and fresh["capture_known"]
                            receipt["capture_error"] = receipt.get("capture_error") or fresh["capture_error"]
                            receipt["dispatch_at"] = time.time()
                            persist()
                            return await self._make_fork_task_stopper(parent.route)({"task_id": task_id})
                        callback = asyncio.create_task(stop_current_generation())
                        callbacks[key] = callback
                    # The native callback latches before its first interrupt await. Preserve
                    # that callback if a slow CLI cannot acknowledge promptly; don't let IPC
                    # monopolize the deterministic watchdog or restart the escalation grace.
                    try:
                        result = tool_result_to_control(await asyncio.wait_for(asyncio.shield(callback), 1.0))
                    except TimeoutError:
                        result = {"ok": True, "pending": True}
                    if not result["ok"]:
                        return result
                    latch = child.hook_state.stop_latched_at if child is not None else None
                if receipt["stop_requested_at"] is None:
                    receipt["stop_requested_at"] = latch or receipt.get("dispatch_at") or receipt["intent_at"]
                    receipt["request_timestamp_basis"] = "native_latch" if latch else "dispatch_or_intent_lower_bound_native_time_unknown"
                    receipt["acknowledged_at"] = time.time()
                    persist()
            active = child is not None and bool(child.busy or child.hook_state.execution_active)
            survivors = [int(pid) for pid, start in receipt["owned"].items()
                         if (active or int(pid) != receipt["root_pid"])
                         and _maint.process_identity_matches(int(pid), int(start))]
            cleanup = receipt["capture_known"] and not active and not survivors and record.status in {"stopped", "failed", "completed"}
            receipt.update(cleanup_complete=cleanup, observed_at=time.time(), survivors=survivors, route_active=active,
                           native_status=record.status, native_completed_at=record.completed_at)
            persist()
            return {"ok": True, "text": "stopped and cleanup observed" if cleanup else "stop requested; cleanup pending",
                    "result": receipt}

    async def _control_new_tree(self, *, caller: str, args: dict[str, Any]) -> dict[str, Any]:
        prompt_file = str(args.get("prompt_file") or "").strip() or None
        prompt_file_content: str | None = None
        if prompt_file:
            try:
                prompt_file_content = self._read_vault_prompt_file(prompt_file)
            except Exception as exc:
                return {"ok": False, "error": f"cannot read prompt_file: {exc}"}
        hooks = args.get("hooks")
        if isinstance(hooks, str) and hooks.strip():
            try:
                hooks = json.loads(hooks)
            except json.JSONDecodeError as exc:
                return {"ok": False, "error": f"hooks must be a JSON object: {exc}"}
        env = args.get("env")
        if isinstance(env, str) and env.strip():
            try:
                env = json.loads(env)
            except json.JSONDecodeError as exc:
                return {"ok": False, "error": f"env must be a JSON object: {exc}"}
        chat = args.get("chat")
        if chat is None:
            chat = args.get("chat_id")
        origin: dict[str, Any] = {"kind": "external", "caller": caller}
        trigger = f"external trigger: {caller}"
        # An agent launching through a fork names itself so the tree can report back (ops-61).
        origin_team = str(args.get("origin_team") or "").strip() or None
        origin_agent = str(args.get("origin_agent") or "").strip() or None
        if origin_team and origin_agent:
            origin.update(kind="agent", origin_team=origin_team, origin_agent=origin_agent)
            trigger = (
                f"new tree launched by {origin_agent} (team {origin_team}); report completion to it "
                f"with SendInboxMessage team_name={origin_team}"
            )
        return await self._create_new_tree(
            trigger_label=trigger,
            notice_text=f"new tree started by {origin_agent or 'external:' + caller}",
            chat=chat,
            title=str(args["title"]),
            prompt=str(args.get("prompt") or ""),
            prompt_file=prompt_file,
            prompt_file_content=prompt_file_content,
            hooks=hooks or None,
            model=str(args.get("model") or "").strip() or None,
            effort=str(args.get("effort") or "").strip() or None,
            env=env or None,
            origin=origin,
        )

    def _read_vault_prompt_file(self, prompt_file: str) -> str:
        file_path = Path(prompt_file)
        if prompt_file.startswith("~"):
            file_path = file_path.expanduser()
        elif not file_path.is_absolute():
            file_path = self._config.vault_path / file_path
        return file_path.read_text(encoding="utf-8").strip()

    def _known_forum_chat_ids(self) -> set[int]:
        return {route.chat_id for route in self._states_by_route if route.thread_id is not None}

    def _record_tree_origin(self, *, team_name: str | None, origin: dict[str, Any]) -> None:
        """Remember who launched a new root tree, beside its team config (ops-61 provenance).

        The launcher is not the tree's lineage parent: report-back and attribution read this
        record instead. Best effort: a write failure never fails the launch.
        """
        normalized = (team_name or "").strip()
        if not normalized:
            return
        try:
            team_dir = Path.home() / ".claude" / "teams" / normalized
            team_dir.mkdir(parents=True, exist_ok=True)
            record = {**origin, "recorded_at": datetime.now(timezone.utc).isoformat()}
            (team_dir / "origin.json").write_text(json.dumps(record, ensure_ascii=True, indent=2), encoding="utf-8")
        except Exception:
            logger.warning("Failed recording tree origin team=%s", normalized, exc_info=True)

    # CACHE-PREFIX NOTE: a new tree is a fresh root session (no copied history), so nothing is
    # shared with the launcher's cache. The launch only sets the root's model/effort/env/hooks
    # before its first turn, as a fresh AgentTask child does.
    async def _create_new_tree(
        self,
        *,
        trigger_label: str,
        notice_text: str,
        chat: Any,
        title: str,
        prompt: str,
        prompt_file: str | None = None,
        prompt_file_content: str | None = None,
        hooks: dict[str, str] | None = None,
        model: str | None = None,
        effort: str | None = None,
        env: dict[str, str] | None = None,
        origin: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new root tree as a new topic in an EXISTING group chat (vault-h667, ops-61).

        Never creates a chat. Returns chat_id, thread_id, link and the new root's
        root_team_key/agent_name (ops-1.11.6).
        """
        from obs_agent import chat_registry

        bot = self._primary_bot
        if bot is None:
            return {"ok": False, "error": "bot is not connected yet"}
        resolution = chat_registry.resolve_chat(
            chat,
            known_chat_ids=self._known_forum_chat_ids(),
            entries=chat_registry.load_registry(chat_registry.registry_path(self._config.vault_path)),
        )
        if resolution.chat_id is None:
            return {"ok": False, "error": resolution.error or "no chat resolved"}
        chat_id = resolution.chat_id
        title = title.strip()[:120]
        if not title:
            return {"ok": False, "error": "title is required"}
        if not prompt.strip() and not prompt_file_content:
            return {"ok": False, "error": "prompt or prompt_file is required"}
        if hooks is not None:
            if not isinstance(hooks, dict) or not all(
                isinstance(spec, str) and "::" in spec for spec in hooks.values()
            ):
                return {"ok": False, "error": "hooks must map event names to 'file_path::function_name'"}
            from obs_agent.tools import _resolve_hook_spec_path

            try:
                # obs-54: validation runs Git subprocesses; keep them off the event loop.
                hooks = {
                    str(event): await asyncio.to_thread(_resolve_hook_spec_path, spec, self._config.vault_path)
                    for event, spec in hooks.items()
                }
            except ValueError as exc:
                return {"ok": False, "error": str(exc)}
        if env is not None and not isinstance(env, dict):
            return {"ok": False, "error": "env must be a JSON object"}
        resolved_model: str | None = None
        if model and model.lower() not in ("inherit", "source"):
            resolved_model = resolve_model(model)
            from obs_agent.spark import check_spark_available, is_spark_model

            if is_spark_model(resolved_model):
                try:
                    await asyncio.to_thread(
                        check_spark_available, resolved_model, parse_context_suffix(resolved_model)[1]
                    )
                except Exception as exc:
                    return {"ok": False, "error": str(exc)}
        selected_effort: str | None = None
        if effort and effort.lower() != "inherit":
            from obs_agent.effort import normalize_effort

            try:
                selected_effort = normalize_effort(effort)
            except ValueError as exc:
                return {"ok": False, "error": str(exc)}
        topic = await self._enqueue_create_topic(
            route=TelegramRoute(chat_id=int(chat_id), thread_id=None),
            topic_name=title,
            fallback_bot=bot,
            priority=_PRIORITY_SYSTEM,
        )
        thread_id = getattr(topic, "message_thread_id", None)
        if not isinstance(thread_id, int):
            return {"ok": False, "error": "create_forum_topic returned no message_thread_id"}
        route = TelegramRoute(chat_id=int(chat_id), thread_id=thread_id)
        # Explicit hooks replace the default new-chat hooks; none given keeps the defaults.
        state = self._get_state(route, topic_title=title, apply_default_new_chat_hooks=hooks is None)
        assert state is not None
        state.last_bot = bot
        self._set_topic_metadata(route=route, title=title, icon_custom_emoji_id=None)
        if hooks is not None:
            state.session_manager.user_hooks = hooks
        if resolved_model:
            state.session_manager.model_override = resolved_model
        if selected_effort:
            state.session_manager.effort_override = selected_effort
        bootstrap_xml = self._prime_obs_bootstrap(state, lineage=(title,), origin="new_trunk", is_fork=False)
        if env:
            extra_env = {str(k): str(v) for k, v in env.items()}
            state.session_manager.set_sdk_env_overrides({**state.session_manager.sdk_env_overrides, **extra_env})
            state.session_manager.explicit_env_overrides = extra_env
        root_team_key: str | None = None
        root_agent_name: str | None = None
        try:
            bootstrap = parse_obs_bootstrap_xml(bootstrap_xml)
            root_team_key = bootstrap.root_team_key
            root_agent_name = bootstrap.agent_name
        except Exception:
            logger.debug("new tree bootstrap parse failed route=%s", route, exc_info=True)
        if origin:
            self._record_tree_origin(team_name=root_team_key, origin=origin)
        self._persist_state_for_route(route)
        body = self._compose_prompt_file_context(
            prompt=prompt.strip(), prompt_file=prompt_file, prompt_file_content=prompt_file_content,
        )
        text = f"[{trigger_label}]\n{body}"
        notice = await self._send_system_message(
            route=route, bot=bot, text=notice_text, disable_notification=True,
        )
        notice_id = self._sent_message_id(notice) if notice is not None else None
        task = asyncio.create_task(self._run_and_send(
            state=state, user_text=text, bot=bot,
            trigger_message=QueuedMessage(text=text, telegram_message_id=notice_id),
        ))
        self._detached_wake_tasks.add(task)
        task.add_done_callback(self._on_detached_wake_done)
        link = self._build_message_link(route, thread_id)
        chat_name = resolution.entry.name if resolution.entry is not None else None
        return {
            "ok": True,
            "text": (
                f"new tree '{title}' started in chat {chat_name or chat_id}: {link or thread_id}"
                f" (root_team_key={root_team_key}, agent_name={root_agent_name})"
            ),
            "result": {
                "chat_id": int(chat_id),
                "chat_name": chat_name,
                "thread_id": thread_id,
                "link": link,
                "root_team_key": root_team_key,
                "team_name": root_team_key,
                "agent_name": root_agent_name,
            },
        }

    async def _idle_evict_loop(self, interval: float = 60.0) -> None:
        """Periodic idle-CLI sweep so eviction does not wait for a fork completion."""
        while True:
            await asyncio.sleep(interval)
            try:
                await self._prune_idle_claude_processes()
            except Exception:
                logger.warning("Claude idle process eviction sweep failed", exc_info=True)

    async def _cli_hang_watchdog_loop(self, interval: float = 60.0) -> None:
        while True:
            await asyncio.sleep(interval)
            try:
                await self._cli_hang_sweep()
            except Exception:
                logger.warning("[cli_hang_watchdog] sweep failed", exc_info=True)

    async def _cli_hang_sweep(self, *, now: float | None = None, read_cpu=None) -> int:
        """Kill a running turn's Claude CLI that spins without making progress.

        Seen 2026-10-12/13: a CLI stopped emitting output mid-turn while burning
        a full core (21 h on topic 83366, holding the route busy so every later
        message queued forever). A CLI that waits on the API, a tool subprocess
        or a hook uses almost no CPU itself, so "own CPU >= 80% of a core and the
        session JSONL unchanged for the whole window" only matches a hang.

        The kill goes through the normal CLI-exit path: the runner reconnects
        with ``resume`` and asks the model to continue. A second hang of the
        same route within 3 h ends the turn instead and says so in the topic.
        Long no-output stretches are also logged as ``[cli_stall]`` (no action)
        so stalls that are not CPU spins are visible next time.
        """
        threshold = _cli_hang_watchdog_seconds()
        if threshold <= 0:
            return 0
        now = time.time() if now is None else now
        read_cpu = read_cpu or _read_proc_cpu_seconds
        live: set[tuple[TelegramRoute, int]] = set()
        killed = 0
        for route, state in list(self._states_by_route.items()):
            if not (state.busy or state.hook_state.execution_active):
                continue
            client = state.session_manager._client
            process = getattr(getattr(client, "_transport", None), "_process", None)
            pid = getattr(process, "pid", None)
            if not _is_killable_cli_pid(pid) or getattr(process, "returncode", None) is not None:
                continue
            cpu = read_cpu(pid)
            if cpu is None:
                continue
            key = (route, pid)
            live.add(key)
            mtime = self._session_jsonl_mtime(state.session_id)
            sample = self._cli_hang_samples.get(key)
            if sample is None or sample.get("mtime") != mtime:
                self._cli_hang_samples[key] = {"since": now, "cpu0": cpu, "mtime": mtime, "last_log": now}
                continue
            stalled = now - float(sample["since"] or now)
            busy = (cpu - float(sample["cpu0"] or 0.0)) / max(stalled, 1.0)
            if stalled >= 600 and now - float(sample["last_log"] or now) >= 600:
                sample["last_log"] = now
                logger.warning(
                    "[cli_stall] route=%s session_id=%s pid=%s no JSONL progress for %.0fs cpu=%.0f%%",
                    route, state.session_id, pid, stalled, busy * 100,
                )
            if stalled >= threshold and busy >= 0.8:
                self._cli_hang_samples.pop(key, None)
                await self._kill_hung_cli(state, pid=pid, stalled=stalled, busy=busy, now=now)
                killed += 1
        for key in list(self._cli_hang_samples):
            if key not in live:
                self._cli_hang_samples.pop(key, None)
        return killed

    def _session_jsonl_mtime(self, session_id: str | None) -> float | None:
        if not session_id:
            return None
        try:
            path = find_session_jsonl(session_id=session_id, cwd=self._config.vault_path)
            return path.stat().st_mtime if path is not None else None
        except OSError:
            return None

    async def _kill_hung_cli(
        self, state: TelegramSessionState, *, pid: int, stalled: float, busy: float, now: float,
    ) -> None:
        recent = [t for t in self._cli_hang_kills.get(state.route, []) if now - t < 3 * 3600]
        recent.append(now)
        self._cli_hang_kills[state.route] = recent
        give_up = len(recent) >= 2
        logger.warning(
            "[cli_hang_watchdog] killing hung Claude CLI route=%s session_id=%s pid=%s "
            "no_progress=%.0fs cpu=%.0f%% action=%s",
            state.route, state.session_id, pid, stalled, busy * 100,
            "end_turn" if give_up else "resume",
        )
        if give_up:
            # Same effect as /stop: the CLI exit ends the turn, no auto-resume.
            state.hook_state.stop_requested_at = time.time()
        try:
            await asyncio.to_thread(_maint.kill_process_tree, pid)
        except Exception:
            logger.warning("[cli_hang_watchdog] process-tree kill failed pid=%s", pid, exc_info=True)
        session_mgr = state.session_manager
        try:
            await asyncio.wait_for(session_mgr.disconnect_idle_client(direct_kill=True), timeout=10.0)
        except Exception:
            logger.warning("[cli_hang_watchdog] locked kill failed; killing without the session lock", exc_info=True)
            try:
                await session_mgr._direct_kill_client_process_unlocked()
            except Exception:
                logger.warning("[cli_hang_watchdog] direct kill failed route=%s", state.route, exc_info=True)
        bot = state.last_bot or self._primary_bot
        if bot is None:
            return
        minutes = int(stalled // 60)
        text = (
            f"The Claude CLI for this topic hung again (no progress for {minutes} min at full CPU) "
            "and was stopped. Send a message to continue; use /clear if it keeps hanging."
            if give_up
            else f"The Claude CLI for this topic hung (no progress for {minutes} min at full CPU); "
            "restarted it and resumed the turn."
        )
        try:
            await self._send_system_message(
                route=state.route, bot=bot, text=text, disable_notification=True, max_attempts=1,
            )
        except Exception:
            logger.debug("[cli_hang_watchdog] notice failed route=%s", state.route, exc_info=True)

    async def shutdown(self) -> None:
        """Stop background tasks owned by this adapter."""
        for task in [self._crash_snapshot_task, self._idle_evict_task, self._cli_hang_task, *self._stop_escalation_tasks]:
            if task is not None and not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
        if self._background_task is not None and not self._background_task.done():
            self._background_task.cancel()
            try:
                await self._background_task
            except asyncio.CancelledError:
                pass
        if self._schedule_poller_task is not None and not self._schedule_poller_task.done():
            self._schedule_poller_task.cancel()
            try:
                await self._schedule_poller_task
            except asyncio.CancelledError:
                pass
        if self._transport_worker_task is not None and not self._transport_worker_task.done():
            self._transport_worker_task.cancel()
            try:
                await self._transport_worker_task
            except asyncio.CancelledError:
                pass
        for task in list(self._typing_tasks.values()):
            if not task.done():
                task.cancel()
        for task in list(self._typing_tasks.values()):
            try:
                await task
            except asyncio.CancelledError:
                pass
        for task in list(self._observability_flush_tasks.values()):
            if not task.done():
                task.cancel()
        for task in list(self._observability_flush_tasks.values()):
            try:
                await task
            except asyncio.CancelledError:
                pass
        for task in list(self._detached_wake_tasks):
            if not task.done():
                task.cancel()
        for task in list(self._detached_wake_tasks):
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        for task in list(self._fork_task_tasks.values()):
            if not task.done():
                task.cancel()
        for task in list(self._fork_task_tasks.values()):
            try:
                await task
            except asyncio.CancelledError:
                pass
        for task in list(self._schedule_execution_tasks.values()):
            if not task.done():
                task.cancel()
        for task in list(self._schedule_execution_tasks.values()):
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._schedule_execution_tasks.clear()
        self._state_store.close()

    async def _send_plain_with_retry(
        self,
        *,
        route: TelegramRoute,
        bot,
        text: str,
        disable_notification: bool,
        parse_mode: ParseMode | None = None,
        reply_to_message_id: int | None = None,
        priority: int = _PRIORITY_ASSISTANT,
        max_attempts: int | None = None,
    ):
        """Enqueue one Telegram message for paced prioritized transport delivery."""
        return await self._enqueue_send(
            route=route,
            text=text,
            disable_notification=disable_notification,
            parse_mode=parse_mode,
            reply_to_message_id=reply_to_message_id,
            fallback_bot=bot,
            priority=priority,
            max_attempts=max_attempts,
        )

    def _format_system_html(self, text: str) -> str:
        return f"<u><i>{html.escape(text)}</i></u>"

    def _wrap_system_html(self, html_text: str, *, underline: bool = True) -> str:
        if underline:
            return f"<u><i>{html_text}</i></u>"
        return f"<i>{html_text}</i>"

    def _underline_first_nonempty_line_html(self, html_text: str) -> str:
        lines = html_text.splitlines()
        for idx, line in enumerate(lines):
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("<u>") and stripped.endswith("</u>"):
                break
            lines[idx] = f"<u>{stripped}</u>"
            break
        return "\n".join(lines)

    def _format_status_html(self, text: str) -> str:
        return f"<i>{html.escape(text)}</i>"

    def _remember_system_message_id(self, *, route: TelegramRoute, message_id: int | None) -> None:
        if isinstance(message_id, int):
            key = (route.chat_id, message_id)
            self._system_message_ids.add(key)
            self._system_message_routes[key] = route
            self._state_store.upsert_system_message(
                chat_id=route.chat_id,
                message_id=message_id,
                route_chat_id=route.chat_id,
                route_thread_id=route.thread_id,
            )

    def _remember_system_message_ids(self, *, route: TelegramRoute, sent_messages: list) -> None:
        for sent in sent_messages:
            self._remember_system_message_id(
                route=route,
                message_id=self._sent_message_id(sent),
            )

    def _is_system_message_id(self, *, chat_id: int, message_id: int) -> bool:
        return (chat_id, message_id) in self._system_message_ids

    async def _send_system_message(
        self,
        *,
        route: TelegramRoute,
        bot,
        text: str,
        disable_notification: bool,
        reply_to_message_id: int | None = None,
        priority: int = _PRIORITY_SYSTEM,
        max_attempts: int | None = None,
    ):
        sent = await self._send_plain_with_retry(
            route=route,
            bot=bot,
            text=self._format_system_html(text),
            parse_mode=ParseMode.HTML,
            disable_notification=disable_notification,
            reply_to_message_id=reply_to_message_id,
            priority=priority,
            max_attempts=max_attempts,
        )
        self._remember_system_message_id(
            route=route,
            message_id=self._sent_message_id(sent),
        )
        return sent

    async def _send_system_html_message(
        self,
        *,
        route: TelegramRoute,
        bot,
        html_text: str,
        disable_notification: bool,
        reply_to_message_id: int | None = None,
        priority: int = _PRIORITY_SYSTEM,
        underline: bool = True,
        max_attempts: int | None = None,
    ) -> list:
        sent_messages = await self._send_html(
            route=route,
            bot=bot,
            html_text=self._wrap_system_html(html_text, underline=underline),
            disable_notification=disable_notification,
            reply_to_message_id=reply_to_message_id,
            priority=priority,
            max_attempts=max_attempts,
        )
        self._remember_system_message_ids(route=route, sent_messages=sent_messages)
        return sent_messages

    async def _send_task_launch_notice(
        self,
        *,
        route: TelegramRoute,
        bot,
        html_text: str,
        underline: bool = True,
        purpose: str,
    ) -> list:
        """A launch or resume notice; the launch goes on without it if Telegram keeps failing.

        obs-54: on 2026-10-25 AgentTask launches aborted after the child topic
        was created, because the child's first service message timed out three
        times while the event loop stalled; that left empty topics and NoTask
        handles. The notice is retried with the transport's backoff
        (2, 4, 8, 16, 30 s), and a timeout, network error or flood wait after
        the last attempt returns no messages instead of failing the launch.
        Other errors (deleted topic, bad request) still raise.
        """
        try:
            return await self._send_system_html_message(
                route=route,
                bot=bot,
                html_text=html_text,
                disable_notification=True,
                underline=underline,
                max_attempts=_TASK_LAUNCH_SEND_MAX_ATTEMPTS,
            )
        except (TimedOut, NetworkError, RetryAfter) as exc:
            if isinstance(exc, BadRequest):
                raise
            logger.warning(
                "[launch_notice] %s not sent route=%s after %d attempts (%s: %s); continuing without it",
                purpose,
                route,
                _TASK_LAUNCH_SEND_MAX_ATTEMPTS,
                type(exc).__name__,
                exc,
            )
            return []

    def _active_schedules_for_route(self, route: TelegramRoute) -> list[_TopicScheduleRecord]:
        schedule_ids = self._schedule_ids_by_route.get(route, set())
        records = [
            self._topic_schedules_by_id[schedule_id]
            for schedule_id in schedule_ids
            if schedule_id in self._topic_schedules_by_id
        ]
        now = time.time()
        active: list[_TopicScheduleRecord] = []
        for record in records:
            if not record.enabled:
                continue
            if self._schedule_is_exhausted(record, now):
                record.enabled = False
                record.next_run_at = None
                self._register_topic_schedule(record)
                continue
            active.append(record)
        return active

    def _format_duration_human(self, seconds: float | int) -> str:
        total = max(int(seconds), 0)
        if total == 0:
            return "0s"
        days, rem = divmod(total, 86400)
        hours, rem = divmod(rem, 3600)
        minutes, secs = divmod(rem, 60)
        parts: list[str] = []
        if days:
            parts.append(f"{days}d")
        if hours:
            parts.append(f"{hours}h")
        if minutes:
            parts.append(f"{minutes}m")
        if secs and not parts:
            parts.append(f"{secs}s")
        return " ".join(parts[:2])

    def _schedule_display_name(self, record: _TopicScheduleRecord) -> str:
        if record.description:
            return record.description
        return record.schedule_id

    def _schedule_trigger_label(self, record: _TopicScheduleRecord) -> str:
        if record.trigger_kind == "on_topic_stop":
            return "on stop"
        if record.schedule_mode == "cron" and record.cron_expr:
            return f"cron {record.cron_expr}"
        if record.interval_seconds is not None:
            return f"every {self._format_duration_human(record.interval_seconds)}"
        return "interval"

    def _schedule_uses_second_precision(self, record: _TopicScheduleRecord) -> bool:
        if record.trigger_kind == "interval" and record.interval_seconds is not None:
            return record.interval_seconds < 60
        return False

    def _schedule_iso_timestamp(self, ts: float | None) -> str | None:
        if ts is None:
            return None
        return datetime.fromtimestamp(ts, timezone.utc).astimezone(
            self._user_timezone
        ).isoformat()

    def _format_schedule_timestamp(
        self,
        *,
        ts: float,
        record: _TopicScheduleRecord,
        now_ts: float | None = None,
    ) -> str:
        include_seconds = self._schedule_uses_second_precision(record)
        now_utc = datetime.fromtimestamp(now_ts if now_ts is not None else time.time(), timezone.utc)
        value_utc = datetime.fromtimestamp(ts, timezone.utc)
        now_dt = now_utc.astimezone(self._user_timezone)
        value_dt = value_utc.astimezone(self._user_timezone)
        tz_label = value_dt.tzname() or value_dt.strftime("%z") or "local"
        time_fmt = "%H:%M:%S" if include_seconds else "%H:%M"
        if value_dt.date() == now_dt.date():
            return f"today at {value_dt.strftime(time_fmt)} {tz_label}"
        if value_dt.date() == (now_dt + timedelta(days=1)).date():
            return f"tomorrow at {value_dt.strftime(time_fmt)} {tz_label}"
        full_fmt = "%Y-%m-%d %H:%M:%S" if include_seconds else "%Y-%m-%d %H:%M"
        return f"{value_dt.strftime(full_fmt)} {tz_label}"

    def _schedule_details(
        self,
        record: _TopicScheduleRecord,
        *,
        now_ts: float,
        remaining_offset: int = 0,
    ) -> list[str]:
        details: list[str] = [self._schedule_trigger_label(record)]
        if record.max_retry_attempts > 0:
            details.append(
                f"retries={record.retry_attempt_count}/{record.max_retry_attempts}"
            )
        if record.max_runs is not None:
            remaining = max(record.max_runs - record.run_count - remaining_offset, 0)
            details.append(f"remaining={remaining}")
        if record.from_ts is not None:
            details.append(
                "from="
                + self._format_schedule_timestamp(
                    ts=record.from_ts,
                    record=record,
                    now_ts=now_ts,
                )
            )
        if record.until_ts is not None:
            details.append(
                "until="
                + self._format_schedule_timestamp(
                    ts=record.until_ts,
                    record=record,
                    now_ts=now_ts,
                )
            )
        return details

    def _schedule_trigger_line(
        self,
        record: _TopicScheduleRecord,
        *,
        now_ts: float,
    ) -> str:
        details = self._schedule_details(
            record,
            now_ts=now_ts,
            remaining_offset=1,
        )
        if details:
            return (
                f"schedule_triggered: {self._schedule_display_name(record)} "
                f"({' ; '.join(details)})"
            )
        return f"schedule_triggered: {self._schedule_display_name(record)}"

    def _next_schedule_line(self, route: TelegramRoute) -> str | None:
        now = time.time()
        timed_records = [
            record
            for record in self._active_schedules_for_route(route)
            if record.next_run_at is not None
        ]
        record: _TopicScheduleRecord | None = None
        if timed_records:
            record = min(timed_records, key=lambda item: float(item.next_run_at or now))
        else:
            stop_records = [
                candidate
                for candidate in self._active_schedules_for_route(route)
                if candidate.trigger_kind == "on_topic_stop"
            ]
            if stop_records:
                record = stop_records[0]
        if record is None:
            return None

        if record.next_run_at is not None:
            run_at_text = self._format_schedule_timestamp(
                ts=record.next_run_at,
                record=record,
                now_ts=now,
            )
            pieces = [f"next_schedule: {self._schedule_display_name(record)} at {run_at_text}"]
        else:
            pieces = [f"next_schedule: {self._schedule_display_name(record)} on next stop"]
        details = self._schedule_details(record, now_ts=now)
        if details:
            pieces.append(f"({' ; '.join(details)})")
        return " ".join(pieces)

    @staticmethod
    def _context_window_tokens_for_state(state: TelegramSessionState, fallback_tokens: int) -> int:
        return session_context_window(state.session_manager, fallback_tokens)

    def _build_completion_summary(
        self,
        state: TelegramSessionState,
        *,
        subtask_status: str | None = None,
        return_to_parent_link: str | None = None,
        triggered_schedule_id: str | None = None,
        interrupt_discarded_count: int | None = None,
    ) -> str:
        snapshot = build_context_snapshot(
            session_id=state.session_id,
            data=state.hook_state.last_result_data,
            context_window_estimate_tokens=self._context_window_tokens_for_state(
                state,
                self._config.context_window_estimate_tokens,
            ),
            cwd=self._config.vault_path,
        )
        lines: list[str] = []
        if interrupt_discarded_count is not None:
            if interrupt_discarded_count > 0:
                lines.append(
                    f"interrupted; {interrupt_discarded_count} queued messages discarded"
                )
            else:
                lines.append("interrupted")
        lines.append(format_context_snapshot_compact(snapshot))
        if subtask_status:
            lines.append(f"subtask: {subtask_status}")
        if return_to_parent_link:
            lines.append(f"return_to_parent: {return_to_parent_link}")
        next_schedule = self._next_schedule_line(state.route)
        if next_schedule:
            lines.append(next_schedule)
        return "\n".join(lines)

    def _has_queue_idle_state(self, state: TelegramSessionState) -> bool:
        return not state.pending_messages and state.hook_state.message_queue.empty()

    def _bot_for_state(self, state: TelegramSessionState) -> Any | None:
        return state.last_bot or self._primary_bot

    async def _activate_route_session(
        self,
        state: TelegramSessionState,
        session_id: str | None,
    ) -> None:
        current_id = state.session_id
        if current_id == session_id:
            return

        old_manager = state.session_manager
        state.session_manager = SessionManager(config=self._config, hook_state=state.hook_state)
        # The route's launch configuration belongs to the route, not to one
        # session id: carry it across session switches so a reply-to-older-
        # message switch does not silently drop model, hooks, or env.
        state.session_manager.model_override = old_manager.model_override
        state.session_manager.effort_override = old_manager.effort_override
        state.session_manager.user_hooks = old_manager.user_hooks
        state.session_manager.explicit_env_overrides = old_manager.explicit_env_overrides
        state.session_manager.set_sdk_env_overrides(dict(old_manager.sdk_env_overrides))
        if session_id:
            state.session_manager.set_session_id(session_id)
            self._route_by_session_id[session_id] = state.route

        if current_id:
            self._route_by_session_id.pop(current_id, None)
        await old_manager.disconnect()
        self._upsert_route_inbox_target(state)
        self._persist_state_for_route(state.route)

    async def _reset_route_state(self, state: TelegramSessionState) -> None:
        logger.info(
            "[route_reset] route=%s old_session_id=%s model_override=%s effort_override=%s pending=%d",
            state.route,
            state.session_id,
            state.session_manager.model_override,
            state.session_manager.effort_override,
            len(state.pending_messages),
        )
        self._last_inbound_message_id_by_route.pop(state.route, None)
        self._pending_inbound_message_ids_by_route.pop(state.route, None)
        self._unbind_route_sessions(state.route)
        await state.session_manager.async_reset()
        state.pending_messages.clear()
        state.hook_state.reset()
        state.warning_sent = False
        self._prune_bindings_for_route(state.route)
        self._upsert_route_inbox_target(state)
        self._persist_state_for_route(state.route)

    async def _maybe_send_route_warning(self, state: TelegramSessionState) -> None:
        _ = state

    async def _send_received_marker(
        self,
        *,
        route: TelegramRoute,
        bot,
        reply_to_message_id: int | None,
    ) -> list[int]:
        receipt_message = await self._send_system_message(
            route=route,
            bot=bot,
            text="received",
            disable_notification=True,
            reply_to_message_id=reply_to_message_id,
            max_attempts=1,
        )
        receipt_message_id = self._sent_message_id(receipt_message)
        if receipt_message_id is None:
            return []
        return [receipt_message_id]

    def _record_message_binding(
        self,
        *,
        route: TelegramRoute,
        message_id: int,
        jsonl_uuid: str,
        session_id: str,
        role: str,
    ) -> None:
        self._message_map[(route.chat_id, message_id)] = _TelegramMessageBinding(
            jsonl_uuid=jsonl_uuid,
            session_id=session_id,
            role=role,
            route=route,
        )
        self._state_store.upsert_message_binding(
            chat_id=route.chat_id,
            message_id=message_id,
            session_id=session_id,
            jsonl_uuid=jsonl_uuid,
            role=role,
            route_chat_id=route.chat_id,
            route_thread_id=route.thread_id,
        )
        logger.info(
            "[message_map] route=%s telegram_msg_id=%d session_id=%s role=%s uuid=%s",
            route,
            message_id,
            session_id,
            role,
            jsonl_uuid,
        )

    def _sent_message_id(self, message) -> int | None:
        candidate = getattr(message, "message_id", None)
        if isinstance(candidate, int):
            return candidate
        candidate = getattr(message, "id", None)
        if isinstance(candidate, int):
            return candidate
        return None

    def _run_generation(self, parent_message_id: int | None) -> int:
        """The run generation of a launch, resume or wake: its parent message id.

        obs-54: a run whose parent notice never reached Telegram still needs a
        distinct, durable generation, or a stale control-stop timer for one run
        could stop the next (`_control_stop_child` matches by equality). It gets
        a negative, strictly decreasing id from the clock instead, which no
        Telegram message has; `_reply_anchor` keeps it out of reply targets.
        """
        if parent_message_id is not None:
            return parent_message_id
        last = self.__dict__.get("_last_synthetic_generation", 0)
        generation = min(-(time.time_ns() // 1000), last - 1)
        self._last_synthetic_generation = generation
        return generation

    @staticmethod
    def _reply_anchor(message_id: int | None) -> int | None:
        """A message id to reply to, or None for a synthetic run generation."""
        return message_id if isinstance(message_id, int) and message_id > 0 else None

    def _record_or_defer_message_bindings(
        self,
        *,
        state: TelegramSessionState,
        message_ids: list[int],
        jsonl_uuid: str,
        role: str,
        deferred_bindings: list[tuple[int, str, str]] | None = None,
    ) -> None:
        session_id = state.session_id
        for message_id in message_ids:
            if session_id:
                self._record_message_binding(
                    route=state.route,
                    message_id=message_id,
                    jsonl_uuid=jsonl_uuid,
                    session_id=session_id,
                    role=role,
                )
            elif deferred_bindings is not None:
                deferred_bindings.append((message_id, jsonl_uuid, role))

    def _flush_deferred_bindings(
        self,
        *,
        route: TelegramRoute,
        deferred_bindings: list[tuple[int, str, str]],
        session_id: str | None,
    ) -> None:
        if not session_id or not deferred_bindings:
            return
        while deferred_bindings:
            message_id, jsonl_uuid, role = deferred_bindings.pop(0)
            self._record_message_binding(
                route=route,
                message_id=message_id,
                jsonl_uuid=jsonl_uuid,
                session_id=session_id,
                role=role,
            )

    def _prune_bindings_for_route(self, route: TelegramRoute) -> None:
        stale = [
            key for key, binding in self._message_map.items()
            if binding.route == route
        ]
        for key in stale:
            self._message_map.pop(key, None)
            self._system_message_ids.discard(key)
            self._system_message_routes.pop(key, None)
        stale_system = [
            key
            for key, mapped_route in self._system_message_routes.items()
            if mapped_route == route
        ]
        for key in stale_system:
            self._system_message_ids.discard(key)
            self._system_message_routes.pop(key, None)
        self._state_store.delete_message_bindings_for_route(
            chat_id=route.chat_id,
            thread_id=route.thread_id,
        )
        self._state_store.delete_system_messages_for_route(
            chat_id=route.chat_id,
            thread_id=route.thread_id,
        )
        self._state_store.delete_team_worker_states_for_route(
            chat_id=route.chat_id,
            thread_id=route.thread_id,
        )
        self._state_store.delete_task_handle_states_for_route(
            chat_id=route.chat_id,
            thread_id=route.thread_id,
        )
        self._last_inbound_message_id_by_route.pop(route, None)
        self._pending_inbound_message_ids_by_route.pop(route, None)
        self._persist_state_for_route(route)

    async def _await_persisted_session_uuid(
        self,
        *,
        session_id: str,
        jsonl_path: Path | str | None = None,
        timeout_seconds: float = 8.0,
    ) -> str | None:
        deadline = time.monotonic() + max(timeout_seconds, 0.0)
        while True:
            persisted = (
                self._persisted_jsonl_uuids(jsonl_path)
                if jsonl_path is not None
                else self._persisted_session_uuids(session_id)
            )
            if persisted:
                return persisted[-1]
            if time.monotonic() >= deadline:
                return None
            await asyncio.sleep(0.1)

    async def _await_jsonl_stability(
        self,
        *,
        session_id: str | None = None,
        jsonl_path: Path | str | None = None,
        stable_duration: float = 1.0,
        timeout_seconds: float = 10.0,
    ) -> str | None:
        """Wait for a session JSONL to stop receiving new entries.

        Polls persisted UUIDs every 150 ms and tracks the last UUID seen.
        Returns when no new UUIDs appear for *stable_duration* seconds,
        indicating the streaming response has fully flushed to disk.  A safety
        *timeout_seconds* prevents infinite blocking (e.g. if the source is
        executing a long tool).

        Exactly one of ``session_id`` or ``jsonl_path`` must be provided.
        ``jsonl_path`` is read directly so explicit path sources remain
        disambiguated from global session-id lookup.
        """
        if bool(session_id) == bool(jsonl_path):
            raise ValueError("Exactly one of session_id or jsonl_path is required")

        source_label = session_id or str(jsonl_path)
        deadline = time.monotonic() + max(timeout_seconds, 0.0)
        last_uuid: str | None = None
        last_change_time = time.monotonic()

        while True:
            if jsonl_path is not None:
                persisted = self._persisted_jsonl_uuids(jsonl_path)
            else:
                persisted = self._persisted_session_uuids(session_id or "")
            current_uuid = persisted[-1] if persisted else None

            if current_uuid != last_uuid:
                last_uuid = current_uuid
                last_change_time = time.monotonic()

            # Stable long enough — JSONL has stopped growing.
            if last_uuid is not None and (time.monotonic() - last_change_time) >= stable_duration:
                return last_uuid

            if time.monotonic() >= deadline:
                logger.warning(
                    "[jsonl_stability] timed out after %.1fs for source %s "
                    "(last_uuid=%s) — proceeding with current head",
                    timeout_seconds,
                    source_label,
                    last_uuid,
                )
                return last_uuid

            await asyncio.sleep(0.15)

    def _nearest_binding_for_route_message(
        self,
        *,
        route: TelegramRoute,
        target_message_id: int,
        max_distance: int = 3,
    ) -> _TelegramMessageBinding | None:
        candidates: list[tuple[int, int, _TelegramMessageBinding]] = []
        for (chat_id, message_id), binding in self._message_map.items():
            if chat_id != route.chat_id or binding.route != route:
                continue
            if binding.role == "system":
                continue
            if self._is_system_message_id(chat_id=chat_id, message_id=message_id):
                continue
            distance = abs(message_id - target_message_id)
            candidates.append((distance, message_id, binding))
        if not candidates:
            return None
        distance, _message_id, binding = min(candidates, key=lambda item: (item[0], item[1]))
        if distance > max_distance:
            return None
        return binding

    def _refresh_session_head(
        self,
        *,
        state: TelegramSessionState,
        latest_turn_uuid: str | None,
        source: str,
    ) -> None:
        session_id = state.session_id
        if not session_id or not latest_turn_uuid:
            return
        if source == "event_loop":
            # 2026-10-21 Telegram freeze: this runs for every stream event and used
            # to re-parse the whole session JSONL on the event loop each time
            # (3-4 s per call on 8-16 MB sessions). Within a turn the head uuid is
            # unchanged; user_turn/assistant_turn/done_event/post_run re-validate.
            if self._event_loop_head_checked.get(session_id) == latest_turn_uuid:
                return
            self._event_loop_head_checked[session_id] = latest_turn_uuid
        resolved_uuid = latest_turn_uuid
        target = resolve_safe_jsonl_target(
            session_id=session_id,
            cwd=self._config.vault_path,
            preferred_uuid=latest_turn_uuid,
        )
        if target is not None:
            # During tests and occasional SDK/file timing races, a freshly
            # streamed UUID may not be discoverable in JSONL yet. Do not roll a
            # healthy head backward merely because the UUID is missing; do
            # rewrite heads that are known to be unsafe.
            missing_but_healthy = (
                target.changed
                and target.reason == "preferred_uuid_missing"
                and not target.health.needs_recovery
            )
            if not missing_but_healthy:
                if target.changed:
                    logger.warning(
                        "[jsonl_health] purpose=%s session_id=%s preferred_uuid=%s "
                        "resolved_uuid=%s reason=%s first_unsafe=%s first_poison=%s "
                        "safe_line=%s",
                        f"session_head_{source}",
                        session_id,
                        latest_turn_uuid,
                        target.target_uuid,
                        target.reason,
                        target.health.first_unsafe_tail_uuid,
                        target.health.first_poison_uuid,
                        target.health.safe_recovery_line,
                    )
                resolved_uuid = target.target_uuid or latest_turn_uuid
        if self._session_heads.get(session_id) == resolved_uuid:
            return
        self._set_session_head(
            session_id=session_id,
            jsonl_uuid=resolved_uuid,
        )
        logger.info(
            "[session_head] route=%s session_id=%s uuid=%s source=%s",
            state.route,
            session_id,
            resolved_uuid,
            source,
        )

    def _set_session_head(self, *, session_id: str, jsonl_uuid: str) -> None:
        if not session_id or not jsonl_uuid:
            return
        self._session_heads[session_id] = jsonl_uuid
        self._state_store.upsert_session_head(
            session_id=session_id,
            jsonl_uuid=jsonl_uuid,
        )

    # CACHE-PREFIX WARNING: scheduled/inbox wakes resume or fork an idle session from
    # its JSONL in a new process; the replayed history must equal what the API saw.
    # A break is silent: no error, the API just re-bills the whole conversation.
    # Live check: scripts/cache_regression.py resume_new_proc ws_resume queued_resume (docs/cache-proxy-safety.md).
    async def _resolve_session_for_trigger(
        self,
        *,
        state: TelegramSessionState,
        trigger_message: QueuedMessage | None,
        bot,
    ) -> tuple[bool, int | None]:
        reply_to_user_message_id = trigger_message.telegram_message_id if trigger_message else None
        target_message_id = trigger_message.reply_to_message_id if trigger_message else None
        if target_message_id is None:
            return True, reply_to_user_message_id

        target_is_system = self._is_system_message_id(
            chat_id=state.route.chat_id,
            message_id=target_message_id,
        )
        binding = self._message_map.get((state.route.chat_id, target_message_id))
        if binding is None or binding.role == "system" or target_is_system:
            nearest = self._nearest_binding_for_route_message(
                route=state.route,
                target_message_id=target_message_id,
            )
            if nearest is not None:
                binding = nearest
        logger.info(
            "[reply_lookup] route=%s target_message_id=%s found=%s",
            state.route,
            target_message_id,
            bool(binding),
        )
        if binding is None:
            await self._send_system_message(
                route=state.route,
                bot=bot,
                text="can't fork from this message",
                disable_notification=True,
                reply_to_message_id=reply_to_user_message_id,
            )
            return False, reply_to_user_message_id

        latest_uuid = self._session_heads.get(binding.session_id)
        safe_uuid, _health = self._resolve_safe_jsonl_target(
            session_id=binding.session_id,
            preferred_uuid=binding.jsonl_uuid,
            purpose="reply_fork",
        )
        # vault-w0eg: a bound uuid missing from the session JSONL (a streamed uuid
        # the CLI never persisted) must not silently fork a substitute row. A reply
        # to the latest message continues the session; any other reply is refused.
        # No health means no JSONL was found (same finder as _persisted_session_uuids),
        # so nothing can be judged; fork_session_jsonl's own KeyError is the backstop.
        bound_missing = _health is not None and not _health.has_uuid(binding.jsonl_uuid)
        if bound_missing:
            logger.warning(
                "[reply_fork] bound uuid missing from JSONL route=%s session_id=%s uuid=%s latest=%s",
                state.route, binding.session_id, binding.jsonl_uuid, latest_uuid == binding.jsonl_uuid,
            )
            if latest_uuid == binding.jsonl_uuid:
                await self._activate_route_session(state, binding.session_id)
                return True, reply_to_user_message_id
            safe_uuid = None
        if not safe_uuid:
            await self._send_system_message(
                route=state.route,
                bot=bot,
                text="can't fork from this message",
                disable_notification=True,
                reply_to_message_id=reply_to_user_message_id,
            )
            return False, reply_to_user_message_id

        # A stale head (vault-1bc2: pinned before a since-recovered API-error row)
        # is not the latest message: the session went on past it, and run-start
        # recovery would resolve past the replied-to message, so fork it instead.
        if (latest_uuid == binding.jsonl_uuid and safe_uuid == binding.jsonl_uuid
                and not (_health is not None and is_stale_session_head(_health, latest_uuid))):
            await self._activate_route_session(state, binding.session_id)
            return True, reply_to_user_message_id

        fork_session_id = fork_session_jsonl(
            session_id=binding.session_id,
            target_uuid=safe_uuid,
            cwd=self._config.vault_path,
            new_session_id=str(uuid.uuid4()),
        )
        if self._config.fork_cache_warmup_delay_seconds > 0:
            await asyncio.sleep(self._config.fork_cache_warmup_delay_seconds)
        self._set_session_head(
            session_id=fork_session_id,
            jsonl_uuid=safe_uuid,
        )
        # vault-mngu: identity is read BEFORE the session switch, while the route's
        # env still describes the agent that owns the replied-to message.
        identity = self._resolve_agent_identity(state, source_session_id=binding.session_id)
        await self._activate_route_session(state, fork_session_id)
        if identity is not None:
            self._adopt_conversation_branch(
                state,
                ConversationBranch(
                    session_id=fork_session_id,
                    parent_session_id=binding.session_id,
                    fork_point_uuid=safe_uuid,
                    identity=identity,
                ),
            )
            return True, reply_to_user_message_id
        # No identity is recoverable (no env team, no bootstrap in the source
        # JSONL): the agent never had one, so the legacy priming is the only path.
        logger.warning(
            "[inline_fork] no recoverable identity route=%s source_session=%s; priming new bootstrap",
            state.route, binding.session_id,
        )
        lineage = self._ensure_state_lineage(state, session_id=binding.session_id)
        self._prime_obs_bootstrap(
            state,
            lineage=lineage,
            origin="inline_fork",
            is_fork=True,
            parent_session_id=binding.session_id,
            session_id=fork_session_id,
        )
        return True, reply_to_user_message_id

    def _resolve_agent_identity(
        self,
        state: TelegramSessionState,
        *,
        source_session_id: str | None,
    ) -> AgentIdentity | None:
        """Recover the existing identity of the agent on this route (vault-mngu).

        Order: the route's team env (the live identity), then the latest
        bootstrap recorded in the source session JSONL. Never derives a new
        root team key: ``root_team_key_for_lineage`` stamps the current time,
        which is exactly how inline forks used to mint new trees.
        """
        env = state.session_manager.sdk_env_overrides
        team_name = env.get("CLAUDE_CODE_TEAM_NAME", "").strip()
        agent_name = env.get("CLAUDE_CODE_AGENT_NAME", "").strip()
        lineage = tuple(state.agent_lineage or ())
        bootstrap = None
        if not (team_name and agent_name and lineage):
            bootstrap = find_latest_obs_bootstrap_for_session(
                session_id=source_session_id or state.session_id,
                cwd=self._config.vault_path,
            )
        if bootstrap is not None:
            team_name = team_name or (bootstrap.root_team_key or "").strip()
            agent_name = agent_name or (bootstrap.agent_name or "").strip()
            lineage = lineage or tuple(bootstrap.lineage or ())
        if not team_name or not lineage:
            return None
        if not agent_name:
            agent_name = team_name if len(lineage) <= 1 else agent_name_for_lineage(
                lineage, team_key=team_name,
            )
        return AgentIdentity(root_team_key=team_name, agent_name=agent_name, lineage=lineage)

    def _adopt_conversation_branch(
        self,
        state: TelegramSessionState,
        branch: ConversationBranch,
    ) -> None:
        """Make *branch* the route's active conversation without a new identity.

        No bootstrap is primed: the forked JSONL already carries the agent's own
        bootstrap in its copied history, so the agent sees nothing new and its
        team, agent name and inbox stay the same. The original session and its
        message bindings are untouched, so replying to a message on the original
        branch rewinds to it.
        """
        identity = branch.identity
        state.agent_lineage = identity.lineage
        state.session_manager.set_sdk_env_overrides({
            **state.session_manager.sdk_env_overrides,
            **self._build_team_worker_env(
                team_name=identity.root_team_key,
                agent_name=identity.agent_name,
            ),
        })
        state.pending_obs_bootstrap = None
        self._upsert_route_inbox_target(state)
        self._persist_state_for_route(state.route)
        logger.info(
            "[inline_fork] branch adopted route=%s team=%s agent=%s session=%s parent=%s fork_point=%s",
            state.route, identity.root_team_key, identity.agent_name,
            branch.session_id, branch.parent_session_id, branch.fork_point_uuid,
        )

    async def handle_message(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle an incoming Telegram message (entry point from handler)."""
        if update.effective_user is None:
            return
        if update.effective_message is None:
            return

        user_id = update.effective_user.id
        if not self._is_authorized(user_id):
            logger.warning("Unauthorized Telegram user: %d", user_id)
            return

        message = update.effective_message
        route = self._route_for_message(message)
        last_seen = self._last_inbound_message_id_by_route.get(route, 0)
        pending_ids = self._pending_inbound_message_ids_by_route.setdefault(route, set())
        if message.message_id <= last_seen or message.message_id in pending_ids:
            logger.info(
                "Skipping duplicate/stale inbound at receipt route=%s message_id=%s last_seen=%s",
                route, message.message_id, last_seen,
            )
            return
        # Admission must precede every await: normalization and buffer flushes
        # finish out of order, but cannot revoke an already received input.
        pending_ids.add(message.message_id)
        await self._ensure_background_poller(context.bot)
        # Cache the group chat title for General topic naming
        chat = getattr(message, "chat", None)
        if chat is not None:
            chat_title = getattr(chat, "title", None)
            if isinstance(chat_title, str) and chat_title.strip():
                self._chat_titles[message.chat_id] = chat_title.strip()
        await self._maybe_finalize_joined_allowed_user(
            chat_id=message.chat_id,
            joined_user_id=user_id,
            joined_username=self._coerce_username(update.effective_user),
        )
        route = self._route_for_message(message)
        state = self._get_state(route)
        if state is not None:
            state.last_bot = context.bot
        if message.media_group_id is not None:
            media_group_key = (
                message.chat_id,
                user_id,
                route.thread_id,
                str(message.media_group_id),
            )
            if media_group_key not in self._media_group_receipt_ids:
                try:
                    self._media_group_receipt_ids[media_group_key] = await self._send_received_marker(
                        route=route,
                        bot=context.bot,
                        reply_to_message_id=message.message_id,
                    )
                except Exception:
                    logger.debug("Failed to send media-group receipt marker", exc_info=True)
                    self._media_group_receipt_ids[media_group_key] = []
            await self._media_group_buffer.add(update, context)
            return
        if message.text is not None:
            await self._fragment_buffer.add(update, context)
            return
        receipt_message_ids: list[int] = []
        try:
            receipt_message_ids = await self._send_received_marker(
                route=route,
                bot=context.bot,
                reply_to_message_id=message.message_id,
            )
        except Exception:
            logger.debug("Failed to send attachment receipt marker", exc_info=True)

        async def report_transcription_progress(text: str) -> None:
            try:
                status_id = await self._send_system_message(
                    chat_id=route.chat_id,
                    text=text,
                    route=route,
                )
            except Exception:
                logger.debug("Failed to send transcription progress", exc_info=True)
                return
            if isinstance(status_id, int):
                receipt_message_ids.append(status_id)

        try:
            if message.voice is not None:
                normalized = await self._normalizer.normalize_update(
                    update,
                    transcription_progress=report_transcription_progress,
                )
            else:
                normalized = await self._normalizer.normalize_update(update)
        except BaseException:
            pending_ids.discard(message.message_id)
            raise
        if not normalized.agent_text.strip():
            pending_ids.discard(message.message_id)
            logger.info("Skipping empty normalized Telegram message id=%s", message.message_id)
            return
        await self._process_message(
            normalized.agent_text,
            update,
            context,
            inbound_admitted=True,
            pre_sent_status_message_ids=receipt_message_ids,
            user_warnings=normalized.user_warnings,
        )

    def _routes_in_chat(self, chat_id: int) -> list[TelegramRoute]:
        return [route for route in self._states_by_route if route.chat_id == chat_id]

    def _command_targets(
        self,
        *,
        route: TelegramRoute,
        args: list[str],
    ) -> tuple[list[TelegramSessionState], bool]:
        normalized_arg = ""
        if len(args) == 1:
            normalized_arg = args[0].strip().lower()
            # Telegram control clients sometimes send "/cmd all@botname";
            # treat that as the same scope selector as "/cmd all".
            if "@" in normalized_arg:
                normalized_arg = normalized_arg.split("@", 1)[0].strip()
        apply_all = len(args) == 1 and normalized_arg == "all"
        if apply_all:
            routes = self._routes_in_chat(route.chat_id)
            if route not in routes:
                routes.append(route)
            states = [self._get_state(candidate) for candidate in routes]
            return [state for state in states if state is not None], True
        state = self._get_state(route)
        return ([state] if state is not None else []), False

    def _route_tree_identity(
        self, route: TelegramRoute
    ) -> tuple[str, str, tuple[str, ...]] | None:
        """(root team, agent name, normalized lineage) of the agent behind *route*, if known.

        Used by scoped /unschedule so schedules of idle or cold descendants are found from the
        schedule store itself, not only from routes that are active now (vault-maw0).
        """
        state = self._states_by_route.get(route)
        key = self._route_inbox_target_keys_by_route.get(route)
        lineage: tuple[str, ...] = ()
        if state is not None and state.agent_lineage:
            lineage = tuple(
                normalize_lineage_name(item)
                for item in state.agent_lineage
                if isinstance(item, str) and normalize_lineage_name(item)
            )
        if key is not None and lineage:
            return key[0], key[1], lineage
        if state is not None:
            try:
                context_tuple = self._current_tree_context(state)
            except Exception:
                logger.debug("tree identity lookup failed route=%s", route, exc_info=True)
                context_tuple = None
            if context_tuple is not None:
                team_name, agent_name, raw_lineage = context_tuple
                return team_name, agent_name, tuple(
                    normalize_lineage_name(item)
                    for item in raw_lineage
                    if isinstance(item, str) and normalize_lineage_name(item)
                )
        if key is not None:
            return key[0], key[1], ()
        return None

    def _scoped_schedule_records(
        self,
        *,
        route: TelegramRoute,
        scope: str,
    ) -> tuple[list[_TopicScheduleRecord], str | None, str | None]:
        """Schedules in *scope* relative to the topic at *route*.

        Returns (records, tree team name or None, error text or None). ``all`` covers every
        stored schedule; ``chat`` every topic of this Telegram chat; ``tree``/``branch`` use the
        same lineage identity as /stop_tree and /stop_branch, plus the identity of each
        schedule's own route so schedules of idle or never-loaded descendants are included.
        """
        records = list(self._topic_schedules_by_id.values())
        if scope == "all":
            return records, None, None
        if scope == "chat":
            return [record for record in records if record.route.chat_id == route.chat_id], None, None
        state = self._get_state(route, create=False)
        if state is None:
            return [], None, "no agent tree identity found for this topic"
        context_tuple = self._current_tree_context(state)
        if context_tuple is None:
            return [], None, "no agent tree identity found for this topic"
        team_name, agent_name, raw_lineage = context_tuple
        lineage = tuple(
            normalize_lineage_name(item)
            for item in raw_lineage
            if isinstance(item, str) and normalize_lineage_name(item)
        )
        member_routes: set[TelegramRoute] = set()
        try:
            snapshot_states, _stale, _ = self._tree_stop_snapshot(state=state, scope=scope)
            member_routes.update(candidate.route for candidate in snapshot_states)
        except Exception:
            logger.debug("tree snapshot failed for scoped unschedule route=%s", route, exc_info=True)
        member_routes.add(route)
        selected: list[_TopicScheduleRecord] = []
        for record in records:
            if record.route in member_routes:
                selected.append(record)
                continue
            identity = self._route_tree_identity(record.route)
            if identity is None or identity[0] != team_name:
                continue
            if scope == "tree":
                selected.append(record)
            elif identity[1] == agent_name or _schedule_scope.lineage_in_branch(identity[2], lineage):
                selected.append(record)
        return selected, team_name, None

    async def _handle_scoped_unschedule(
        self,
        *,
        route: TelegramRoute,
        bot: Any,
        scope: str,
        include_protected: bool,
    ) -> str:
        """Delete schedules in *scope*, sparing responsibility-protected ones unless asked."""
        records, tree_team, error = self._scoped_schedule_records(route=route, scope=scope)
        if error is not None:
            return f"/unschedule {scope} unavailable: {error}"
        ownership = _schedule_scope.ScheduleOwnership.load(getattr(self._config, "vault_path", None))
        deleted: dict[str, list[tuple[str, str]]] = {}
        protected: list[tuple[str, str, _schedule_scope.Protection]] = []
        for record in sorted(records, key=lambda r: r.schedule_id):
            identity = self._route_tree_identity(record.route)
            record_tree = identity[0] if identity is not None else ""
            protection = ownership.protection(
                schedule_id=record.schedule_id,
                description=record.description,
                tree=tree_team if scope in ("tree", "branch") else record_tree or None,
            )
            if protection.protected and scope == "all" and not protection.reason.startswith("ongoing"):
                # Under "all" every tree is being swept, so tree ownership alone is no reason
                # to keep a schedule; only ongoing responsibilities are spared.
                protection = _schedule_scope.Protection(False, protection.owner_bead, protection.reason)
            if protection.protected and not include_protected:
                protected.append((record.schedule_id, record.description or "", protection))
                continue
            self._delete_topic_schedule(record.schedule_id)
            deleted.setdefault(record_tree, []).append((record.schedule_id, record.description or ""))
        logger.info(
            "[unschedule] scope=%s route=%s deleted=%d protected_kept=%d include_protected=%s",
            scope,
            route,
            sum(len(items) for items in deleted.values()),
            len(protected),
            include_protected,
        )
        return _schedule_scope.format_unschedule_report(
            scope=scope,
            deleted=deleted,
            protected=protected,
            load_errors=ownership.load_errors,
        )

    def _build_session_lines(self, state: TelegramSessionState) -> list[str]:
        task = self._find_task_by_child_route(state.route)
        route_key = self._route_inbox_target_keys_by_route.get(state.route)
        view = SessionViewContext(
            transport="Telegram", topic_title=state.topic_title,
            lineage=tuple(state.agent_lineage or ()),
            pending_bootstrap=state.pending_obs_bootstrap,
            team_name=(task.team_name if task else None) or (route_key[0] if route_key else None),
            agent_name=(task.agent_name if task else None) or (route_key[1] if route_key else None),
            task_id=task.task_id if task else None,
            task_status=task.status if task else None,
            origin=task.launch_tool_name if task else None,
            is_fork=task.is_fork if task else None,
            parent_session_id=task.parent_session_id_at_launch if task else None,
            parent_source_uuid=task.parent_source_uuid if task else None,
            head_uuid=self._session_heads.get(state.session_id or ""),
            chat_id=state.route.chat_id, thread_id=state.route.thread_id,
            busy=state.busy, pending_messages=len(state.pending_messages),
            active_children=len(state.active_fork_task_ids),
            schedule_count=len(self._schedule_ids_by_route.get(state.route, ())),
            notify_on_completion=state.notify_on_completion,
            inbox_wake_pending=state.inbox_wake_pending,
            state_db_path=str(self._config.telegram_state_db_path),
            timeout_ms=task.timeout_ms if task else None,
            max_turns=task.max_turns if task else None,
        )
        return format_session_info_lines(build_session_info(state.session_manager, view=view))

    def _current_tree_context(
        self,
        state: TelegramSessionState,
    ) -> tuple[str, str, tuple[str, ...]] | None:
        bootstrap = None
        if state.pending_obs_bootstrap:
            try:
                bootstrap = parse_obs_bootstrap_xml(state.pending_obs_bootstrap)
            except Exception:
                bootstrap = None
        if bootstrap is None:
            bootstrap = find_latest_obs_bootstrap_for_session(
                session_id=state.session_id,
                cwd=self._config.vault_path,
            )
        route_key = self._route_inbox_target_keys_by_route.get(state.route)
        lineage = state.agent_lineage
        if (not lineage) and bootstrap is not None and bootstrap.lineage:
            lineage = bootstrap.lineage
        env = state.session_manager.sdk_env_overrides
        team_name = (
            (bootstrap.root_team_key if bootstrap is not None else None)
            or env.get("CLAUDE_CODE_TEAM_NAME", "").strip()
            or (route_key[0] if route_key is not None else "")
        )
        agent_name = (
            (bootstrap.agent_name if bootstrap is not None else None)
            or env.get("CLAUDE_CODE_AGENT_NAME", "").strip()
            or (route_key[1] if route_key is not None else "")
        )
        if (not lineage) and team_name and agent_name:
            metadata = self._load_team_projection_metadata(team_name)
            member_lineage = metadata.get(agent_name, {}).get("lineage")
            if isinstance(member_lineage, list):
                lineage = tuple(
                    str(item).strip()
                    for item in member_lineage
                    if isinstance(item, str) and str(item).strip()
                )
        if not lineage:
            lineage = self._ensure_state_lineage(state, session_id=state.session_id)
        if not lineage:
            return None
        if not team_name or not agent_name:
            default_team_name, default_agent_name = self._default_team_projection(lineage)
            team_name = team_name or default_team_name
            agent_name = agent_name or default_agent_name
        return team_name, agent_name, tuple(lineage)

    @staticmethod
    def _fallback_tree_display_name(agent_name: str) -> str:
        normalized = agent_name.strip()
        if not normalized:
            return "unknown"
        match = re.match(r"^[0-9a-f]{10}-(.+)$", normalized)
        if match:
            normalized = match.group(1)
        else:
            match = re.match(r"^\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-(.+)$", normalized)
            if match:
                normalized = match.group(1)
        return normalized.replace("-", " ")

    @staticmethod
    def _tree_chat_token(chat_id: int) -> str | None:
        chat_str = str(chat_id)
        if chat_str.startswith("-100"):
            return chat_str[4:]
        if chat_str.startswith("-"):
            return chat_str[1:]
        return None

    def _build_topic_link(self, route: TelegramRoute) -> str | None:
        chat_token = self._tree_chat_token(route.chat_id)
        if chat_token is None or route.thread_id is None:
            return None
        return f"https://t.me/c/{chat_token}/{route.thread_id}"

    def _tree_display_name_for_member(self, member: dict[str, Any], team_name: str) -> str:
        agent_name = str(member.get("agent_name") or "").strip()
        display_name = str(member.get("display_name") or agent_name).strip()
        lineage_length = member.get("lineage_length")
        if agent_name == team_name or lineage_length == 1:
            return format_root_display_name(team_name, display_name)
        return display_name

    def _tree_link_for_member(self, member: dict[str, Any], team_name: str) -> str | None:
        agent_name = str(member.get("agent_name") or "").strip()
        if not agent_name:
            return None
        record = self._resolve_team_worker_record(team_name=team_name, agent_name=agent_name)
        if record is not None:
            topic_link = self._build_topic_link(record.child_route)
            if topic_link:
                return topic_link
            anchor_id = record.child_completion_message_id or record.launch_child_message_id
            if anchor_id is not None:
                return self._build_message_link(record.child_route, anchor_id)
        state = self._resolve_route_inbox_target(team_name=team_name, agent_name=agent_name)
        if state is not None:
            topic_link = self._build_topic_link(state.route)
            if topic_link:
                return topic_link
            last_inbound_message_id = self._last_inbound_message_id_by_route.get(state.route)
            if last_inbound_message_id is not None:
                return self._build_message_link(state.route, last_inbound_message_id)
        topic_chat_id = member.get("topic_chat_id")
        topic_thread_id = member.get("topic_thread_id")
        if not isinstance(topic_chat_id, int) or not isinstance(topic_thread_id, int):
            return None
        return self._build_topic_link(
            TelegramRoute(chat_id=topic_chat_id, thread_id=topic_thread_id),
        )

    def _load_tree_members(
        self,
        *,
        team_name: str,
        current_agent_name: str,
        current_lineage: tuple[str, ...],
        current_route: TelegramRoute,
    ) -> dict[str, dict[str, Any]]:
        metadata = self._load_team_projection_metadata(team_name)
        inbox_dir = Path.home() / ".claude" / "teams" / team_name / "inboxes"
        all_agents: set[str] = set(metadata)
        if inbox_dir.is_dir():
            for path in inbox_dir.iterdir():
                if path.suffix == ".json" and path.stem:
                    all_agents.add(path.stem)
        if current_agent_name:
            all_agents.add(current_agent_name)

        members: dict[str, dict[str, Any]] = {}
        for agent_name in sorted(all_agents):
            entry = dict(metadata.get(agent_name) or {})
            entry["agent_name"] = agent_name
            members[agent_name] = entry

        for idx, display_name in enumerate(current_lineage):
            lineage = current_lineage[: idx + 1]
            agent_name = agent_name_for_lineage(lineage, team_key=team_name)
            entry = members.setdefault(agent_name, {"agent_name": agent_name})
            entry.setdefault("display_name", display_name)
            entry.setdefault("lineage", list(lineage))
            entry.setdefault("lineage_length", len(lineage))
            entry.setdefault("root_team_key", team_name)
            if idx > 0:
                entry.setdefault(
                    "parent_agent_name",
                    agent_name_for_lineage(lineage[:-1], team_key=team_name),
                )
                entry.setdefault("parent_display_name", current_lineage[idx - 1])
            if agent_name == current_agent_name:
                entry["topic_chat_id"] = current_route.chat_id
                entry["topic_thread_id"] = current_route.thread_id

        for agent_name, entry in members.items():
            entry.setdefault("display_name", self._fallback_tree_display_name(agent_name))
            if not isinstance(entry.get("lineage_length"), int):
                lineage = entry.get("lineage")
                if isinstance(lineage, list):
                    entry["lineage_length"] = len(lineage)
        return members

    def _member_activity_sort_key(self, member: dict[str, Any], agent_name: str) -> tuple[float, str]:
        candidates = [
            member.get("last_active_at"),
            member.get("last_activity_at"),
            member.get("completed_at"),
            member.get("created_at"),
            member.get("updated_at"),
        ]
        for candidate in candidates:
            if isinstance(candidate, (int, float)):
                return (-float(candidate), str(agent_name))
            if isinstance(candidate, str) and candidate.strip():
                try:
                    parsed = datetime.fromisoformat(candidate.replace("Z", "+00:00"))
                except ValueError:
                    continue
                return (-parsed.timestamp(), str(agent_name))
        return (0.0, str(agent_name))

    def _render_tree_html(
        self,
        *,
        team_name: str,
        current_agent_name: str,
        current_lineage: tuple[str, ...],
        members: dict[str, dict[str, Any]],
        mode: str,
    ) -> str:
        if mode == "ancestors":
            allowed = {
                agent_name_for_lineage(current_lineage[: idx + 1], team_key=team_name)
                for idx in range(len(current_lineage))
            }
        elif mode == "descendants":
            allowed = {
                agent_name
                for agent_name, member in members.items()
                if isinstance(member.get("lineage"), list)
                and tuple(member["lineage"][: len(current_lineage)]) == current_lineage
            }
            allowed.add(current_agent_name)
        elif mode == "children":
            allowed = {
                agent_name
                for agent_name, member in members.items()
                if str(member.get("parent_agent_name") or "") == current_agent_name
            }
            allowed.add(current_agent_name)
        else:
            allowed = set(members)

        children_by_parent: dict[str, list[str]] = {}
        root_names: list[str] = []
        for agent_name, member in members.items():
            if agent_name not in allowed:
                continue
            parent_agent_name = str(member.get("parent_agent_name") or "").strip()
            if parent_agent_name and parent_agent_name in allowed and parent_agent_name != agent_name:
                children_by_parent.setdefault(parent_agent_name, []).append(agent_name)
            else:
                root_names.append(agent_name)

        def _sort_key(agent_name: str) -> tuple[float, str]:
            return self._member_activity_sort_key(members[agent_name], agent_name)

        for child_names in children_by_parent.values():
            child_names.sort(key=_sort_key)
        root_names = sorted(set(root_names), key=_sort_key)

        def _label_html(
            agent_name: str,
            *,
            allow_link: bool,
            bold: bool = False,
        ) -> str:
            member = members[agent_name]
            display_name = self._tree_display_name_for_member(member, team_name)
            label = html.escape(display_name)
            if allow_link:
                link = self._tree_link_for_member(member, team_name)
                if link:
                    label = f'<a href="{html.escape(link, quote=True)}">{label}</a>'
            if bold:
                label = f"<b>{label}</b>"
            if agent_name == current_agent_name:
                label = f"{label} (current)"
            return label

        if mode == "ancestors":
            lineage_names = [
                agent_name_for_lineage(current_lineage[: idx + 1], team_key=team_name)
                for idx in range(len(current_lineage))
            ]
            lines = [
                f"- {_label_html(agent_name, allow_link=agent_name != current_agent_name, bold=agent_name == current_agent_name)}"
                for agent_name in lineage_names
                if agent_name in allowed
            ]
            return "\n".join(lines)

        if mode == "descendants" and current_agent_name in allowed:
            header_agent_name = current_agent_name
        else:
            root_agent = agent_name_for_lineage(current_lineage[:1], team_key=team_name)
            if root_agent in allowed:
                header_agent_name = root_agent
            elif root_names:
                header_agent_name = root_names[0]
            else:
                return ""

        body_roots = list(children_by_parent.get(header_agent_name, []))
        if mode == "tree":
            for root_name in root_names:
                if root_name != header_agent_name and root_name not in body_roots:
                    body_roots.append(root_name)

        lines: list[str] = []

        def _walk(agent_name: str, depth: int) -> None:
            indent = "\u00A0" * (4 * depth)
            lines.append(
                f"{indent}- {_label_html(agent_name, allow_link=agent_name != current_agent_name)}"
            )
            for child_name in children_by_parent.get(agent_name, []):
                _walk(child_name, depth + 1)

        for root_name in body_roots:
            _walk(root_name, 0)

        header = _label_html(
            header_agent_name,
            allow_link=header_agent_name != current_agent_name,
            bold=True,
        )
        if not lines:
            return header
        return f"{header}\n\n" + "\n".join(lines)

    async def _handle_tree_view(
        self,
        *,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        mode: str,
    ) -> None:
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        route = self._route_for_message(update.effective_message)
        state = self._get_state(route)
        if state is None:
            return
        state.last_bot = context.bot
        context_tuple = self._current_tree_context(state)
        if context_tuple is None:
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text="tree unavailable: no OBS lineage/bootstrap found for this topic",
                disable_notification=True,
                reply_to_message_id=update.effective_message.message_id,
            )
            return
        team_name, current_agent_name, current_lineage = context_tuple
        members = self._load_tree_members(
            team_name=team_name,
            current_agent_name=current_agent_name,
            current_lineage=current_lineage,
            current_route=route,
        )
        html_text = self._render_tree_html(
            team_name=team_name,
            current_agent_name=current_agent_name,
            current_lineage=current_lineage,
            members=members,
            mode=mode,
        )
        if not html_text:
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text="tree unavailable: no team members found",
                disable_notification=True,
                reply_to_message_id=update.effective_message.message_id,
            )
            return
        await self._send_html(
            route=route,
            bot=context.bot,
            html_text=html_text,
            disable_notification=True,
            reply_to_message_id=update.effective_message.message_id,
        )

    async def handle_tree(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        await self._handle_tree_view(update=update, context=context, mode="tree")

    async def handle_tree_descendants(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        await self._handle_tree_view(update=update, context=context, mode="descendants")

    async def handle_tree_children(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        await self._handle_tree_view(update=update, context=context, mode="children")

    async def handle_tree_ancestors(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        await self._handle_tree_view(update=update, context=context, mode="ancestors")

    async def handle_tree_alias_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        text = (update.effective_message.text or "").strip().lower() if update.effective_message is not None else ""
        mode = "tree"
        if text.startswith("/tree-ancestors"):
            mode = "ancestors"
        elif text.startswith("/tree-children"):
            mode = "children"
        elif text.startswith("/tree-") or text.startswith("/tree-descendants"):
            mode = "descendants"
        await self._handle_tree_view(update=update, context=context, mode=mode)

    async def handle_help(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /help - show concise command usage."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        route = self._route_for_message(update.effective_message)
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=_TELEGRAM_HELP_TEXT,
            disable_notification=True,
            reply_to_message_id=update.effective_message.message_id,
        )

    async def handle_unknown_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle unrecognized slash commands with usage guidance."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        text = str(getattr(update.effective_message, "text", "") or "").strip()
        command = text.split(maxsplit=1)[0] if text else "command"
        route = self._route_for_message(update.effective_message)
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=f"unknown command: {command}\nUse /help for usage.",
            disable_notification=True,
            reply_to_message_id=update.effective_message.message_id,
        )

    async def handle_clear(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /clear - reset current topic or all topics in the current chat."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        await self._ensure_background_poller(context.bot)
        route = self._route_for_message(update.effective_message)
        states, apply_all = self._command_targets(route=route, args=context.args)
        has_schedules = (
            any(bool(self._schedule_ids_by_route.get(state.route, set())) for state in states)
            if apply_all
            else bool(self._schedule_ids_by_route.get(route, set()))
        )
        for state in states:
            state.last_bot = context.bot
            state.hook_state.interrupt_flag = True
            state.hook_state.pause_queue_delivery = False
            self._mark_task_terminal_request(state.route, "failed")
            await self._cancel_route_fork_tasks(state.route, status="failed")

        for state in states:
            lock = self._get_route_lock(state.route)
            async with lock:
                await self._reset_route_state(state)

        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=(
                (
                    "all topic sessions cleared; schedules were kept; agent identities were kept. "
                    "Use /unschedule all to remove schedules across this chat."
                )
                if apply_all and has_schedules
                else (
                    "session cleared; schedule was kept; agent identity was kept. Use /unschedule to remove this topic schedule."
                    if has_schedules
                    else (
                        "all topic sessions cleared; agent identities were kept"
                        if apply_all
                        else "session cleared; agent identity was kept"
                    )
                )
            ),
            disable_notification=True,
        )

    async def handle_effort(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Inspect/select per-topic effort, safely between turns."""
        from obs_agent.effort import EFFORT_USAGE

        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        await self._ensure_background_poller(context.bot)
        route = self._route_for_message(update.effective_message)
        state = self._get_state(route)
        if state is None:
            return
        state.last_bot = context.bot
        args = list(context.args or [])
        async with self._get_route_lock(route):
            if not args:
                response = (f"effort: {state.session_manager.effective_effort}; "
                            f"model: {state.session_manager.effective_model}\n"
                            f"usage: {EFFORT_USAGE}")
            elif len(args) != 1:
                response = f"usage: {EFFORT_USAGE}"
            elif state.busy or state.pending_messages or not state.hook_state.message_queue.empty():
                response = "effort unchanged: wait for the active/queued work to finish, or /stop first"
            else:
                try:
                    effort = await state.session_manager.set_effort(args[0])
                except ValueError as exc:
                    response = f"{exc}. usage: {EFFORT_USAGE}"
                else:
                    self._persist_state_for_route(route)
                    response = f"effort selected: {effort}; applies on the next turn (conversation kept)"
        await self._send_system_message(
            route=route, bot=context.bot, text=response, disable_notification=True,
        )

    async def handle_model(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /model - select the model before a session's first message."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        await self._ensure_background_poller(context.bot)
        route = self._route_for_message(update.effective_message)
        state = self._get_state(route)
        if state is None:
            return
        state.last_bot = context.bot

        args = [str(arg).strip() for arg in context.args if str(arg).strip()]
        if len(args) != 1:
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text=(
                    "usage: /model <model|inherit>; examples: "
                    "/model gpt, /model gpt[200k], /model sonnet[1m]"
                ),
                disable_notification=True,
            )
            return

        requested = args[0]
        lock = self._get_route_lock(route)
        async with lock:
            session_started = (
                state.busy
                or state.session_id is not None
                or bool(state.pending_messages)
                or not state.hook_state.message_queue.empty()
            )
            if session_started:
                response = (
                    "model is locked for this active session; use /clear or /new, "
                    "then /model before sending the first message"
                )
            else:
                state.session_manager.model_override = (
                    None if requested.lower() == "inherit" else resolve_model(requested)
                )
                effective_model = normalize_model_for_claude_code(
                    state.session_manager.effective_model
                )
                state.hook_state.effective_model = effective_model
                self._persist_state_for_route(route)
                response = (f"model selected for next session: {effective_model}; "
                            f"effort: {state.session_manager.effective_effort}")

        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=response,
            disable_notification=True,
        )

    async def handle_new(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /new - reset current topic into a new trunk identity."""
        if update.effective_user is None or update.effective_message is None:
            return
        first_arg = str(context.args[0]).strip().lower() if context.args else ""
        if first_arg == "-group":
            await self.handle_new_group_alias(update, context)
            return
        if first_arg == "-bot":
            await self.handle_new_bot_alias(update, context)
            return
        raw_text = str(getattr(update.effective_message, "text", "") or "").strip()
        if re.match(_NEW_GROUP_ALIAS_PATTERN, raw_text):
            await self.handle_new_group_alias(update, context)
            return
        if re.match(_NEW_BOT_ALIAS_PATTERN, raw_text):
            await self.handle_new_bot_alias(update, context)
            return
        if not self._is_authorized(update.effective_user.id):
            return

        await self._ensure_background_poller(context.bot)
        route = self._route_for_message(update.effective_message)
        state = self._get_state(route)
        if state is None:
            return
        state.last_bot = context.bot
        requested = " ".join(context.args).strip() or None
        new_title, chosen_emoji, chosen_icon = await self._resolve_new_topic_visibility(
            state=state,
            bot=context.bot,
            raw_args=requested,
        )

        state.hook_state.interrupt_flag = True
        state.hook_state.pause_queue_delivery = False
        self._mark_task_terminal_request(state.route, "failed")
        await self._cancel_route_fork_tasks(state.route, status="failed")

        lock = self._get_route_lock(state.route)
        async with lock:
            self._remove_route_inbox_target(state.route)
            state.agent_lineage = None
            state.pending_obs_bootstrap = None
            await self._reset_route_state(state)
            if self._default_new_chat_hooks is not None:
                state.session_manager.user_hooks = dict(self._default_new_chat_hooks)
            await self._apply_topic_visibility(
                route=route,
                bot=context.bot,
                title=new_title,
                icon_custom_emoji_id=chosen_icon,
            )
            self._prime_obs_bootstrap(
                state,
                lineage=(new_title,),
                origin="new_trunk",
                is_fork=False,
            )

        topic_label = new_title
        if chosen_emoji:
            topic_label = f"{chosen_emoji} {topic_label}"
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=f"new trunk session created: {topic_label}",
            disable_notification=True,
        )

    async def handle_new_group(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /new_group - provision a fresh forum supergroup via the userbot."""
        raw_args = self._extract_command_args(
            update,
            context,
            command_names=("new_group",),
        )
        await self._run_userbot_command(
            update,
            context,
            action_name="new group",
            command_cb=lambda: self._provision_new_group(
                update=update,
                context=context,
                raw_args=raw_args,
            ),
        )

    async def handle_new_group_alias(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /new-group raw-text alias."""
        raw_args = self._extract_command_args(
            update,
            context,
            command_names=("new-group", "new_group"),
        )
        await self._run_userbot_command(
            update,
            context,
            action_name="new group",
            command_cb=lambda: self._provision_new_group(
                update=update,
                context=context,
                raw_args=raw_args,
            ),
        )

    async def handle_new_bot(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /new_bot - create a new sender bot via BotFather."""
        raw_args = self._extract_command_args(
            update,
            context,
            command_names=("new_bot",),
        )
        await self._run_userbot_command(
            update,
            context,
            action_name="new bot",
            command_cb=lambda: self._provision_new_bot(
                update=update,
                context=context,
                raw_args=raw_args,
            ),
        )

    async def handle_new_bot_alias(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        """Handle /new-bot raw-text alias."""
        raw_args = self._extract_command_args(
            update,
            context,
            command_names=("new-bot", "new_bot"),
        )
        await self._run_userbot_command(
            update,
            context,
            action_name="new bot",
            command_cb=lambda: self._provision_new_bot(
                update=update,
                context=context,
                raw_args=raw_args,
            ),
        )

    def _extract_command_args(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        command_names: tuple[str, ...],
    ) -> str | None:
        joined = " ".join(context.args).strip()
        if joined:
            return joined
        message = update.effective_message
        if message is None:
            return None
        text = str(getattr(message, "text", "") or "").strip()
        for command_name in command_names:
            pattern = rf"^/{re.escape(command_name)}(?:@[A-Za-z0-9_]+)?(?:\s+(.*))?\s*$"
            match = re.match(pattern, text)
            if match:
                extracted = (match.group(1) or "").strip()
                return extracted or None
        return None

    async def _run_userbot_command(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        action_name: str,
        command_cb,
    ) -> None:
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        route = self._route_for_message(update.effective_message)
        started_text = self._userbot_command_started_text(action_name)
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=started_text,
            disable_notification=True,
            reply_to_message_id=update.effective_message.message_id,
        )
        try:
            result_text = await command_cb()
        except Exception as exc:
            logger.error("Telegram %s failed (%s)", action_name, type(exc).__name__)
            await self._report_command_error(update, context.bot, exc)
            return
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=result_text,
            disable_notification=True,
            reply_to_message_id=update.effective_message.message_id,
        )

    def _userbot_command_started_text(self, action_name: str) -> str:
        normalized = action_name.strip().lower()
        if normalized == "new bot":
            wait_target = "BotFather"
        elif normalized == "new group":
            wait_target = "Telegram"
        else:
            wait_target = "Telegram"
        return f"{action_name} started: waiting on {wait_target}; this can take a bit"

    def _build_userbot_provisioner(self) -> TelegramUserbotProvisioner:
        return TelegramUserbotProvisioner(self._config)

    def _coerce_username(self, user: Any) -> str | None:
        username = getattr(user, "username", None)
        if not isinstance(username, str):
            return None
        normalized = username.lstrip("@").strip()
        return normalized or None

    def _parse_new_group_request(self, raw_args: str | None) -> tuple[str | None, str]:
        if not raw_args or not raw_args.strip():
            raise RuntimeError("group title required: /new-group <group title>")
        try:
            parts = shlex.split(raw_args)
        except ValueError as exc:
            raise RuntimeError(f"invalid /new-group arguments: {exc}") from exc

        target_override: str | None = None
        idx = 0
        while idx < len(parts) and parts[idx].startswith("--"):
            option = parts[idx]
            if option == "--user":
                if idx + 1 >= len(parts):
                    raise RuntimeError("--user requires @handle or numeric id")
                target_override = parts[idx + 1].strip()
                idx += 2
                continue
            if option.startswith("--user="):
                target_override = option.partition("=")[2].strip()
                idx += 1
                continue
            raise RuntimeError(f"unsupported /new-group option: {option}")

        title = " ".join(parts[idx:]).strip()
        if not title:
            raise RuntimeError("group title required: /new-group <group title>")
        return target_override, title

    async def _provision_new_group(
        self,
        *,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        raw_args: str | None,
    ) -> str:
        if update.effective_user is None:
            raise RuntimeError("missing effective user")
        target_override, title = self._parse_new_group_request(raw_args)
        provisioner = self._build_userbot_provisioner()
        result = await provisioner.create_group(
            title=title,
            default_user_id=update.effective_user.id,
            default_username=self._coerce_username(update.effective_user),
            target_override=target_override,
        )
        target_label = (
            f"@{result.target_username}" if result.target_username
            else str(result.target_user_id) if result.target_user_id is not None
            else "unknown"
        )
        bot_label = ", ".join(f"@{username}" for username in result.added_bot_usernames) or "none"
        leave_label = "userbot left after setup" if result.creator_left else "userbot stayed as owner"
        layout_label = "list" if not result.forum_tabs_enabled else "tabs"
        folder_label = "not configured"
        if result.folder_title:
            folder_label = f"{result.folder_title}:{'added' if result.added_to_folder else 'unchanged'}"
        addlist_label = "not configured"
        if result.addlist_url:
            addlist_label = f"{result.addlist_url}:{'added' if result.added_to_addlist else 'unchanged'}"
        return (
            f"created group: {result.title} "
            f"(chat_id={result.chat_id}; target={target_label}; bots={bot_label}; forum_layout={layout_label}; "
            f"folder={folder_label}; addlist={addlist_label}; {leave_label})"
        )

    async def _provision_new_bot(
        self,
        *,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        raw_args: str | None,
    ) -> str:
        _ = update, context
        display_name = (raw_args or "").strip() or "Claudia"
        provisioner = self._build_userbot_provisioner()
        created = await provisioner.create_bot(display_name=display_name)
        await self._register_secondary_sender_bot(created.token)
        groups_text = "enabled" if created.groups_enabled else "not confirmed"
        privacy_text = "disabled" if created.privacy_disabled else "not confirmed"
        return (
            f"created bot: {created.username} "
            f"(display_name={created.display_name}; env_key={created.env_key}; groups={groups_text}; privacy={privacy_text})"
        )

    async def _register_secondary_sender_bot(self, token: str) -> None:
        primary = self._config.telegram_primary_bot_token
        if token == primary:
            return
        if token in self._config.telegram_bot_tokens:
            return
        await self._ensure_sender_pool()
        self._config.telegram_bot_tokens.append(token)
        new_sender = Bot(token=token)
        try:
            await new_sender.delete_my_commands()
        except Exception:
            logger.warning("Failed clearing commands on newly created secondary bot", exc_info=True)
        self._sender_bots.append(new_sender)

    async def handle_schedule(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        route = self._route_for_message(update.effective_message)
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text="/schedule is gated until Sprint 1 schedule reliability is approved; use CronCreate from an agent topic for now.",
            disable_notification=True,
            reply_to_message_id=update.effective_message.message_id,
        )

    async def handle_unschedule(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /unschedule [branch|tree|all|chat] [--include-protected] (vault-maw0)."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        route = self._route_for_message(update.effective_message)
        parsed = _schedule_scope.parse_scope_args(context.args)
        if parsed.scope == "chat":
            states, _ = self._command_targets(route=route, args=["all"])
            deleted = 0
            for state in states:
                schedule_ids = sorted(self._schedule_ids_by_route.get(state.route, set()))
                for schedule_id in schedule_ids:
                    self._delete_topic_schedule(schedule_id)
                    deleted += 1
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text=(
                    f"unscheduled {deleted} schedule(s) across this chat"
                    if deleted > 0
                    else "no schedules attached to this chat"
                ),
                disable_notification=True,
            )
            return
        if parsed.scope in ("all", "tree", "branch"):
            text = await self._handle_scoped_unschedule(
                route=route,
                bot=context.bot,
                scope=parsed.scope,
                include_protected=parsed.include_protected,
            )
            for chunk in split_message(text):
                await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text=chunk,
                    disable_notification=True,
                )
            return

        schedule_ids = sorted(self._schedule_ids_by_route.get(route, set()))
        if not schedule_ids:
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text="no schedules attached to this topic",
                disable_notification=True,
            )
            return

        if parsed.rest:
            target_id = parsed.rest[0].strip()
            record = self._topic_schedules_by_id.get(target_id)
            if record is None or record.route != route:
                await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text=f"no schedule found in this topic: {target_id}",
                    disable_notification=True,
                )
                return
            self._delete_topic_schedule(target_id)
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text=f"unscheduled 1 schedule for this topic: {target_id}",
                disable_notification=True,
            )
        else:
            # Delete only the next upcoming schedule (soonest next_run_at)
            records = [
                self._topic_schedules_by_id[sid]
                for sid in schedule_ids
                if sid in self._topic_schedules_by_id
            ]
            # Sort by next_run_at; schedules without next_run_at go last
            records.sort(key=lambda r: r.next_run_at if r.next_run_at is not None else float("inf"))
            if records:
                next_record = records[0]
                self._delete_topic_schedule(next_record.schedule_id)
                await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text=f"unscheduled next upcoming schedule: {next_record.schedule_id}",
                    disable_notification=True,
                )
            else:
                await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text="no schedules attached to this topic",
                    disable_notification=True,
                )

    async def log_command_update(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Log every slash command before its handler runs (observer only)."""
        message = update.effective_message
        if message is None:
            return
        try:
            route = self._route_for_message(message)
        except Exception:
            route = None
        state = self._get_state(route, create=False) if route is not None else None
        logger.info(
            "[command] route=%s user_id=%s message_id=%s session_id=%s text=%r",
            route,
            update.effective_user.id if update.effective_user else None,
            message.message_id,
            state.session_id if state is not None else None,
            (message.text or "")[:300],
        )

    async def handle_session(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /session without starting a client or creating a persisted route."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return
        if context.args:
            await update.effective_message.reply_text("Usage: /session", parse_mode=None)
            return

        route = self._route_for_message(update.effective_message)
        state = self._get_state(route, create=False)
        if state is None:
            state = self._build_session_state(route)
            if self._default_new_chat_hooks is not None:
                state.session_manager.user_hooks = dict(self._default_new_chat_hooks)
        text = "\n".join(self._build_session_lines(state))
        for chunk in split_message(text):
            await update.effective_message.reply_text(
                chunk, parse_mode=None, disable_web_page_preview=True,
            )

    async def handle_report(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /report [comment] - persist a debug case file for later analysis."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        route = self._route_for_message(update.effective_message)
        comment = " ".join(context.args).strip()
        try:
            report_path = self._write_case_report(
                route=route,
                trigger_message_id=update.effective_message.message_id,
                trigger_user_id=update.effective_user.id,
                comment=comment,
            )
        except Exception as exc:
            logger.error("Failed writing /report case file (%s)", type(exc).__name__)
            await self._report_command_error(update, context.bot, exc)
            return

        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=f"report saved: {report_path}",
            disable_notification=True,
            reply_to_message_id=update.effective_message.message_id,
        )

    async def _handle_scoped_stop(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        scope: str,
    ) -> None:
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        await self._ensure_background_poller(context.bot)
        route = self._route_for_message(update.effective_message)
        state = self._get_state(route)
        if state is None:
            return
        states, stale, current_lineage = self._tree_stop_snapshot(
            state=state,
            scope=scope,
        )
        if current_lineage is None:
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text=f"{scope} stop unavailable: no agent tree identity found",
                disable_notification=True,
            )
            return
        second_states, second_stale, _ = self._tree_stop_snapshot(
            state=state,
            scope=scope,
        )
        seen_routes = {candidate.route for candidate in states}
        states.extend(candidate for candidate in second_states if candidate.route not in seen_routes)
        stale += second_stale
        counts = await self._interrupt_scoped_states(states=states, bot=context.bot)
        attempted = sum(counts.values())
        logger.info(
            "Scoped interrupt via /stop_%s from user %d attempted=%d interrupted=%d inactive=%d stale=%d failed=%d",
            scope,
            update.effective_user.id,
            attempted,
            counts["interrupted"],
            counts["already_inactive"],
            stale,
            counts["failed"],
        )
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=(
                f"/stop_{scope}: interrupted {counts['interrupted']}; "
                f"already inactive {counts['already_inactive']}; "
                f"stale {stale}; failed {counts['failed']}"
            ),
            disable_notification=True,
        )

    async def handle_stop_branch(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /stop_branch - interrupt this agent and recursive descendants."""
        await self._handle_scoped_stop(update, context, scope="branch")

    async def handle_stop_tree(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /stop_tree - interrupt the complete root team tree."""
        await self._handle_scoped_stop(update, context, scope="tree")

    async def handle_stop(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /stop - this topic; /stop all every tree; /stop chat every topic of this chat."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        await self._ensure_background_poller(context.bot)
        route = self._route_for_message(update.effective_message)
        parsed = _schedule_scope.parse_scope_args(context.args)
        if parsed.scope == "all":
            # Every running agent in every tree (vault-maw0). Only routes with a live turn or a
            # connected client are touched: idle disconnected agents have nothing to stop, and
            # touching thousands of idle routes would only queue stale interrupt notices.
            states = [
                candidate
                for candidate in list(self._states_by_route.values())
                if candidate.busy
                or candidate.hook_state.execution_active
                or (candidate.session_manager._client is not None and candidate.session_manager._connected)
            ]
            if route not in {candidate.route for candidate in states}:
                current = self._get_state(route, create=False)
                if current is not None:
                    states.insert(0, current)
            counts = await self._interrupt_scoped_states(states=states, bot=context.bot)
            cancelled_tasks = await self._cancel_running_fork_tasks(status="stopped")
            logger.info(
                "Global interrupt via /stop all from user %d interrupted=%d inactive=%d failed=%d tasks=%d",
                update.effective_user.id,
                counts["interrupted"],
                counts["already_inactive"],
                counts["failed"],
                cancelled_tasks,
            )
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text=(
                    f"/stop all (every tree): interrupted {counts['interrupted']}; "
                    f"already inactive {counts['already_inactive']}; failed {counts['failed']}; "
                    f"running agent tasks cancelled {cancelled_tasks}. "
                    "Schedules are untouched — /unschedule all removes them."
                ),
                disable_notification=True,
            )
            return
        states, apply_all = self._command_targets(
            route=route, args=["all"] if parsed.scope == "chat" else []
        )
        interrupt_sent = 0
        for state in states:
            state.last_bot = context.bot
            if await self._request_route_interrupt(state):
                interrupt_sent += 1
            if apply_all:
                await self._cancel_route_fork_tasks(state.route, status="stopped")
            else:
                self._mark_child_task_terminal_request(state.route, "stopped")
        logger.info(
            "Interrupt via /stop from user %d all=%s sdk_interrupts=%d/%d",
            update.effective_user.id,
            apply_all,
            interrupt_sent,
            len(states),
        )
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text="interrupt sent to all topics" if apply_all else "interrupt sent",
            disable_notification=True,
        )

    def _status_to_text(self, event: StatusEvent) -> str:
        if event.type == "queue_delivered":
            return ""
        return event.summary

    def _render_notification_status_html(self, event: StatusEvent) -> str:
        heading = event.summary.strip() or "notification"
        parts = [self._format_system_html(heading)]
        for line in event.messages or []:
            normalized = line.strip()
            if normalized:
                parts.append(self._format_status_html(normalized))
        return "\n".join(parts).strip()

    def _is_interrupt_marker_text(self, text: str) -> bool:
        normalized = text.strip()
        return (
            normalized.startswith("[Request interrupted by user")
            and normalized.endswith("]")
        )

    def _render_turn_html(self, turn_items: list[TextEvent | StatusEvent]) -> str:
        parts: list[str] = []
        for item in turn_items:
            if isinstance(item, TextEvent):
                if self._is_interrupt_marker_text(item.text):
                    parts.append(self._format_system_html(item.text.strip()))
                    continue
                rendered = md_to_telegram_html(item.text)
                if rendered:
                    parts.append(rendered)
            elif isinstance(item, StatusEvent):
                if item.type == "notification":
                    rendered = self._render_notification_status_html(item)
                    if rendered:
                        parts.append(rendered)
                    continue
                status_text = self._status_to_text(item)
                if status_text.strip():
                    parts.append(self._format_status_html(status_text))
        return "\n".join(parts).strip()

    def _turn_is_observability_only(self, turn_items: list[TextEvent | StatusEvent]) -> bool:
        if not turn_items:
            return False
        if any(isinstance(item, TextEvent) for item in turn_items):
            return False
        # Keep notification pushes visible immediately instead of coalescing them
        # into the low-priority observability buffer.
        if any(
            isinstance(item, StatusEvent) and item.type == "notification"
            for item in turn_items
        ):
            return False
        return True

    async def _flush_observability_buffer(
        self,
        *,
        route: TelegramRoute,
        bot,
        priority: int = _PRIORITY_OBSERVABILITY,
    ) -> None:
        """Send this route's buffered tool-status chunks.

        The background coalescing flush keeps the low observability priority. Callers inside
        the run loop pass ``_PRIORITY_ASSISTANT``: they await this before the assistant text
        (or DoneEvent) it precedes, so a low priority there starved the whole run loop behind
        other routes' traffic on the single transport worker (obs-13, 2026-10-18: 17 minutes,
        the route stayed "running" and its inbox wake was delayed).
        """
        task = self._observability_flush_tasks.pop(route, None)
        if task is not None and not task.done():
            task.cancel()
        buffered = self._observability_buffer.pop(route, None)
        if not buffered:
            return
        html_text = "\n".join(
            chunk.html_text for chunk in buffered if chunk.html_text.strip()
        ).strip()
        if not html_text:
            return
        started = time.monotonic()
        sent_messages = await self._send_html(
            route=route,
            bot=bot,
            html_text=html_text,
            disable_notification=True,
            priority=priority,
        )
        waited = time.monotonic() - started
        if waited >= _OBSERVABILITY_SLOW_FLUSH_WARN_SECONDS:
            logger.warning(
                "[observability_flush] slow send route=%s priority=%d waited=%.1fs pending_chat_ops=%d",
                route, priority, waited, self._chat_pending_ops.get(route.chat_id, 0),
            )
        latest_uuid: str | None = None
        latest_session_id: str | None = None
        for chunk in reversed(buffered):
            if chunk.jsonl_uuid and chunk.session_id:
                latest_uuid = chunk.jsonl_uuid
                latest_session_id = chunk.session_id
                break
        if latest_uuid and latest_session_id:
            for sent in sent_messages:
                message_id = self._sent_message_id(sent)
                if not isinstance(message_id, int):
                    continue
                self._record_message_binding(
                    route=route,
                    message_id=message_id,
                    jsonl_uuid=latest_uuid,
                    session_id=latest_session_id,
                    role="assistant",
                )

    def _schedule_observability_flush(self, *, route: TelegramRoute) -> None:
        existing = self._observability_flush_tasks.get(route)
        if existing is not None and not existing.done():
            return

        async def _delayed_flush() -> None:
            try:
                await asyncio.sleep(_OBSERVABILITY_COALESCE_SECONDS)
                state = self._get_state(route, create=False)
                if state is None or state.last_bot is None:
                    return
                await self._flush_observability_buffer(route=route, bot=state.last_bot)
            except asyncio.CancelledError:
                pass
            except Exception:
                logger.debug("observability flush failed route=%s", route, exc_info=True)
            finally:
                self._observability_flush_tasks.pop(route, None)

        self._observability_flush_tasks[route] = asyncio.create_task(_delayed_flush())

    async def _send_html(
        self,
        *,
        route: TelegramRoute,
        bot,
        html_text: str,
        disable_notification: bool,
        reply_to_message_id: int | None = None,
        priority: int = _PRIORITY_ASSISTANT,
        max_attempts: int | None = None,
    ) -> list:
        text = html_text.strip() if html_text.strip() else "(no response)"
        chunks = split_message(text)
        sent_messages: list = []

        for index, chunk in enumerate(chunks):
            if index > 0:
                await asyncio.sleep(_CHUNK_DELAY_SECONDS)
            try:
                sent = await self._send_plain_with_retry(
                    route=route,
                    bot=bot,
                    text=chunk,
                    parse_mode=ParseMode.HTML,
                    disable_notification=disable_notification,
                    reply_to_message_id=reply_to_message_id if index == 0 else None,
                    priority=priority,
                    max_attempts=max_attempts,
                )
                sent_messages.append(sent)
            except BadRequest as exc:
                msg_lower = str(exc).lower()
                if "can't parse entities" in msg_lower:
                    logger.warning("HTML parse failed, sending plain text: %s", exc)
                    plain = re.sub(r"<[^>]+>", "", chunk)
                    sent = await self._send_plain_with_retry(
                        route=route,
                        bot=bot,
                        text=plain,
                        disable_notification=disable_notification,
                        reply_to_message_id=reply_to_message_id if index == 0 else None,
                        priority=priority,
                        max_attempts=max_attempts,
                    )
                    sent_messages.append(sent)
                    continue
                if "too long" in msg_lower:
                    logger.warning(
                        "Chunk too long (%d chars), re-splitting as plain text: %s",
                        len(chunk), exc,
                    )
                    plain = re.sub(r"<[^>]+>", "", chunk)
                    sub_chunks = split_message(plain)
                    for sub_index, sub in enumerate(sub_chunks):
                        sent = await self._send_plain_with_retry(
                            route=route,
                            bot=bot,
                            text=sub,
                            disable_notification=disable_notification,
                            reply_to_message_id=(
                                reply_to_message_id
                                if index == 0 and sub_index == 0
                                else None
                            ),
                            priority=priority,
                            max_attempts=max_attempts,
                        )
                        sent_messages.append(sent)
                    continue
                raise
        return sent_messages

    async def _flush_turn(
        self,
        *,
        state: TelegramSessionState,
        bot,
        turn_items: list[TextEvent | StatusEvent],
        jsonl_uuid: str | None = None,
        deferred_bindings: list[tuple[int, str, str]] | None = None,
    ) -> None:
        if not turn_items:
            return
        html_text = self._render_turn_html(turn_items)
        if not html_text:
            return
        if self._turn_is_observability_only(turn_items):
            self._observability_buffer.setdefault(state.route, []).append(
                _ObservabilityChunk(
                    html_text=html_text,
                    jsonl_uuid=jsonl_uuid,
                    session_id=state.session_id,
                )
            )
            self._schedule_observability_flush(route=state.route)
            return
        await self._flush_observability_buffer(route=state.route, bot=bot, priority=_PRIORITY_ASSISTANT)
        logger.info(
            "[flush_turn] sending %d chars (%d items) route=%s preview=%r",
            len(html_text), len(turn_items), state.route, html_text[:160],
        )
        if "<tool_call>" in html_text or "&lt;tool_call&gt;" in html_text:
            logger.warning(
                "[flush_turn] textual tool call in assistant text (unparsed model tool call) "
                "route=%s session_id=%s model=%s",
                state.route, state.session_id, state.session_manager.effective_model,
            )
        sent_messages = await self._send_html(
            route=state.route,
            bot=bot,
            html_text=html_text,
            disable_notification=True,
            priority=_PRIORITY_ASSISTANT,
        )
        session_id = state.session_id
        if not jsonl_uuid:
            logger.info(
                "[flush_turn] not mapping turn jsonl_uuid=%s session_id=%s turn_items=%d text=%r",
                jsonl_uuid,
                session_id,
                len(turn_items),
                html_text[:500],
            )
            return
        for sent in sent_messages:
            message_id = self._sent_message_id(sent)
            if message_id is None:
                continue
            if session_id:
                self._record_message_binding(
                    route=state.route,
                    message_id=message_id,
                    jsonl_uuid=jsonl_uuid,
                    session_id=session_id,
                    role="assistant",
                )
            elif deferred_bindings is not None:
                deferred_bindings.append((message_id, jsonl_uuid, "assistant"))

    async def _run_and_send(
        self,
        *,
        state: TelegramSessionState,
        user_text: str,
        bot,
        trigger_message: QueuedMessage | None = None,
        extra_pending: list[QueuedMessage] | None = None,
        trigger_status_message_ids: list[int] | None = None,
        triggered_schedule_id: str | None = None,
        suppress_completion_summary: bool = False,
        quiet_error: bool = False,
    ) -> _RunOutcome:
        pending_messages = list(state.pending_messages)
        if extra_pending:
            pending_messages.extend(extra_pending)

        proceed, reply_to_message_id = await self._resolve_session_for_trigger(
            state=state,
            trigger_message=trigger_message,
            bot=bot,
        )
        if not proceed:
            state.pending_messages = []
            return _RunOutcome(assistant_text="")
        logger.info(
            "[run_and_send] preflight route=%s session_id=%s trigger_message_id=%s schedule_id=%s pending=%d msg=%.80s",
            state.route,
            state.session_id,
            trigger_message.telegram_message_id if trigger_message else None,
            triggered_schedule_id,
            len(pending_messages),
            user_text,
        )
        try:
            await self._recover_route_session_if_needed(
                state=state,
                source="run_start",
            )
        except Exception as exc:
            # Dead-topic fix (2026-10-12): never drop the turn silently. Tell the
            # topic once per (session, error); queued work stays owned by the route,
            # including messages a caller drained into extra_pending (obs-52 V1:
            # an idle inbox wake lost them when this preflight raised).
            state.pending_messages = pending_messages
            error = f"{type(exc).__name__}: {exc}"
            key = (state.session_id, error)
            if self._recovery_failure_notified.get(state.route) != key:
                self._recovery_failure_notified[state.route] = key
                try:
                    await self._send_system_message(
                        route=state.route,
                        bot=bot,
                        text=(
                            exc.notice() if isinstance(exc, ContentRefusalLoopError) else
                            f"Session recovery failed for {state.session_id}, so this turn could not run "
                            f"({error}). Send /clear to start a fresh session in this topic."
                        ),
                        disable_notification=False,
                        reply_to_message_id=trigger_message.telegram_message_id if trigger_message else None,
                    )
                except Exception:
                    logger.exception("[jsonl_recovery_failed] could not notify route=%s", state.route)
            raise
        self._recovery_failure_notified.pop(state.route, None)

        # Keep queued work owned by the route until session preflight succeeds.
        # A cancelled/failed detached delivery can then retry without losing it.
        state.pending_messages = []
        runner = ConversationRunner(
            state.session_manager,
            state.hook_state,
            self._config,
            pending_messages=pending_messages,
        )

        def _store_remaining_pending() -> None:
            nonlocal interrupt_discarded_count
            remaining = runner.remaining_pending
            if state.hook_state.interrupt_requested:
                interrupt_discarded_count = len(remaining)
                if remaining:
                    logger.info(
                        "[run_and_send] Dropping %d pending queued message(s) after /stop route=%s",
                        len(remaining),
                        state.route,
                    )
                state.pending_messages = []
                return
            state.pending_messages = remaining

        turn_items: list[TextEvent | StatusEvent] = []
        deferred_bindings: list[tuple[int, str, str]] = []
        completion_sent = False
        event_count = 0
        turn_count = 0
        latest_turn_uuid: str | None = None
        interrupt_discarded_count: int | None = None
        captured_text_parts: list[str] = []
        failed = False
        error_text: str | None = None
        state.busy = True
        state.hook_state.execution_active = True
        state.last_bot = bot
        state.hook_state.interrupt_flag = False
        state.hook_state.interrupt_requested = False
        # A latched task stop (obs-2) survives turn starts: a turn that starts
        # without explicit new input stays marked stopped and cannot reconnect.
        state.hook_state.stop_requested_at = state.hook_state.stop_latched_at
        state.hook_state.pause_queue_delivery = False
        run_user_text = user_text
        # A stop ends the prior turn, not the task described by the next message.
        state.hook_state.interrupt_notice_pending = False
        runner_events = None
        trigger_status_ids = list(trigger_status_message_ids or [])
        trigger_user_mapped = False
        pending_bootstrap_active: str | None = None

        def _completion_interrupt_count() -> int | None:
            if interrupt_discarded_count is not None:
                return interrupt_discarded_count
            if state.hook_state.interrupt_requested:
                return 0
            return None

        logger.info(
            "[run_and_send] START route=%s msg=%s",
            state.route, user_text[:80],
        )

        state.inflight_user_text = user_text
        state.inflight_first_turn = not state.session_id
        try:
            if state.pending_obs_bootstrap is None and not self._session_heads.get(state.session_id or ""):
                had_lineage = state.agent_lineage is not None
                lineage = self._ensure_state_lineage(state)
                projection = self._state_inbox_projection(state)
                self._prime_obs_bootstrap(
                    state,
                    lineage=lineage,
                    origin="session_reset" if had_lineage else "trunk_start",
                    is_fork=False,
                    team_name=projection[0] if projection is not None else None,
                    agent_name=projection[1] if projection is not None else None,
                    session_id=state.session_id,
                )
            await state.session_manager.get_client()
            self._bind_state_session(state)
            latest_session_bootstrap = None
            if state.pending_obs_bootstrap:
                latest_session_bootstrap = find_latest_obs_bootstrap_for_session(
                    session_id=state.session_id,
                    cwd=self._config.vault_path,
                )
            if state.pending_obs_bootstrap and (
                latest_session_bootstrap is None
                or latest_session_bootstrap.raw_xml != state.pending_obs_bootstrap
            ):
                # Fresh child/fork topics may inherit a parent session head before
                # their own bootstrap is written. Keep prepending the pending
                # bootstrap until the child session JSONL actually contains it.
                pending_bootstrap_active = state.pending_obs_bootstrap
                run_user_text = f"{pending_bootstrap_active}\n\n{run_user_text}"
            last_good_turn_uuid = self._session_heads.get(state.session_id or "")
            # Prepend server timestamp + context stats to user messages
            _now_str = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
            _ctx_snapshot = build_context_snapshot(
                session_id=state.session_id,
                data=state.hook_state.last_result_data,
                context_window_estimate_tokens=self._context_window_tokens_for_state(
                    state,
                    self._config.context_window_estimate_tokens,
                ),
                cwd=self._config.vault_path,
            )
            _ctx_remaining = _ctx_snapshot.get("estimated_context_remaining_tokens", 0)
            _ctx_pct = _ctx_snapshot.get("estimated_context_remaining_pct", 0.0)
            _ctx_window = _ctx_snapshot.get("estimated_context_window_tokens", 0)
            if state.hook_state.last_result_data is not None:
                # Print the session's real context window next to the percentage so
                # agents never read the CLI capacity-selector suffix (e.g. [1m]) as
                # the served window.
                _ctx_line = (
                    f"\nContext: ~{_ctx_remaining:,} of {_ctx_window:,} "
                    f"tokens remaining ({_ctx_pct:.0f}%)"
                )
            else:
                _ctx_line = "\nContext: first turn"
            run_user_text = f"<system-note>\nTime: {_now_str}{_ctx_line}\n</system-note>\n\n{run_user_text}"

            working_message = None
            try:
                working_message = await self._send_system_message(
                    route=state.route,
                    bot=bot,
                    text="working",
                    disable_notification=True,
                    reply_to_message_id=None,
                    max_attempts=1,
                )
            except Exception:
                logger.debug("Failed to send working marker", exc_info=True)
            working_message_id = self._sent_message_id(working_message) if working_message is not None else None
            if isinstance(working_message_id, int):
                trigger_status_ids.append(working_message_id)
            runner_events = runner.run(run_user_text)
            async for event in runner_events:
                event_count += 1
                self._flush_deferred_bindings(
                    route=state.route,
                    deferred_bindings=deferred_bindings,
                    session_id=state.session_id,
                )
                self._bind_state_session(state)
                self._refresh_session_head(
                    state=state,
                    latest_turn_uuid=latest_turn_uuid,
                    source="event_loop",
                )
                if isinstance(event, TextEvent | StatusEvent):
                    if (
                        isinstance(event, StatusEvent)
                        and event.type == "queue_delivered"
                        and event.summary.strip().lower() == "queued message delivered"
                    ):
                        try:
                            queued_working_message = await self._send_system_message(
                                route=state.route,
                                bot=bot,
                                text="working",
                                disable_notification=True,
                                max_attempts=1,
                            )
                            queued_working_message_id = self._sent_message_id(queued_working_message)
                            if isinstance(queued_working_message_id, int):
                                trigger_status_ids.append(queued_working_message_id)
                        except Exception:
                            logger.debug("Failed to send queued-delivery working marker", exc_info=True)
                    if isinstance(event, TextEvent) and event.text:
                        captured_text_parts.append(event.text)
                    turn_items.append(event)
                    continue

                if isinstance(event, TurnEndEvent):
                    if event.is_error:
                        failed = True
                        visible_error_text = event.error_text or "\n".join(
                            item.text.strip()
                            for item in turn_items
                            if isinstance(item, TextEvent) and item.text.strip()
                        ).strip()
                        if visible_error_text:
                            error_text = visible_error_text
                        if event.error_text:
                            if not any(
                                isinstance(item, TextEvent) and item.text.strip()
                                for item in turn_items
                            ):
                                turn_items.append(TextEvent(text=event.error_text))
                                captured_text_parts.append(event.error_text)
                        if state.session_id and last_good_turn_uuid:
                            self._set_session_head(
                                session_id=state.session_id,
                                jsonl_uuid=last_good_turn_uuid,
                            )
                            latest_turn_uuid = last_good_turn_uuid
                        await self._flush_turn(
                            state=state,
                            bot=bot,
                            turn_items=turn_items,
                            deferred_bindings=deferred_bindings,
                        )
                        turn_items.clear()
                        trigger_status_ids.clear()
                        continue
                    if (
                        event.jsonl_uuid
                        and event.message_role == "user"
                        and not trigger_user_mapped
                        and trigger_message is not None
                        and isinstance(trigger_message.telegram_message_id, int)
                    ):
                        self._record_or_defer_message_bindings(
                            state=state,
                            message_ids=[trigger_message.telegram_message_id],
                            jsonl_uuid=event.jsonl_uuid,
                            role="user",
                            deferred_bindings=deferred_bindings,
                        )
                        if trigger_status_ids:
                            self._record_or_defer_message_bindings(
                                state=state,
                                message_ids=list(trigger_status_ids),
                                jsonl_uuid=event.jsonl_uuid,
                                role="system",
                                deferred_bindings=deferred_bindings,
                            )
                        if state.session_id:
                            self._refresh_session_head(
                                state=state,
                                latest_turn_uuid=event.jsonl_uuid,
                                source="user_turn",
                            )
                        latest_turn_uuid = event.jsonl_uuid
                        trigger_user_mapped = True
                        trigger_status_ids.clear()

                    turn_count += 1
                    logger.info(
                        "[run_and_send] TurnEnd #%d items=%d route=%s",
                        turn_count, len(turn_items), state.route,
                    )
                    mapped_uuid = (
                        event.jsonl_uuid
                        if event.jsonl_uuid and turn_items and not event.is_error
                        else None
                    )
                    if mapped_uuid and trigger_status_ids:
                        self._record_or_defer_message_bindings(
                            state=state,
                            message_ids=trigger_status_ids,
                            jsonl_uuid=mapped_uuid,
                            role="assistant",
                            deferred_bindings=deferred_bindings,
                        )
                        trigger_status_ids.clear()
                    if mapped_uuid:
                        latest_turn_uuid = mapped_uuid
                        last_good_turn_uuid = mapped_uuid
                        self._refresh_session_head(
                            state=state,
                            latest_turn_uuid=latest_turn_uuid,
                            source="assistant_turn",
                        )
                    await self._flush_turn(
                        state=state,
                        bot=bot,
                        turn_items=turn_items,
                        jsonl_uuid=mapped_uuid,
                        deferred_bindings=deferred_bindings,
                    )
                    turn_items.clear()
                    continue

                if isinstance(event, DoneEvent):
                    logger.info(
                        "[run_and_send] DoneEvent events=%d turns=%d route=%s",
                        event_count, turn_count, state.route,
                    )
                    # Safety flush in case a producer emitted text without TurnEndEvent.
                    if turn_items:
                        await self._flush_turn(
                            state=state,
                            bot=bot,
                            turn_items=turn_items,
                            deferred_bindings=deferred_bindings,
                        )
                        turn_items.clear()

                    self._flush_deferred_bindings(
                        route=state.route,
                        deferred_bindings=deferred_bindings,
                        session_id=state.session_id,
                    )
                    self._bind_state_session(state)
                    self._refresh_session_head(
                        state=state,
                        latest_turn_uuid=latest_turn_uuid,
                        source="done_event",
                    )
                    _store_remaining_pending()
                    await self._flush_observability_buffer(route=state.route, bot=bot, priority=_PRIORITY_ASSISTANT)
                    if not suppress_completion_summary and self._should_emit_completion_summary(state):
                        if triggered_schedule_id is None:
                            self._reanchor_interval_schedules_for_route(
                                route=state.route,
                                base_ts=time.time(),
                            )
                        summary_message = await self._send_system_message(
                            route=state.route,
                            bot=bot,
                            text=self._build_completion_summary(
                                state,
                                triggered_schedule_id=triggered_schedule_id,
                                interrupt_discarded_count=_completion_interrupt_count(),
                            ),
                            disable_notification=False,
                            reply_to_message_id=reply_to_message_id,
                            priority=_PRIORITY_ASSISTANT,
                        )
                        summary_message_id = self._sent_message_id(summary_message)
                        latest_uuid = latest_turn_uuid or self._session_heads.get(
                            state.session_id or ""
                        )
                        if (
                            summary_message_id is not None
                            and latest_uuid
                        ):
                            self._record_or_defer_message_bindings(
                                state=state,
                                message_ids=[summary_message_id],
                                jsonl_uuid=latest_uuid,
                                role="assistant",
                                deferred_bindings=deferred_bindings,
                            )
                        else:
                            logger.info(
                                "[summary_map] skipped message_id=%s latest_uuid=%s session_id=%s",
                                summary_message_id,
                                latest_uuid,
                                state.session_id,
                            )
                        completion_sent = True
                    break

            _store_remaining_pending()
            self._flush_deferred_bindings(
                route=state.route,
                deferred_bindings=deferred_bindings,
                session_id=state.session_id,
            )
            self._bind_state_session(state)
            self._refresh_session_head(
                state=state,
                latest_turn_uuid=latest_turn_uuid,
                source="post_run",
            )
            await self._flush_observability_buffer(route=state.route, bot=bot, priority=_PRIORITY_ASSISTANT)

            if (
                not completion_sent
                and not suppress_completion_summary
                and self._should_emit_completion_summary(state)
            ):
                if triggered_schedule_id is None:
                    self._reanchor_interval_schedules_for_route(
                        route=state.route,
                        base_ts=time.time(),
                    )
                summary_message = await self._send_system_message(
                    route=state.route,
                    bot=bot,
                    text=self._build_completion_summary(
                        state,
                        triggered_schedule_id=triggered_schedule_id,
                        interrupt_discarded_count=_completion_interrupt_count(),
                    ),
                    disable_notification=False,
                    reply_to_message_id=reply_to_message_id,
                    priority=_PRIORITY_ASSISTANT,
                )
                summary_message_id = self._sent_message_id(summary_message)
                latest_uuid = latest_turn_uuid or self._session_heads.get(
                    state.session_id or ""
                )
                if (
                    summary_message_id is not None
                    and latest_uuid
                ):
                    self._record_or_defer_message_bindings(
                        state=state,
                        message_ids=[summary_message_id],
                        jsonl_uuid=latest_uuid,
                        role="assistant",
                        deferred_bindings=deferred_bindings,
                    )
                else:
                    logger.info(
                        "[summary_map] skipped message_id=%s latest_uuid=%s session_id=%s",
                        summary_message_id,
                        latest_uuid,
                        state.session_id,
                    )
                completion_sent = True

        except Exception as exc:
            logger.exception("Error in ConversationRunner")

            error_detail = f"{type(exc).__name__}: {exc}"
            if len(error_detail) > 200:
                error_detail = error_detail[:200] + "..."
            failed = True
            error_text = error_detail

            if quiet_error:
                logger.warning("[run_and_send] repeat failure, error message suppressed route=%s", state.route)
            else:
                try:
                    await self._send_system_message(
                        route=state.route,
                        bot=bot,
                        text=f"error: {error_detail}",
                        disable_notification=False,
                        reply_to_message_id=reply_to_message_id,
                    )
                except Exception:
                    logger.exception("Failed to send error reply")

            try:
                await state.session_manager.soft_reset()
                logger.info("Soft reset after error (session_id preserved)")
            except Exception:
                logger.warning("Soft reset failed", exc_info=True)

        finally:
            # Finish runner queue ownership before another route turn can start,
            # even if transport failed while the generator was yielding an event.
            if runner_events is not None:
                await runner_events.aclose()
            _store_remaining_pending()
            if state.hook_state.post_stop_messages:
                state.pending_messages = list(state.pending_messages) + state.hook_state.post_stop_messages
                state.hook_state.post_stop_messages = []
            state.busy = False
            state.inflight_user_text = None
            state.inflight_first_turn = False
            state.hook_state.execution_active = False
            state.hook_state.interrupt_requested = False
            try:
                await self._flush_observability_buffer(route=state.route, bot=bot, priority=_PRIORITY_ASSISTANT)
            except Exception:
                logger.debug("Failed flushing observability buffer in finally", exc_info=True)
            # Always send the final completion summary so Telegram collectors
            # have a stable end-of-turn marker even on error paths.
            if (
                not completion_sent
                and not suppress_completion_summary
                and self._should_emit_completion_summary(state)
            ):
                try:
                    if triggered_schedule_id is None:
                        self._reanchor_interval_schedules_for_route(
                            route=state.route,
                            base_ts=time.time(),
                        )
                    summary_message = await self._send_system_message(
                        route=state.route,
                        bot=bot,
                        text=self._build_completion_summary(
                            state,
                            triggered_schedule_id=triggered_schedule_id,
                            interrupt_discarded_count=_completion_interrupt_count(),
                        ),
                        disable_notification=False,
                        reply_to_message_id=reply_to_message_id,
                        priority=_PRIORITY_ASSISTANT,
                    )
                    summary_message_id = self._sent_message_id(summary_message)
                    latest_uuid = latest_turn_uuid or self._session_heads.get(
                        state.session_id or ""
                    )
                    if (
                        summary_message_id is not None
                        and latest_uuid
                    ):
                        self._record_or_defer_message_bindings(
                            state=state,
                            message_ids=[summary_message_id],
                            jsonl_uuid=latest_uuid,
                            role="assistant",
                            deferred_bindings=deferred_bindings,
                        )
                    else:
                        logger.info(
                            "[summary_map] skipped message_id=%s latest_uuid=%s session_id=%s",
                            summary_message_id,
                            latest_uuid,
                            state.session_id,
                        )
                except Exception:
                    logger.debug("Failed to send completion summary in finally", exc_info=True)

        if (
            not trigger_user_mapped
            and trigger_message is not None
            and isinstance(trigger_message.telegram_message_id, int)
            and latest_turn_uuid
        ):
            mapped_key = (state.route.chat_id, trigger_message.telegram_message_id)
            if mapped_key not in self._message_map:
                self._record_or_defer_message_bindings(
                    state=state,
                    message_ids=[trigger_message.telegram_message_id],
                    jsonl_uuid=latest_turn_uuid,
                    role="user",
                    deferred_bindings=deferred_bindings,
                )
            trigger_user_mapped = True
        if trigger_status_ids and latest_turn_uuid:
            self._record_or_defer_message_bindings(
                state=state,
                message_ids=list(trigger_status_ids),
                jsonl_uuid=latest_turn_uuid,
                role="system",
                deferred_bindings=deferred_bindings,
            )
            trigger_status_ids.clear()
        self._flush_deferred_bindings(
            route=state.route,
            deferred_bindings=deferred_bindings,
            session_id=state.session_id,
        )

        # Check for queued inbox wake — fires after the turn completes
        # (mirrors children's wake_requested flag on _ForkTaskRecord).
        if state.inbox_wake_pending:
            state.inbox_wake_pending = False
            try:
                team_name_for_wake = None
                agent_name_for_wake = None
                for (tn, an), r in self._route_inbox_targets.items():
                    if r == state.route:
                        team_name_for_wake, agent_name_for_wake = tn, an
                        break
                if team_name_for_wake and agent_name_for_wake:
                    # Detached: awaiting here re-enters _run_and_send from inside
                    # _run_and_send's own tail, nesting another full turn into
                    # whatever is waiting on this one (on the inbox path, the
                    # original sender's tool call).
                    self._spawn_detached_route_inbox_wake(
                        state=state,
                        team_name=team_name_for_wake,
                        agent_name=agent_name_for_wake,
                        sender=state.inbox_wake_sender,
                        summary=state.inbox_wake_summary,
                        content=state.inbox_wake_content,
                    )
            except Exception:
                logger.debug("Failed queued inbox wake after turn", exc_info=True)
            state.inbox_wake_sender = None
            state.inbox_wake_summary = None
            state.inbox_wake_content = None

        assistant_text = "\n".join(part for part in captured_text_parts if part).strip()
        self._note_route_credit_limit(
            route=state.route,
            failed=failed,
            error_text=error_text,
            assistant_text=assistant_text,
        )
        return _RunOutcome(
            assistant_text=assistant_text,
            failed=failed,
            error=error_text,
        )

    @staticmethod
    def _telegram_sender_label(user: Any) -> str:
        full_name = getattr(user, "full_name", None)
        if isinstance(full_name, str) and full_name.strip():
            return full_name.strip()
        parts = [
            value.strip()
            for value in (getattr(user, "first_name", None), getattr(user, "last_name", None))
            if isinstance(value, str) and value.strip()
        ]
        return " ".join(parts) or "Unknown Telegram User"

    def _annotate_telegram_user_text(self, user_text: str, user: Any) -> str:
        user_id = getattr(user, "id", None)
        return (
            f'<telegram_sender full_name="{html.escape(self._telegram_sender_label(user), quote=True)}" '
            f'user_id="{int(user_id)}"/>\n{user_text}'
        )

    async def _process_admitted_message(
        self, user_text: str, update: Update, context: ContextTypes.DEFAULT_TYPE,
        *, last_message_id: int,
    ) -> None:
        await self._process_message(
            user_text, update, context,
            inbound_admitted=True, last_message_id=last_message_id,
        )

    async def _process_message(
        self,
        user_text: str,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        *,
        pre_sent_status_message_ids: list[int] | None = None,
        user_warnings: list[str] | None = None,
        inbound_admitted: bool = False,
        last_message_id: int | None = None,
    ) -> None:
        """Process a complete (possibly reassembled) user message."""
        if update.effective_message is None or update.effective_user is None:
            return

        route = self._route_for_message(update.effective_message)
        message_id = update.effective_message.message_id
        last_seen = self._last_inbound_message_id_by_route.get(route)
        if not inbound_admitted and isinstance(last_seen, int) and message_id <= last_seen:
            logger.info(
                "Skipping duplicate/out-of-order inbound route=%s message_id=%s last_seen=%s",
                route,
                message_id,
                last_seen,
            )
            return
        self._last_inbound_message_id_by_route[route] = max(
            last_seen or 0, message_id, last_message_id or 0,
        )
        pending_ids = self._pending_inbound_message_ids_by_route.get(route)
        if pending_ids is not None:
            pending_ids.difference_update({
                mid for mid in pending_ids
                if mid <= self._last_inbound_message_id_by_route[route]
            })
        state = self._get_state(route)
        if state is None:
            return
        self._persist_state_for_route(route)
        state.last_bot = context.bot
        state.warning_sent = False
        self._clear_stop_latch(state, "user_message")

        logger.info("Processing message from route %s: %s", route, user_text[:100])

        lock = self._get_route_lock(route)
        logger.info(
            "[process_message] route=%s lock.locked=%s busy=%s",
            route, lock.locked(), state.busy,
        )
        reply_to_message_id = None
        reply_to_message = update.effective_message.reply_to_message
        candidate_reply_id = getattr(reply_to_message, "message_id", None)
        if isinstance(candidate_reply_id, int):
            # Forum-topic sends often arrive as an implicit reply to the topic root.
            # That is routing metadata, not an explicit user fork target.
            if not (route.thread_id is not None and candidate_reply_id == route.thread_id):
                reply_to_message_id = candidate_reply_id
        annotated_user_text = self._annotate_telegram_user_text(
            user_text, update.effective_user
        )
        incoming = QueuedMessage(
            text=annotated_user_text,
            telegram_message_id=update.effective_message.message_id,
            reply_to_message_id=reply_to_message_id,
        )
        if lock.locked() or state.busy:
            state.hook_state.message_queue.put_nowait(incoming)
            logger.info("[process_message] queued while busy route=%s", route)
            try:
                await self._send_received_marker(
                    route=route,
                    bot=context.bot,
                    reply_to_message_id=incoming.telegram_message_id,
                )
            except Exception:
                logger.debug("Failed to send receipt marker for queued message", exc_info=True)
            return

        # Pre-claim busy before status marker delivery to avoid a race where
        # a second inbound message slips between marker send and lock acquire.
        state.busy = True
        trigger_status_message_ids: list[int] = list(pre_sent_status_message_ids or [])
        if not trigger_status_message_ids:
            try:
                trigger_status_message_ids.extend(
                    await self._send_received_marker(
                        route=route,
                        bot=context.bot,
                        reply_to_message_id=incoming.telegram_message_id,
                    )
                )
            except Exception:
                logger.debug("Failed to send receipt marker", exc_info=True)
        for warning in user_warnings or []:
            try:
                warning_message = await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text=warning,
                    disable_notification=True,
                    reply_to_message_id=incoming.telegram_message_id,
                )
                warning_message_id = self._sent_message_id(warning_message)
                if warning_message_id is not None:
                    trigger_status_message_ids.append(warning_message_id)
            except Exception:
                logger.debug("Failed to send normalization warning", exc_info=True)
        try:
            async with lock:
                logger.info("[process_message] lock acquired route=%s", route)
                if state.hook_state.pause_queue_delivery:
                    state.pending_messages.extend(_drain_queue(state.hook_state.message_queue))
                    state.hook_state.pause_queue_delivery = False
                await self._run_and_send(
                    state=state,
                    user_text=annotated_user_text,
                    bot=context.bot,
                    trigger_message=incoming,
                    trigger_status_message_ids=trigger_status_message_ids,
                )
                logger.info("[process_message] _run_and_send returned route=%s", route)
        finally:
            if state.busy and not lock.locked():
                # _run_and_send normally clears this; this is fallback for
                # pre-lock failures.
                state.busy = False

    async def _process_media_group(
        self,
        updates: list[Update],
        context: ContextTypes.DEFAULT_TYPE,
    ) -> None:
        if not updates:
            return
        first_message = updates[0].effective_message
        first_user = updates[0].effective_user
        receipt_message_ids: list[int] = []
        if first_message is not None and first_user is not None and first_message.media_group_id is not None:
            media_group_key = (
                first_message.chat_id,
                first_user.id,
                getattr(first_message, "message_thread_id", None),
                str(first_message.media_group_id),
            )
            receipt_message_ids = self._media_group_receipt_ids.pop(media_group_key, [])
        normalized = await self._normalizer.normalize_media_group(updates)
        if not normalized.agent_text.strip():
            logger.info("Skipping empty normalized Telegram media group")
            return
        await self._process_message(
            normalized.agent_text,
            updates[0],
            context,
            inbound_admitted=True,
            last_message_id=max(item.effective_message.message_id for item in updates),
            pre_sent_status_message_ids=receipt_message_ids,
            user_warnings=normalized.user_warnings,
        )

    async def _schedule_poller_loop(self) -> None:
        """Poll topic schedules independently of inbox and queue delivery."""
        while True:
            try:
                await asyncio.sleep(self._background_poll_seconds)
                await self._process_stop_schedule_events()
                await self._run_due_interval_schedules()
                if (self._pending_schedule_owners or self._pending_schedule_owner_retirements
                    or self._schedule_owner_sweep_pending) and (
                    self._schedule_owner_repair_task is None or self._schedule_owner_repair_task.done()
                ):
                    self._schedule_owner_repair_task = asyncio.create_task(self._repair_pending_schedule_owners())
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("Schedule poller iteration failed")

    async def _poll_background_queues_once(self) -> None:
        """Dispatch queued delivery without awaiting any recipient's full turn."""
        if self._inbox_wake_poll_task is None or self._inbox_wake_poll_task.done():
            # Inbox discovery may await a worker's Telegram wake marker. It must
            # not prevent completed-child queues on other routes being serviced.
            task = asyncio.create_task(self._poll_team_worker_inbox_wakes())
            self._inbox_wake_poll_task = task
            self._detached_wake_tasks.add(task)
            task.add_done_callback(self._on_detached_wake_done)
        for state in list(self._states_by_route.values()):
            delivery = self._background_delivery_tasks.get(state.route)
            if delivery is not None and not delivery.done():
                continue
            bot = self._bot_for_state(state)
            if bot is None:
                continue
            if state.busy or state.hook_state.pause_queue_delivery:
                continue
            if state.hook_state.stop_latched_at is not None:
                # A stopped task's queue waits for explicit new input (obs-2).
                continue
            if self._chat_pending_ops.get(state.route.chat_id, 0) > 0:
                # Keep model-visible queue delivery behind Telegram transport drain.
                # Otherwise the model can process queued updates before users have
                # seen prior assistant messages still pending delivery.
                continue
            # Leave queue ownership with the route until delivery starts.
            pending_depth = state.hook_state.message_queue.qsize() + len(
                state.pending_messages
            )
            if pending_depth == 0:
                continue
            if self._get_route_lock(state.route).locked():
                continue
            backoff = self._auto_delivery_backoff.get(state.route)
            if backoff is not None and time.monotonic() < backoff[1]:
                continue
            task = asyncio.create_task(self._deliver_background_queue(state))
            self._background_delivery_tasks[state.route] = task
            self._detached_wake_tasks.add(task)
            task.add_done_callback(
                lambda done, route=state.route: self._on_background_delivery_done(route, done)
            )

    def _on_background_delivery_done(self, route: TelegramRoute, task: asyncio.Task) -> None:
        if self._background_delivery_tasks.get(route) is task:
            self._background_delivery_tasks.pop(route, None)
        self._on_detached_wake_done(task)

    async def _deliver_background_queue(self, state: TelegramSessionState) -> None:
        lock = self._get_route_lock(state.route)
        if lock.locked():
            return
        async with lock:
            bot = self._bot_for_state(state)
            if (
                bot is None
                or state.busy
                or state.hook_state.pause_queue_delivery
                or state.hook_state.stop_latched_at is not None
                or self._chat_pending_ops.get(state.route.chat_id, 0) > 0
            ):
                return
            queued = _drain_queue(state.hook_state.message_queue)
            if not queued and not state.pending_messages:
                return
            logger.info(
                "Auto-delivering queued updates route=%s queued=%d pending=%d",
                state.route, len(queued), len(state.pending_messages),
            )
            state.pending_messages.extend(queued)
            trigger_message = state.pending_messages[-1]
            # Reserve this route before asynchronous session/transport startup.
            state.busy = True
            prior_failures = self._auto_delivery_backoff.get(state.route, (0, 0.0))[0]
            outcome = None
            raised = True
            try:
                outcome = await self._run_and_send(
                    state=state,
                    user_text=_AUTO_DELIVERY_PROMPT,
                    bot=bot,
                    trigger_message=trigger_message,
                    # One visible error per failure streak, not one per retry.
                    quiet_error=prior_failures > 0,
                )
                raised = False
            finally:
                state.busy = False
                self._record_auto_delivery_outcome(
                    state.route,
                    failed=raised or (isinstance(outcome, _RunOutcome) and outcome.failed),
                )

    def _record_auto_delivery_outcome(self, route: TelegramRoute, *, failed: bool) -> None:
        """Exponential backoff for auto-delivery that keeps failing (vault-qjit)."""
        if not failed:
            self._auto_delivery_backoff.pop(route, None)
            return
        failures = self._auto_delivery_backoff.get(route, (0, 0.0))[0] + 1
        delay = min(
            _AUTO_DELIVERY_BACKOFF_BASE_SECONDS * (2 ** (failures - 1)),
            _AUTO_DELIVERY_BACKOFF_MAX_SECONDS,
        )
        self._auto_delivery_backoff[route] = (failures, time.monotonic() + delay)
        logger.warning(
            "[auto_delivery] run failed route=%s consecutive=%d next_retry_in=%.0fs",
            route, failures, delay,
        )

    async def _background_poller_loop(self) -> None:
        """Poll for queued background messages and auto-deliver when idle."""
        while True:
            try:
                await asyncio.sleep(self._background_poll_seconds)
                await self._poll_background_queues_once()
            except asyncio.CancelledError:
                break
            except Exception:
                logger.exception("Background poller iteration failed")

    def _build_message_link(self, route: TelegramRoute, message_id: int) -> str | None:
        chat_token = self._tree_chat_token(route.chat_id)
        if chat_token is None:
            return None
        if route.thread_id is None:
            return f"https://t.me/c/{chat_token}/{message_id}"
        return f"https://t.me/c/{chat_token}/{route.thread_id}/{message_id}"

    def _resolve_runtime_log_file(self) -> str | None:
        for key in ("OBS_RUNTIME_LOG_FILE", "OBS_TELEGRAM_LOG_FILE"):
            value = (os.environ.get(key) or "").strip()
            if value:
                return value
        return None

    def _write_case_report(
        self,
        *,
        route: TelegramRoute,
        trigger_message_id: int,
        trigger_user_id: int,
        comment: str,
    ) -> Path:
        now_utc = datetime.now(timezone.utc)
        timestamp_slug = now_utc.strftime("%Y%m%d-%H%M%S")
        thread_part = (
            f"topic{route.thread_id}"
            if route.thread_id is not None
            else "general"
        )
        filename = (
            f"case-{timestamp_slug}-chat{route.chat_id}-{thread_part}-{uuid.uuid4().hex[:8]}.md"
        )
        report_dir = self._config.claude_path / "reports" / "cases"
        report_dir.mkdir(parents=True, exist_ok=True)
        report_path = report_dir / filename

        state = self._get_state(route, create=False)
        session_id = state.session_id if state is not None else None
        session_head = self._session_heads.get(session_id or "")
        session_jsonl = (
            find_session_jsonl(session_id=session_id, cwd=self._config.vault_path)
            if session_id
            else None
        )

        bound = self._message_map.get((route.chat_id, trigger_message_id))
        bound_uuid = bound.jsonl_uuid if bound is not None else None
        bound_session = bound.session_id if bound is not None else None
        trigger_link = self._build_message_link(route, trigger_message_id)
        log_file = self._resolve_runtime_log_file()
        normalized_comment = comment.strip() or "(no comment provided)"

        lines = [
            "# Telegram Case Report",
            "",
            f"- Created (UTC): {now_utc.isoformat(timespec='seconds')}",
            f"- Trigger comment: {normalized_comment}",
            f"- Chat ID: {route.chat_id}",
            f"- Topic thread ID: {route.thread_id if route.thread_id is not None else '(General)'}",
            f"- Topic title: {self._current_topic_title(route)}",
            f"- Trigger message ID: {trigger_message_id}",
            f"- Trigger message link: {trigger_link or '(unavailable for this chat id)'}",
            f"- Trigger user ID: {trigger_user_id}",
            f"- Active route session ID: {session_id or '(none)'}",
            f"- Active route head UUID: {session_head or '(none)'}",
            f"- Trigger binding UUID: {bound_uuid or '(none)'}",
            f"- Trigger binding session ID: {bound_session or '(none)'}",
            f"- Session JSONL: {session_jsonl or '(none)'}",
            f"- State DB: {self._config.telegram_state_db_path}",
            f"- Runtime PID: {os.getpid()}",
            f"- Runtime log file: {log_file or '(OBS_RUNTIME_LOG_FILE not set)'}",
            "",
            "## Notes",
            "- This file was created by `/report` for later debugging.",
            "- Correlate with logs using timestamp + chat/topic/message identifiers above.",
            "",
        ]
        report_path.write_text("\n".join(lines), encoding="utf-8")
        return report_path

    def _find_bound_message_id(
        self,
        *,
        session_id: str,
        jsonl_uuid: str,
        preferred_route: TelegramRoute | None = None,
    ) -> tuple[TelegramRoute, int] | None:
        matches = [
            (binding.route, message_id, binding.role)
            for (chat_id, message_id), binding in self._message_map.items()
            if chat_id == (preferred_route.chat_id if preferred_route else chat_id)
            and binding.session_id == session_id
            and binding.jsonl_uuid == jsonl_uuid
            and (preferred_route is None or binding.route == preferred_route)
        ]
        if not matches:
            matches = [
                (binding.route, message_id, binding.role)
                for (_chat_id, message_id), binding in self._message_map.items()
                if binding.session_id == session_id and binding.jsonl_uuid == jsonl_uuid
            ]
        if not matches:
            return None
        preferred = [
            item
            for item in matches
            if item[2] != "system" and not self._is_system_message_id(
                chat_id=item[0].chat_id,
                message_id=item[1],
            )
        ]
        chosen = preferred if preferred else matches
        route, message_id, _role = max(chosen, key=lambda item: item[1])
        return route, message_id

    def _next_topic_title(self, state: TelegramSessionState, explicit: str | None) -> str:
        _alias, title = self._next_topic_alias_and_title(state, explicit)
        return title

    @staticmethod
    def _looks_like_topic_emoji_token(token: str | None) -> bool:
        normalized = (token or "").strip()
        if not normalized:
            return False
        return not any(char.isalnum() for char in normalized)

    def _random_topic_title(self) -> str:
        left, right = random.sample(_RANDOM_TOPIC_WORDS, 2)
        return f"{left.title()} {right.title()}"

    async def _available_forum_topic_icons(self, bot) -> list[tuple[str, str]]:
        try:
            stickers = await bot.get_forum_topic_icon_stickers()
        except Exception:
            logger.debug("Failed loading forum topic icon stickers", exc_info=True)
            return []
        icons: list[tuple[str, str]] = []
        seen: set[str] = set()
        for sticker in stickers:
            emoji = str(getattr(sticker, "emoji", "") or "").strip()
            custom_emoji_id = str(getattr(sticker, "custom_emoji_id", "") or "").strip()
            if not emoji or not custom_emoji_id or custom_emoji_id in seen:
                continue
            seen.add(custom_emoji_id)
            icons.append((emoji, custom_emoji_id))
        return icons

    async def _resolve_new_topic_visibility(
        self,
        *,
        state: TelegramSessionState,
        bot,
        raw_args: str | None,
    ) -> tuple[str, str | None, str | None]:
        normalized_args = " ".join((raw_args or "").split()).strip()
        tokens = normalized_args.split() if normalized_args else []
        requested_emoji: str | None = None
        if tokens and self._looks_like_topic_emoji_token(tokens[0]):
            requested_emoji = tokens[0]
            tokens = tokens[1:]
        requested_title = normalize_lineage_name(" ".join(tokens))
        if not requested_title:
            requested_title = self._random_topic_title()

        current_icon = (
            state.topic_icon_custom_emoji_id
            or self._topic_metadata_for_route(state.route).icon_custom_emoji_id
        )
        available_icons = await self._available_forum_topic_icons(bot)
        emoji_to_id = {emoji: custom_id for emoji, custom_id in available_icons}
        chosen_emoji: str | None = None
        chosen_icon: str | None = None
        if requested_emoji and requested_emoji in emoji_to_id:
            chosen_emoji = requested_emoji
            chosen_icon = emoji_to_id[requested_emoji]
        else:
            choices = [(emoji, custom_id) for emoji, custom_id in available_icons if custom_id != current_icon]
            if not choices:
                choices = list(available_icons)
            if choices:
                chosen_emoji, chosen_icon = random.choice(choices)
        return requested_title, chosen_emoji, chosen_icon

    async def _apply_topic_visibility(
        self,
        *,
        route: TelegramRoute,
        bot,
        title: str,
        icon_custom_emoji_id: str | None,
    ) -> None:
        normalized_title = normalize_lineage_name(title) or self._default_topic_title(route)
        if route.thread_id is not None:
            try:
                await bot.edit_forum_topic(
                    chat_id=route.chat_id,
                    message_thread_id=route.thread_id,
                    name=normalized_title,
                    icon_custom_emoji_id=icon_custom_emoji_id,
                )
            except Exception:
                logger.warning(
                    "Failed editing forum topic route=%s title=%s icon=%s",
                    route,
                    normalized_title,
                    icon_custom_emoji_id,
                    exc_info=True,
                )
        self._set_topic_metadata(
            route=route,
            title=normalized_title,
            icon_custom_emoji_id=icon_custom_emoji_id,
        )

    def _update_topic_metadata_from_update(self, update: Update) -> None:
        if update.effective_message is None:
            return
        self._update_topic_metadata_from_message(update.effective_message)

    async def handle_forum_topic_created(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        _ = context
        self._update_topic_metadata_from_update(update)

    async def handle_forum_topic_edited(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        _ = context
        self._update_topic_metadata_from_update(update)

    async def _maybe_finalize_joined_allowed_user(
        self,
        *,
        chat_id: int,
        joined_user_id: int,
        joined_username: str | None,
    ) -> bool:
        if chat_id >= 0:
            return False
        provisioner = self._build_userbot_provisioner()
        try:
            left = await provisioner.finalize_joined_allowed_user(
                chat_id=chat_id,
                joined_user_id=joined_user_id,
                joined_username=joined_username,
            )
        except Exception:
            logger.exception(
                "Failed finalizing joined allowed user chat_id=%s joined_user_id=%s",
                chat_id,
                joined_user_id,
            )
            return False
        if left:
            logger.info(
                "Userbot left chat_id=%s after allowed user_id=%s joined",
                chat_id,
                joined_user_id,
            )
        return left

    async def handle_new_chat_members(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        _ = context
        if update.effective_message is None:
            return
        message = update.effective_message
        joined_members = list(getattr(message, "new_chat_members", []) or [])
        if not joined_members:
            return
        joined_allowed_user = next(
            (
                member
                for member in joined_members
                if isinstance(getattr(member, "id", None), int) and self._is_authorized(int(member.id))
            ),
            None,
        )
        if joined_allowed_user is None:
            return

        await self._maybe_finalize_joined_allowed_user(
            chat_id=message.chat_id,
            joined_user_id=int(joined_allowed_user.id),
            joined_username=self._coerce_username(joined_allowed_user),
        )

    async def _drop_route_state(
        self,
        route: TelegramRoute,
        *,
        terminal_status: str | None = None,
    ) -> None:
        flush_task = self._observability_flush_tasks.pop(route, None)
        if flush_task is not None and not flush_task.done():
            flush_task.cancel()
        self._observability_buffer.pop(route, None)
        if terminal_status:
            self._mark_task_terminal_request(route, terminal_status)
            await self._cancel_route_fork_tasks(route, status=terminal_status)
            self._sweep_route_team_worker_mappings(
                route,
                terminal_status=terminal_status,
            )
        stale_session_ids = [
            session_id
            for session_id, mapped_route in self._route_by_session_id.items()
            if mapped_route == route
        ]
        # Track dropped agent names so collision detection allows respawn
        inbox_key = self._route_inbox_target_keys_by_route.get(route)
        self._remove_route_inbox_target(route)
        state = self._states_by_route.pop(route, None)
        self._route_locks.pop(route, None)
        self._prune_bindings_for_route(route)
        self._topic_metadata_by_route.pop(route, None)
        self._delete_topic_schedules_for_route(route)
        self._state_store.delete_route_state(
            chat_id=route.chat_id,
            thread_id=route.thread_id,
        )
        if state is None:
            return
        if state.session_id:
            stale_session_ids.append(state.session_id)
        self._unbind_route_sessions(route)
        for session_id in stale_session_ids:
            self._session_heads.pop(session_id, None)
            self._state_store.delete_session_head(session_id=session_id)
        try:
            await state.session_manager.disconnect()
        finally:
            state.hook_state.reset()

    # CACHE-PREFIX WARNING: AgentTask fork=true children start from a byte copy of the
    # parent's JSONL (fork_session_jsonl). The child's first request must be an
    # append of the parent's last request; child-only tools/env/system differences
    # invalidate the whole shared prefix.
    # A break is silent: no error, the API just re-bills the whole conversation.
    # Live check: scripts/cache_regression.py parallel_fork recovery (docs/cache-proxy-safety.md).
    async def _create_child_fork_topic(
        self,
        *,
        parent_state: TelegramSessionState,
        bot,
        source_session_id: str | None,
        source_uuid: str | None,
        source_route: TelegramRoute,
        source_message_id: int | None,
        topic_name: str,
        child_service_html: str,
        source_jsonl_path: Path | None = None,
        notify_on_completion: bool,
        is_fork: bool = True,
        team_name: str | None = None,
        agent_name: str | None = None,
        lineage_name: str | None = None,
        lineage_origin: str | None = None,
        model: str | None = None,
        effort: str | None = None,
        inherit_schedules: bool = True,
        env_override: dict[str, str] | None = None,
        temperature: float | None = None,
        user_hooks: dict[str, str] | None = None,
        inherit_hooks: bool = False,
        launcher_lineage: bool = False,
    ) -> dict[str, Any]:
        from obs_agent.effort import child_effort_override, build_effort_env, resolve_effort

        child_model = resolve_model(model) if model else parent_state.session_manager.effective_model
        if model:
            # A Spark alias for a model the Sparks are not serving (or a window
            # larger than the serving profile) fails here with a clear message,
            # before any topic or JSONL fork exists. Fails open if unreachable.
            from obs_agent.spark import check_spark_available, is_spark_model

            if is_spark_model(child_model):
                await asyncio.to_thread(
                    check_spark_available, child_model, parse_context_suffix(child_model)[1]
                )
        selected_effort = child_effort_override(
            effort, parent_effort=parent_state.session_manager.effective_effort,
            model=model, session_env=env_override,
        )
        new_effort = getattr(self._config, "new_session_effort_level", None)
        if (
            new_effort
            and not is_fork
            and (effort is None or not str(effort).strip())
            and not (env_override or {}).get("CLAUDE_CODE_EFFORT_LEVEL")
        ):
            # Fresh sessions share no prompt cache with the parent, so they take
            # the new-session default; forks keep inheriting (cache key).
            selected_effort = new_effort
        # Check malformed extra-body JSON before creating the topic or forking JSONL.
        build_effort_env(child_model, resolve_effort(
            child_model, override=selected_effort,
            configured=self._config.effort_level,
            model_defaults=self._config.model_effort_levels,
            environ=os.environ, session_env=env_override,
        ), {**os.environ, **(env_override or {})})
        if is_fork:
            if not source_session_id or not source_uuid:
                raise RuntimeError("Cannot create fork child topic: source session head is unavailable")
            if source_jsonl_path is not None:
                safe_target = resolve_safe_jsonl_target(
                    session_id=source_session_id,
                    cwd=self._config.vault_path,
                    preferred_uuid=source_uuid,
                    source_path=source_jsonl_path,
                )
                safe_uuid = safe_target.target_uuid if safe_target is not None else source_uuid
            else:
                safe_uuid, _health = self._resolve_safe_jsonl_target(
                    session_id=source_session_id,
                    preferred_uuid=source_uuid,
                    purpose="create_child_fork",
                )
            if not safe_uuid:
                raise RuntimeError("Cannot create fork child topic: source session has no safe JSONL head")
            source_uuid = safe_uuid
            child_session_id = fork_session_jsonl(
                session_id=source_session_id,
                target_uuid=source_uuid,
                cwd=self._config.vault_path,
                source_path=source_jsonl_path,
                new_session_id=str(uuid.uuid4()),
            )
            self._set_session_head(
                session_id=child_session_id,
                jsonl_uuid=source_uuid,
            )
        else:
            child_session_id = ""
        parent_icon = (
            parent_state.topic_icon_custom_emoji_id
            or self._topic_metadata_for_route(parent_state.route).icon_custom_emoji_id
        )

        forum_topic = await self._enqueue_create_topic(
            route=TelegramRoute(chat_id=parent_state.route.chat_id, thread_id=None),
            topic_name=topic_name,
            icon_custom_emoji_id=parent_icon,
            fallback_bot=bot,
            priority=_PRIORITY_SYSTEM,
        )
        thread_id = getattr(forum_topic, "message_thread_id", None)
        if not isinstance(thread_id, int):
            raise RuntimeError("create_forum_topic returned no message_thread_id")
        raw_child_icon = getattr(forum_topic, "icon_custom_emoji_id", None)
        child_icon = (
            raw_child_icon.strip()
            if isinstance(raw_child_icon, str) and raw_child_icon.strip()
            else parent_icon
        )

        child_route = TelegramRoute(chat_id=parent_state.route.chat_id, thread_id=thread_id)
        child_state = self._get_state(
            child_route,
            topic_title=topic_name,
            apply_default_new_chat_hooks=False,
        )
        assert child_state is not None
        child_state.topic_title = topic_name
        child_state.topic_icon_custom_emoji_id = child_icon
        child_state.last_bot = bot
        child_state.warning_sent = False
        child_state.notify_on_completion = notify_on_completion
        self._set_topic_metadata(
            route=child_route,
            title=topic_name,
            icon_custom_emoji_id=child_icon,
        )
        if inherit_schedules:
            self._inherit_topic_schedules(
                parent_route=parent_state.route,
                child_route=child_route,
                is_fork=is_fork,
            )
        child_lineage: tuple[str, ...] | None = None
        normalized_lineage_name = normalize_lineage_name(lineage_name)
        if normalized_lineage_name:
            parent_lineage = self._ensure_state_lineage(
                parent_state,
                # A fork of a foreign session_source belongs under the LAUNCHER in the tree,
                # never under the source session's own lineage.
                session_id=(parent_state.session_id if launcher_lineage else None)
                or source_session_id
                or parent_state.session_id,
            )
            child_lineage = parent_lineage + (normalized_lineage_name,)
            # Children inherit the parent's root_team_key — only trunk generates
            # a new timestamp-based key. The agent_name is always computed fresh.
            default_agent_name = agent_name_for_lineage(child_lineage)
            parent_team_key = self._get_parent_team_key(parent_state)
            team_name = (team_name or "").strip() or parent_team_key or root_team_key_for_lineage(child_lineage)
            agent_name = (agent_name or "").strip() or default_agent_name
            if not (team_name or "").strip():
                team_name = root_team_key_for_lineage(child_lineage)
            if not _SAFE_AGENT_IDENTITY_RE.fullmatch(agent_name.lower()):
                raise ValueError("agent_name must be hash-prefixed stable identity")
            # Collision detection is based on current bindings, not merely on
            # inbox-file existence. Deleted topics intentionally leave inbox
            # files behind so backlog can survive until the same identity is
            # respawned.
            is_auto_generated = bool(
                re.match(r"^F\d+$", normalized_lineage_name, re.IGNORECASE)
            )
            if team_name and agent_name:
                inbox_path = (
                    Path.home() / ".claude" / "teams" / team_name
                    / "inboxes" / f"{agent_name}.json"
                )
                agent_key = self._team_worker_key(team_name, agent_name)
                projection_is_bound = False
                if agent_key is not None:
                    projection_is_bound = (
                        self._resolve_route_inbox_target(
                            team_name=team_name,
                            agent_name=agent_name,
                        ) is not None
                        or self._resolve_team_worker_record(
                            team_name=team_name,
                            agent_name=agent_name,
                        ) is not None
                    )
                if inbox_path.exists() and projection_is_bound:
                    if is_auto_generated:
                        # Auto-increment: try F2, F3, ... until we find a free name
                        counter = int(normalized_lineage_name[1:])
                        for attempt in range(100):
                            counter += 1
                            candidate_name = f"F{counter}"
                            candidate_lineage = parent_lineage + (candidate_name,)
                            _, candidate_agent = self._default_team_projection(candidate_lineage)
                            candidate_inbox = (
                                Path.home() / ".claude" / "teams" / team_name
                                / "inboxes" / f"{candidate_agent}.json"
                            )
                            candidate_bound = (
                                self._resolve_route_inbox_target(
                                    team_name=team_name,
                                    agent_name=candidate_agent,
                                ) is not None
                                or self._resolve_team_worker_record(
                                    team_name=team_name,
                                    agent_name=candidate_agent,
                                ) is not None
                            )
                            if not candidate_inbox.exists() or not candidate_bound:
                                # Found a free name — update everything
                                normalized_lineage_name = candidate_name
                                child_lineage = candidate_lineage
                                agent_name = candidate_agent
                                # Update the parent's fork counter so next auto-gen starts from here
                                parent_state.child_fork_count = counter
                                self._persist_state_for_route(parent_state.route)
                                break
                        else:
                            raise RuntimeError(
                                f"Agent name collision: could not find a free auto-generated name "
                                f"after 100 attempts in team '{team_name}'."
                            )
                    else:
                        raise RuntimeError(
                            f"Agent name collision: '{agent_name}' already exists in team '{team_name}'. "
                            f"Choose a different name for this child agent."
                        )
        # Clear dropped key if name is being reused (respawn)
        await self._activate_route_session(child_state, child_session_id or None)
        team_env = self._build_team_worker_env(
            team_name=team_name,
            agent_name=agent_name,
        )
        # Merge user-provided env overrides (from AgentTask env parameter)
        if env_override:
            team_env.update(env_override)
        # Temperature takes precedence over thinking, but preserve unrelated fields.
        if temperature is not None:
            from obs_agent.effort import parse_extra_body

            body = parse_extra_body(team_env.get("CLAUDE_CODE_EXTRA_BODY"))
            body.update({"temperature": temperature, "thinking": {"type": "disabled"}})
            team_env["CLAUDE_CODE_EXTRA_BODY"] = json.dumps(body)
        base_team_env = self._build_team_worker_env(
            team_name=team_name,
            agent_name=agent_name,
        )
        child_state.session_manager.explicit_env_overrides = {
            key: value for key, value in team_env.items() if base_team_env.get(key) != value
        } or None
        child_state.session_manager.set_sdk_env_overrides(team_env)
        # Apply per-session model override. resolve_model handles shorthand
        # lookup and context suffix preservation. _build_options in session.py
        # picks up model_override and injects the right env vars (context window,
        # compaction threshold, API key) for non-Claude models. When no explicit
        # model is provided, inherit the parent's effective model instead of
        # falling back to the shared config default.
        child_state.session_manager.model_override = child_model
        child_state.session_manager.effort_override = selected_effort
        # --- User hooks ---
        # Resolve effective hooks: explicit hooks take precedence, then
        # inheritance from the parent if inherit_hooks is True.
        effective_hooks = user_hooks
        if not effective_hooks and inherit_hooks:
            effective_hooks = parent_state.session_manager.user_hooks
        child_state.session_manager.user_hooks = effective_hooks
        if child_lineage is not None:
            self._prime_obs_bootstrap(
                child_state,
                lineage=child_lineage,
                origin=lineage_origin or ("user_fork" if is_fork else "agent_task_fresh"),
                is_fork=is_fork,
                parent_session_id=source_session_id,
                team_name=team_name,
                agent_name=agent_name,
                session_id=child_session_id or None,
            )

        source_link = (
            self._build_message_link(source_route, source_message_id)
            if source_message_id is not None
            else None
        )
        styled_service_html = self._underline_first_nonempty_line_html(child_service_html)
        # obs-54: the topic exists from here on; a failed notice must not abort
        # the launch and leave the topic empty with no task behind it.
        service_messages = await self._send_task_launch_notice(
            route=child_route,
            bot=bot,
            html_text=styled_service_html,
            underline=False,
            purpose="child service message",
        )
        service_message_id = self._sent_message_id(service_messages[0]) if service_messages else None
        if service_message_id is not None:
            if source_uuid is not None and child_session_id:
                self._record_message_binding(
                    route=child_route,
                    message_id=service_message_id,
                    jsonl_uuid=source_uuid,
                    session_id=child_session_id,
                    role="assistant",
                )
        session_marker_id: int | None = None
        session_marker_text = (
            f"session forked: {child_session_id}"
            if is_fork
            else "fresh session will be assigned on first turn"
        )
        try:
            session_marker = await self._send_system_message(
                route=child_route,
                bot=bot,
                text=session_marker_text,
                disable_notification=True,
                # obs-54: best-effort like the notices; unbounded retries held
                # the launch here for as long as Telegram stayed unreachable.
                max_attempts=_TASK_LAUNCH_SEND_MAX_ATTEMPTS,
            )
            session_marker_id = self._sent_message_id(session_marker)
            if session_marker_id is not None:
                if source_uuid is not None and child_session_id:
                    self._record_message_binding(
                        route=child_route,
                        message_id=session_marker_id,
                        jsonl_uuid=source_uuid,
                        session_id=child_session_id,
                        role="assistant",
                    )
        except Exception:
            logger.debug("Failed sending fork session marker route=%s", child_route, exc_info=True)
        child_link = (
            self._build_message_link(child_route, service_message_id)
            if service_message_id is not None
            else None
        )
        return {
            "child_route": child_route,
            "child_state": child_state,
            "child_session_id": child_session_id,
            "child_link": child_link,
            "child_service_message_id": service_message_id,
            "child_session_marker_message_id": session_marker_id,
            "source_link": source_link,
            "team_name": team_name,
            "agent_name": agent_name,
            "child_lineage": child_lineage,
        }

    def _build_fork_task_child_service_html(
        self,
        *,
        agent_id: str,
        description: str | None,
        prompt: str,
        source_link: str | None,
        max_turns: int | None = None,
        is_fork: bool = True,
        team_name: str | None = None,
        agent_name: str | None = None,
        prompt_file: str | None = None,
        prompt_file_content: str | None = None,
    ) -> str:
        lines = ["fork task launched by agent" if is_fork else "agent task launched by agent"]
        lines.append(
            html.escape(
                f"<fork_context><is_fork>{str(is_fork).lower()}</is_fork><agent_id>{agent_id}</agent_id></fork_context>"
            )
        )
        if source_link:
            lines.append(
                f'forked from <a href="{html.escape(source_link)}">source message</a>'
            )
        lines.append(f"agentId: {html.escape(agent_id)}")
        if description:
            lines.append(f"description: {html.escape(description)}")
        if team_name:
            lines.append(f"team_name: {html.escape(team_name)}")
        if agent_name:
            lines.append(f"agent_name: {html.escape(agent_name)}")
        if max_turns is not None:
            lines.append(f"max_turns: {max_turns}")
        if prompt_file:
            lines.append(f"prompt_file: {html.escape(prompt_file)}")
        if prompt:
            lines.append("prompt:")
            lines.append(html.escape(prompt))
        return "\n".join(lines)

    def _read_schedule_prompt_file(self, prompt_file: str) -> str:
        """Read a schedule prompt file (vault-relative, absolute or ~). Raises OSError."""
        path = Path(prompt_file)
        if prompt_file.startswith("~"):
            path = path.expanduser()
        elif not path.is_absolute():
            path = Path(self._config.vault_path) / path
        return path.read_text(encoding="utf-8").strip()

    def _compose_schedule_prompt(self, record: "_TopicScheduleRecord") -> str:
        """vault-wlh: inline prompt first, then the prompt file read at THIS fire.

        Raises ScheduledPromptFileError when the file cannot be read, so the fire
        fails visibly instead of sending an empty or stale prompt.
        """
        if not record.prompt_file:
            return record.prompt
        try:
            content = self._read_schedule_prompt_file(record.prompt_file)
        except OSError as exc:
            raise ScheduledPromptFileError(
                f"schedule prompt_file unreadable: {record.prompt_file}: {exc}"
            ) from exc
        file_block = "\n".join(
            [
                f'<schedule_prompt_file path="{html.escape(record.prompt_file)}">',
                content,
                "</schedule_prompt_file>",
            ]
        )
        if record.prompt:
            return f"{record.prompt}\n\n{file_block}"
        return file_block

    @staticmethod
    def _compose_prompt_file_context(
        *,
        prompt: str,
        prompt_file: str | None,
        prompt_file_content: str | None,
    ) -> str:
        if not prompt_file_content:
            return prompt
        file_block = "\n".join(
            [
                f'<prompt_file_context path="{html.escape(prompt_file or "")}">',
                html.escape(prompt_file_content),
                "</prompt_file_context>",
            ]
        )
        if prompt:
            return f"{file_block}\n\n{prompt}"
        return file_block

    def _build_fork_task_launch_text(
        self,
        *,
        task_id: str,
        output_file: str | None,
        topic_link: str | None,
        task_label: str,
        agent_name: str | None = None,
        team_name: str | None = None,
        lineage: tuple[str, ...] = (),
        session_id: str | None = None,
    ) -> str:
        lines = [f"{task_label} launched."]
        if team_name:
            lines.append(f"team_name: {team_name}")
        if agent_name:
            lines.append(f"agent_name: {agent_name}")
        lines.append(f"lineage: {' / '.join(lineage) if lineage else '<unavailable>'}")
        if session_id:
            lines.append(f"session_id: {session_id}")
        else:
            lines.append("session_id: pending until the child session starts")
        lines.append(f"task_id (deprecated/internal compatibility): {task_id}")
        lines.append(f"agentId: {task_id}")
        lines.append("task_id_scope: deprecated/internal")
        lines.append("Working in the background; completion will be posted here.")
        if output_file:
            lines.append(f"output_file (trusted internal record-derived): {output_file}")
        if topic_link:
            lines.append(f"telegram_topic: {topic_link}")
        return "\n".join(lines)

    def _build_super_task_lifecycle_html(
        self,
        *,
        record: _ForkTaskRecord,
        phase: str,
        elapsed_seconds: float | None = None,
        idle_seconds: float | None = None,
    ) -> str:
        heading = self._format_system_html(f"notification: agent task {phase}")
        body_lines = [f"agentId: {record.task_id}"]
        if record.description:
            body_lines.append(f"description: {record.description}")
        if elapsed_seconds is not None:
            body_lines.append(f"elapsed_s: {max(int(elapsed_seconds), 0)}")
        if idle_seconds is not None:
            body_lines.append(f"idle_for_s: {max(int(idle_seconds), 0)}")
        body_html = "\n".join(self._format_status_html(line) for line in body_lines)
        return "\n".join([heading, body_html]).strip()

    async def _send_super_task_lifecycle_notification(
        self,
        *,
        record: _ForkTaskRecord,
        parent_state: TelegramSessionState | None,
        phase: str,
        elapsed_seconds: float | None = None,
        idle_seconds: float | None = None,
    ) -> None:
        if phase in {"running", "idle"}:
            return
        if record.is_fork:
            return
        if parent_state is None or parent_state.last_bot is None:
            return
        html_text = self._build_super_task_lifecycle_html(
            record=record,
            phase=phase,
            elapsed_seconds=elapsed_seconds,
            idle_seconds=idle_seconds,
        )
        try:
            sent_messages = await self._send_html(
                route=record.parent_route,
                bot=parent_state.last_bot,
                html_text=html_text,
                disable_notification=True,
                reply_to_message_id=self._reply_anchor(record.launch_parent_message_id),
                priority=_PRIORITY_SYSTEM,
            )
            self._remember_system_message_ids(route=record.parent_route, sent_messages=sent_messages)
        except Exception:
            logger.debug(
                "Failed sending AgentTask lifecycle notification task_id=%s phase=%s",
                record.task_id,
                phase,
                exc_info=True,
            )

    async def _monitor_super_task_lifecycle(
        self,
        *,
        record: _ForkTaskRecord,
        child_state: TelegramSessionState,
        parent_state: TelegramSessionState | None,
    ) -> None:
        if record.is_fork:
            return
        if parent_state is None or parent_state.last_bot is None:
            return
        now = time.time()
        last_activity = child_state.session_manager.last_activity or now
        await self._send_super_task_lifecycle_notification(
            record=record,
            parent_state=parent_state,
            phase="running",
            elapsed_seconds=0.0,
        )
        idle_reported = False
        while True:
            await asyncio.sleep(self._super_task_monitor_tick_seconds)
            task = self._fork_task_tasks.get(record.task_id)
            if task is None or task.done():
                return
            now = time.time()
            current_activity = child_state.session_manager.last_activity or last_activity
            if current_activity > last_activity:
                last_activity = current_activity
                if idle_reported:
                    await self._send_super_task_lifecycle_notification(
                        record=record,
                        parent_state=parent_state,
                        phase="running",
                        elapsed_seconds=now - record.created_at,
                    )
                    idle_reported = False
                    continue
            if (
                not idle_reported
                and (now - last_activity) >= self._super_task_idle_seconds
            ):
                await self._send_super_task_lifecycle_notification(
                    record=record,
                    parent_state=parent_state,
                    phase="idle",
                    elapsed_seconds=now - record.created_at,
                    idle_seconds=now - last_activity,
                )
                idle_reported = True
                continue

    def _build_idle_team_worker_prompt(
        self,
        *,
        team_name: str,
        agent_name: str,
        sender: str | None,
        summary: str | None,
        content: str | None,
    ) -> str:
        lines = [
            "(System: New teammate messages arrived while you were idle.)",
            f"Use ReadInbox with team_name={team_name}, agent={agent_name}, include_read=false, mark_read=true, limit=50.",
            "Process all unread teammate messages and continue team work.",
            "If needed, reply to teammates with SendInboxMessage.",
        ]
        sender_norm = (sender or "").strip()
        summary_norm = (summary or "").strip()
        content_norm = (content or "").strip()
        if sender_norm:
            lines.append(f"Latest sender: {sender_norm}.")
        if summary_norm:
            lines.append(f"Latest summary: {summary_norm}.")
        if content_norm:
            preview = content_norm if len(content_norm) <= 240 else f"{content_norm[:240]}..."
            lines.append(f"Latest content preview: {preview}")
        return "\n".join(lines)

    def _build_running_team_worker_prompt(
        self,
        *,
        team_name: str,
        agent_name: str,
        sender: str | None,
        summary: str | None,
        content: str | None,
    ) -> str:
        lines = [
            "(System notification: New teammate messages arrived while you were still running.)",
            f"At the next convenient opportunity, call ReadInbox with team_name={team_name}, agent={agent_name}, include_read=false, mark_read=true, limit=50.",
            "Process all unread teammate messages before you finish the current task if practical.",
            "If needed, reply to teammates with SendInboxMessage.",
        ]
        sender_norm = (sender or "").strip()
        summary_norm = (summary or "").strip()
        content_norm = (content or "").strip()
        if sender_norm:
            lines.append(f"Latest sender: {sender_norm}.")
        if summary_norm:
            lines.append(f"Latest summary: {summary_norm}.")
        if content_norm:
            preview = content_norm if len(content_norm) <= 240 else f"{content_norm[:240]}..."
            lines.append(f"Latest content preview: {preview}")
        return "\n".join(lines)

    def _queue_running_team_worker_notice(
        self,
        *,
        state: TelegramSessionState,
        team_name: str,
        agent_name: str,
        sender: str | None,
        summary: str | None,
        content: str | None,
    ) -> None:
        # A teammate message sent to a stopped agent is new input: it wakes the
        # agent once the stopped turn has ended (agents are idle, not dead).
        self._clear_stop_latch(state, "inbox_message")
        notice = QueuedMessage(
            text=self._build_running_team_worker_prompt(
                team_name=team_name,
                agent_name=agent_name,
                sender=sender,
                summary=summary,
                content=content,
            )
        )
        if state.busy and state.hook_state.stop_requested_at is not None:
            # The stopped turn discards its leftover queue when it ends; keep
            # this later notice out of that discard.
            state.hook_state.post_stop_messages.append(notice)
            return
        state.hook_state.message_queue.put_nowait(notice)

    @staticmethod
    def _team_inbox_path(team_name: str, agent_name: str) -> Path:
        return Path.home() / ".claude" / "teams" / team_name / "inboxes" / f"{agent_name}.json"

    async def _send_bounce_backs_for_dead_agent(self, route: TelegramRoute) -> None:
        """Notify senders of a dead agent that their messages may not have been read.

        Scans the dead agent's inbox for unread messages, sends a bounce-back
        to each unique sender, and voids any must_reply obligations.
        """
        # Find team_name and agent_name for this route
        dead_team: str | None = None
        dead_agent: str | None = None
        for record in self._fork_tasks_by_id.values():
            if record.child_route == route:
                dead_team = (record.team_name or "").strip() or None
                dead_agent = (record.agent_name or "").strip() or None
                break
        if not dead_team or not dead_agent:
            # Also check route_inbox_targets (for trunk agents)
            for (team, agent), target_route in list(self._route_inbox_targets.items()):
                if target_route == route:
                    dead_team, dead_agent = team, agent
                    break
        if not dead_team or not dead_agent:
            logger.debug("Cannot send bounce-backs — no team/agent mapping for route=%s", route)
            return

        inbox_path = self._team_inbox_path(dead_team, dead_agent)
        if not inbox_path.exists():
            return

        try:
            entries = json.loads(inbox_path.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed reading dead agent inbox for bounce-back: %s", inbox_path, exc_info=True)
            return

        if not isinstance(entries, list):
            return

        # Collect unique senders with unread messages
        senders_to_notify: set[str] = set()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            if entry.get("read", False):
                continue
            sender = str(entry.get("from") or "").strip()
            if sender and sender != "system":
                senders_to_notify.add(sender)
            # Void must_reply obligations
            if entry.get("must_reply") and not entry.get("replied"):
                entry["replied"] = True

        # Write back the voided must_reply flags
        try:
            inbox_path.write_text(json.dumps(entries, ensure_ascii=True), encoding="utf-8")
        except Exception:
            logger.debug("Failed writing voided must_reply flags: %s", inbox_path, exc_info=True)

        # Delete reply_wake schedules for this route
        reply_wake_id = f"reply-wake-{route.chat_id}-{route.thread_id or 'general'}"
        existing = self._topic_schedules_by_id.get(reply_wake_id)
        if existing is not None:
            self._delete_topic_schedule(reply_wake_id)

        # Send bounce-back to each unique sender
        for sender_name in senders_to_notify:
            sender_inbox = self._team_inbox_path(dead_team, sender_name)
            sender_inbox.parent.mkdir(parents=True, exist_ok=True)
            bounce_msg = {
                "from": "system",
                "text": (
                    f"Agent {dead_agent} is no longer available — topic was deleted. "
                    f"Your message may not have been read."
                ),
                "summary": "agent dead — message undeliverable",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "read": False,
                "must_reply": False,
                "replied": False,
            }
            try:
                sender_entries: list = []
                if sender_inbox.exists():
                    sender_entries = json.loads(sender_inbox.read_text(encoding="utf-8"))
                    if not isinstance(sender_entries, list):
                        sender_entries = []
                sender_entries.append(bounce_msg)
                sender_inbox.write_text(json.dumps(sender_entries, ensure_ascii=True), encoding="utf-8")
                logger.info(
                    "Sent bounce-back to %s: agent %s is dead (topic deleted)",
                    sender_name,
                    dead_agent,
                )
            except Exception:
                logger.debug(
                    "Failed sending bounce-back to %s for dead agent %s",
                    sender_name,
                    dead_agent,
                    exc_info=True,
                )

    def _latest_unread_sender_team(self, *, team_name: str, agent_name: str) -> str | None:
        """vault-5lko: the latest unread message's sender team, when recorded."""
        inbox_path = self._team_inbox_path(team_name, agent_name)
        try:
            entries = json.loads(inbox_path.read_text(encoding="utf-8"))
        except Exception:
            return None
        if not isinstance(entries, list):
            return None
        for item in reversed(entries):
            if isinstance(item, dict) and not bool(item.get("read", False)):
                return str(item.get("from_team") or "").strip() or None
        return None

    def _cached_latest_unread_team_inbox_message(
        self,
        *,
        team_name: str,
        agent_name: str,
    ) -> tuple[str | None, str | None, str | None] | None:
        """``_latest_unread_team_inbox_message``, reused while the inbox file is unchanged.

        obs-54: the wake poller asks for every team worker and route inbox
        (~19k on 2026-10-25) every 3 s, and reading and parsing each file
        blocked the event loop. The answer is a function of the file bytes and
        the wake floor, so it is reused while the file's identity (device,
        inode, size, mtime, ctime) is unchanged. Any write, and any utime that
        restores an old mtime, sets ctime to the current time, which userspace
        cannot set back. The answer is stored only for a file whose last
        change (the later of mtime and ctime) is more than
        ``_INBOX_CACHE_SETTLE_SECONDS`` old when it is read, so a later write
        gets a later timestamp even on a coarse filesystem clock.
        """
        inbox_path = self._team_inbox_path(team_name, agent_name)
        try:
            st = inbox_path.stat()
        except OSError:
            self._inbox_latest_cache.pop(inbox_path, None)
            return None
        identity = (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
        floor = self._inbox_wake_floor
        cached = self._inbox_latest_cache.get(inbox_path)
        if cached is not None and cached[0] == identity and cached[1] == floor:
            return cached[2]
        settled = time.time() - max(st.st_mtime, st.st_ctime) > _INBOX_CACHE_SETTLE_SECONDS
        result = self._latest_unread_team_inbox_message(team_name=team_name, agent_name=agent_name)
        try:
            after = inbox_path.stat()
        except OSError:
            after = None
        if settled and after is not None and (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns,
        ) == identity:
            self._inbox_latest_cache[inbox_path] = (identity, floor, result)
        else:
            self._inbox_latest_cache.pop(inbox_path, None)
        return result

    def _latest_unread_team_inbox_message(
        self,
        *,
        team_name: str,
        agent_name: str,
    ) -> tuple[str | None, str | None, str | None] | None:
        inbox_path = self._team_inbox_path(team_name, agent_name)
        if not inbox_path.exists():
            return None
        try:
            loaded = json.loads(inbox_path.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed reading team inbox for wake poll: %s", inbox_path, exc_info=True)
            return None
        if not isinstance(loaded, list):
            return None
        latest_unread: dict[str, Any] | None = None
        for item in loaded:
            if not isinstance(item, dict):
                continue
            if bool(item.get("read", False)):
                continue
            message_ts = self._try_parse_rfc3339_timestamp(item.get("timestamp"))
            if message_ts is None or message_ts < self._inbox_wake_floor:
                continue
            # Skip must_reply messages that have already been replied to —
            # otherwise the poller keeps nagging for them indefinitely.
            if item.get("must_reply") and item.get("replied"):
                continue
            latest_unread = item
        if latest_unread is None:
            return None
        sender = str(latest_unread.get("from") or "").strip() or None
        summary = str(latest_unread.get("summary") or "").strip() or None
        content = (
            str(
                latest_unread.get("text")
                or latest_unread.get("content")
                or ""
            ).strip()
            or None
        )
        return sender, summary, content

    async def _poll_team_worker_inbox_wakes(self) -> None:
        handled_keys: set[tuple[str, str]] = set()
        task_ids = list(dict.fromkeys(self._team_worker_records.values()))
        for index, task_id in enumerate(task_ids):
            if index and index % _LOOP_YIELD_EVERY == 0:
                # obs-54: ~19k inboxes per sweep; let other topics run between batches.
                await asyncio.sleep(0)
            record = self._fork_tasks_by_id.get(task_id)
            if record is None:
                self._remove_team_worker_mappings_for_task(task_id)
                continue
            # Don't skip based on status — always try to deliver.
            # If the agent is truly dead, _handle_inbox_message_notification
            # will catch the error and send bounce-backs.
            team_name = (record.team_name or "").strip()
            agent_name = (record.agent_name or "").strip()
            if not team_name or not agent_name:
                continue
            handled_keys.add((team_name, agent_name))
            latest = self._cached_latest_unread_team_inbox_message(
                team_name=team_name,
                agent_name=agent_name,
            )
            if latest is None:
                continue
            sender, summary, content = latest
            fingerprint = f"{sender}:{summary}:{content}"[:200]
            dedup_key = (team_name, agent_name, fingerprint)
            if dedup_key in self._notified_inbox_keys:
                continue
            self._notified_inbox_keys.add(dedup_key)
            await self._handle_inbox_message_notification(
                sender_route=record.child_route,
                payload={
                    "team_name": team_name,
                    "recipient": agent_name,
                    "sender": sender,
                    "sender_team": self._latest_unread_sender_team(
                        team_name=team_name, agent_name=agent_name
                    ),
                    "summary": summary,
                    "content": content,
                },
            )
        for index, (key, route) in enumerate(list(self._route_inbox_targets.items())):
            if index and index % _LOOP_YIELD_EVERY == 0:
                await asyncio.sleep(0)
            if key in handled_keys:
                continue
            state = self._get_state(route, create=False)
            if state is None:
                self._remove_route_inbox_target(route)
                continue
            latest = self._cached_latest_unread_team_inbox_message(
                team_name=key[0],
                agent_name=key[1],
            )
            if latest is None:
                continue
            sender, summary, content = latest
            fingerprint = f"{sender}:{summary}:{content}"[:200]
            dedup_key = (key[0], key[1], fingerprint)
            if dedup_key in self._notified_inbox_keys:
                continue
            self._notified_inbox_keys.add(dedup_key)
            await self._handle_inbox_message_notification(
                sender_route=route,
                payload={
                    "team_name": key[0],
                    "recipient": key[1],
                    "sender": sender,
                    "sender_team": self._latest_unread_sender_team(
                        team_name=key[0], agent_name=key[1]
                    ),
                    "summary": summary,
                    "content": content,
                },
            )

    async def _start_idle_team_worker_wake(
        self,
        *,
        record: _ForkTaskRecord,
        sender: str | None,
        summary: str | None,
        content: str | None,
    ) -> None:
        team_name = (record.team_name or "").strip()
        agent_name = (record.agent_name or "").strip()
        if not team_name or not agent_name:
            raise RuntimeError(
                f"Cannot wake team worker: missing team_name={team_name!r} or agent_name={agent_name!r}"
            )
        child_state = self._get_state(record.child_route, create=False)
        if child_state is None:
            raise RuntimeError(
                f"Cannot wake team worker {agent_name}: child_state is None for route={record.child_route}"
            )
        bot = self._bot_for_state(child_state)
        if bot is None:
            raise RuntimeError(
                f"Cannot wake team worker {agent_name}: no bot available for route={record.child_route}"
            )
        child_state.last_bot = bot

        sender_norm = (sender or "").strip() or None
        summary_norm = (summary or "").strip() or None
        content_norm = (content or "").strip() or None
        wake_html_lines = ["agent task wake: teammate message received"]
        wake_html_lines.append(f"team_name: {html.escape(team_name)}")
        wake_html_lines.append(f"agent_name: {html.escape(agent_name)}")
        if sender_norm:
            wake_html_lines.append(f"from: {html.escape(sender_norm)}")
        if summary_norm:
            wake_html_lines.append(f"summary: {html.escape(summary_norm)}")
        wake_messages = await self._send_system_html_message(
            route=record.child_route,
            bot=bot,
            html_text="\n".join(wake_html_lines),
            disable_notification=True,
            underline=False,
        )
        wake_message_id = self._sent_message_id(wake_messages[0]) if wake_messages else None
        wake_prompt = self._build_idle_team_worker_prompt(
            team_name=team_name,
            agent_name=agent_name,
            sender=sender_norm,
            summary=summary_norm,
            content=content_norm,
        )

        current_child_session_id = (child_state.session_id or "").strip() or record.child_session_id
        if current_child_session_id:
            record.child_session_id = current_child_session_id
        # vault-u3b.35: a child restored mid-run after a maintenance restart or
        # crash still owes its launching parent a completion callback. Keep the
        # original parent for this one run so the parent hears back; the flag
        # is cleared here, and the finish path persists the callback id, so it
        # is delivered at most once.
        owed_callback = record.callback_owed and self._owed_callback_deliverable(record)
        record.callback_owed = False
        if owed_callback:
            logger.warning(
                "[restore] delivering owed parent callback on wake task_id=%s parent=%s",
                record.task_id,
                record.parent_route,
            )
        else:
            record.parent_route = record.child_route
            record.parent_session_id_at_launch = (
                current_child_session_id
                or record.parent_session_id_at_launch
            )
            record.parent_source_uuid = (
                self._session_heads.get(current_child_session_id or "")
                or record.parent_source_uuid
            )
        record.prompt = wake_prompt
        record.prompt_file = None
        record.prompt_file_content = None
        record.status = "launched"
        record.error = None
        record.terminal_request = None
        record.completed_at = None
        record.result_text = None
        record.parent_callback_message_id = None
        record.child_completion_message_id = None
        record.tool_use_id = None
        record.launch_tool_name = "AgentTask"
        if not owed_callback:
            # An owed callback replies to the parent's original launch message.
            record.launch_parent_message_id = self._run_generation(wake_message_id)
        record.launch_child_message_id = wake_message_id
        record.idle_ready = False
        record.wake_requested = False
        record.wake_source_sender = None
        record.wake_source_summary = None
        record.wake_source_content = None
        record.emit_parent_callback = owed_callback
        self._register_team_worker_record(record)
        await self._schedule_fork_task(
            task_id=record.task_id,
            parent_state=child_state,
            wake_reserved=True,
        )

    async def _start_idle_route_inbox_wake(
        self,
        *,
        state: TelegramSessionState,
        team_name: str,
        agent_name: str,
        sender: str | None,
        summary: str | None,
        content: str | None,
    ) -> None:
        bot = self._bot_for_state(state)
        if bot is None:
            return

        sender_norm = (sender or "").strip() or None
        summary_norm = (summary or "").strip() or None
        content_norm = (content or "").strip() or None
        wake_html_lines = ["topic wake: teammate message received"]
        wake_html_lines.append(f"team_name: {html.escape(team_name)}")
        wake_html_lines.append(f"agent_name: {html.escape(agent_name)}")
        if sender_norm:
            wake_html_lines.append(f"from: {html.escape(sender_norm)}")
        if summary_norm:
            wake_html_lines.append(f"summary: {html.escape(summary_norm)}")
        wake_messages = await self._send_system_html_message(
            route=state.route,
            bot=bot,
            html_text="\n".join(wake_html_lines),
            disable_notification=True,
            underline=False,
        )
        wake_message_id = self._sent_message_id(wake_messages[0]) if wake_messages else None
        wake_prompt = self._build_idle_team_worker_prompt(
            team_name=team_name,
            agent_name=agent_name,
            sender=sender_norm,
            summary=summary_norm,
            content=content_norm,
        )
        self._clear_stop_latch(state, "inbox_wake")
        queued_before = _drain_queue(state.hook_state.message_queue)
        await self._run_and_send(
            state=state,
            user_text=wake_prompt,
            bot=bot,
            trigger_message=QueuedMessage(
                text=wake_prompt,
                telegram_message_id=wake_message_id,
            ),
            extra_pending=queued_before if queued_before else None,
        )

    def _on_detached_wake_done(self, task: asyncio.Task) -> None:
        self._detached_wake_tasks.discard(task)
        if task.cancelled():
            return
        exc = task.exception()
        if exc is not None:
            logger.warning("Detached route inbox wake failed", exc_info=exc)

    def _spawn_detached_route_inbox_wake(
        self,
        *,
        state: TelegramSessionState,
        team_name: str,
        agent_name: str,
        sender: str | None,
        summary: str | None,
        content: str | None,
    ) -> asyncio.Task:
        """Run a route-target inbox wake detached from the caller's turn.

        The wake drives the *recipient's* entire turn through ``_run_and_send``.
        Awaiting it inline blocks the caller — and on the ``SendInboxMessage``
        path the caller is the sender's MCP tool call, so the sender could not
        end its turn until the recipient finished.  The worker-record path
        already detaches (``_schedule_fork_task``); this mirrors it.

        The route lock and the busy re-check move *inside* the detached task so
        that turn serialization for the route is unchanged.  If the re-check
        loses the race, the message takes the existing deferral path instead of
        being dropped.
        """

        async def _runner() -> None:
            lock = self._get_route_lock(state.route)
            async with lock:
                if (
                    state.busy
                    or state.hook_state.pause_queue_delivery
                    or self._chat_pending_ops.get(state.route.chat_id, 0) > 0
                ):
                    self._queue_running_team_worker_notice(
                        state=state,
                        team_name=team_name,
                        agent_name=agent_name,
                        sender=sender,
                        summary=summary,
                        content=content,
                    )
                    return
                # A slow wake-marker send is already an admitted wake, even
                # though _run_and_send has not reached its busy flag yet.
                state.busy = True
                try:
                    await self._start_idle_route_inbox_wake(
                        state=state,
                        team_name=team_name,
                        agent_name=agent_name,
                        sender=sender,
                        summary=summary,
                        content=content,
                    )
                finally:
                    state.busy = False

        task = asyncio.create_task(_runner())
        self._detached_wake_tasks.add(task)
        task.add_done_callback(self._on_detached_wake_done)
        return task

    async def _maybe_wake_route_inbox_target(
        self,
        *,
        state: TelegramSessionState,
        team_name: str,
        agent_name: str,
        sender: str | None,
        summary: str | None,
        content: str | None,
    ) -> bool:
        if state.busy or state.hook_state.pause_queue_delivery:
            return False
        if self._chat_pending_ops.get(state.route.chat_id, 0) > 0:
            return False
        lock = self._get_route_lock(state.route)
        if lock.locked():
            return False
        self._spawn_detached_route_inbox_wake(
            state=state,
            team_name=team_name,
            agent_name=agent_name,
            sender=sender,
            summary=summary,
            content=content,
        )
        return True

    async def _handle_inbox_message_notification(
        self,
        *,
        sender_route: TelegramRoute,
        payload: dict[str, Any],
    ) -> dict[str, Any] | None:
        team_name = str(payload.get("team_name") or "").strip()
        recipient = str(payload.get("recipient") or "").strip()
        if not team_name or not recipient:
            return {"delivered": False, "reason": "recipient has no current route binding"}

        sender = str(payload.get("sender") or "").strip() or None
        summary = str(payload.get("summary") or "").strip() or None
        content = str(payload.get("content") or "").strip() or None
        direct_notified_key: tuple[str, str, str] | None = None
        if payload.get("_direct_send"):
            fingerprint = f"{sender}:{summary}:{content}"[:200]
            direct_notified_key = (team_name, recipient, fingerprint)

        def _mark_direct_send_notified() -> None:
            if direct_notified_key is not None:
                self._notified_inbox_keys.add(direct_notified_key)

        # vault-5lko: name the sender's team when it differs from the
        # recipient's, so the recipient can reply. Display only; dedup above
        # uses the raw sender.
        sender_team = str(payload.get("sender_team") or "").strip() or None
        if sender and sender_team and sender_team != team_name:
            sender = f"{sender} (team {sender_team})"

        # Handle reply_wake_clear signal: all must_reply messages replied
        if payload.get("_reply_wake_clear"):
            # Find and delete the reply_wake schedule for the recipient's route
            recipient_state = self._resolve_route_inbox_target(
                team_name=team_name,
                agent_name=recipient,
            )
            if recipient_state is not None:
                wake_id = reply_wake_schedule_id(recipient_state.route)
                if wake_id in self._topic_schedules_by_id:
                    self._delete_topic_schedule(wake_id)
                    logger.info(
                        "Deleted reply_wake schedule %s: all must_reply messages replied",
                        wake_id,
                    )
            return {"delivered": True}

        # Create reply_wake schedule if this is a must_reply message
        if payload.get("_must_reply"):
            recipient_state = self._resolve_route_inbox_target(
                team_name=team_name,
                agent_name=recipient,
            )
            if recipient_state is not None:
                wake_record = create_reply_wake_schedule(recipient_state.route)
                existing = self._topic_schedules_by_id.get(wake_record.schedule_id)
                if existing is not None:
                    # Upsert: reset run_count for the new message — fresh attempts.
                    existing.enabled = True
                    existing.run_count = 0
                    existing.next_run_at = time.time() + (existing.interval_seconds or 1)
                    self._register_topic_schedule(existing)
                    logger.info(
                        "Upserted reply_wake schedule %s: run_count reset to 0",
                        wake_record.schedule_id,
                    )
                else:
                    wake_record.next_run_at = time.time() + (wake_record.interval_seconds or 1)
                    self._register_topic_schedule(wake_record)
                    logger.info(
                        "Created reply_wake schedule %s for route=%s",
                        wake_record.schedule_id,
                        recipient_state.route,
                    )

        record = self._resolve_team_worker_record(
            team_name=team_name,
            agent_name=recipient,
        )
        if record is None:
            state = self._resolve_route_inbox_target(
                team_name=team_name,
                agent_name=recipient,
            )
            if state is None:
                return {"delivered": False, "reason": "recipient has no current route binding"}
            try:
                woken = await self._maybe_wake_route_inbox_target(
                    state=state,
                    team_name=team_name,
                    agent_name=recipient,
                    sender=sender,
                    summary=summary,
                    content=content,
                )
                if not woken:
                    self._queue_running_team_worker_notice(
                        state=state,
                        team_name=team_name,
                        agent_name=recipient,
                        sender=sender,
                        summary=summary,
                        content=content,
                    )
                _mark_direct_send_notified()
                return {"delivered": True}
            except Exception as exc:
                logger.warning(
                    "Failed waking lineage route from inbox notification route=%s team=%s agent=%s sender_route=%s",
                    state.route,
                    team_name,
                    recipient,
                    sender_route,
                    exc_info=True,
                )
                return {
                    "delivered": False,
                    "reason": self._notification_failure_reason(exc),
                }
        # If the agent task is actively running, queue the wake for when the
        # turn completes — we can't start two fork tasks simultaneously.
        running = self._fork_task_tasks.get(record.task_id)
        if running is not None and not running.done():
            child_state = self._get_state(record.child_route, create=False)
            if child_state is not None:
                self._queue_running_team_worker_notice(
                    state=child_state,
                    team_name=team_name,
                    agent_name=recipient,
                    sender=sender,
                    summary=summary,
                    content=content,
                )
            else:
                record.wake_requested = True
                record.wake_source_sender = sender
                record.wake_source_summary = summary
                record.wake_source_content = content
                self._persist_task_handle_record(record)
            _mark_direct_send_notified()
            return {"delivered": True}

        child_state = self._get_state(record.child_route, create=False)
        if child_state is not None and (
            child_state.busy
            or child_state.hook_state.pause_queue_delivery
            or self._get_route_lock(child_state.route).locked()
            or self._chat_pending_ops.get(child_state.route.chat_id, 0) > 0
        ):
            self._queue_running_team_worker_notice(
                state=child_state,
                team_name=team_name,
                agent_name=recipient,
                sender=sender,
                summary=summary,
                content=content,
            )
            _mark_direct_send_notified()
            return {"delivered": True}

        # Always try to wake regardless of record status (completed, failed,
        # stopped, etc.).  Over-deliver rather than under-deliver.
        record.idle_ready = True
        if child_state is not None:
            child_state.busy = True
        wake_scheduled = False
        try:
            await self._start_idle_team_worker_wake(
                record=record,
                sender=sender,
                summary=summary,
                content=content,
            )
            wake_scheduled = True
            _mark_direct_send_notified()
            return {"delivered": True}
        except Exception as exc:
            logger.warning(
                "Failed waking team worker from inbox notification route=%s task_id=%s status=%s sender_route=%s",
                record.child_route,
                record.task_id,
                record.status,
                sender_route,
                exc_info=True,
            )
            # Wake failed — send bounce-back so senders know.
            await self._send_bounce_backs_for_dead_agent(record.child_route)
            return {
                "delivered": False,
                "reason": self._notification_failure_reason(exc),
            }
        finally:
            if child_state is not None and not wake_scheduled:
                child_state.busy = False

    async def _schedule_fork_task(
        self,
        *,
        task_id: str,
        parent_state: TelegramSessionState,
        wake_reserved: bool = False,
    ) -> None:
        parent_state.active_fork_task_ids.add(task_id)
        started = False

        async def execute() -> None:
            nonlocal started
            started = True
            if wake_reserved and task_id not in self._fork_tasks_by_id:
                parent_state.busy = False
                parent_state.active_fork_task_ids.discard(task_id)
                return
            if wake_reserved:
                await self._execute_fork_task(task_id, wake_reserved=True)
            else:
                await self._execute_fork_task(task_id)

        def completed(done: asyncio.Task) -> None:
            if wake_reserved and not started:
                # Cancellation before the coroutine's first step bypasses its finally.
                parent_state.busy = False
                parent_state.active_fork_task_ids.discard(task_id)
            if self._fork_task_tasks.get(task_id) is done:
                self._fork_task_tasks.pop(task_id, None)
                if wake_reserved:
                    parent_state.active_fork_task_ids.discard(task_id)

        task = asyncio.create_task(execute())
        self._fork_task_tasks[task_id] = task
        task.add_done_callback(completed)

    async def _resume_fork_task(
        self,
        *,
        route: TelegramRoute,
        state: TelegramSessionState,
        args: dict[str, Any],
        task_id: str,
    ) -> dict[str, Any]:
        record = self._fork_tasks_by_id.get(task_id)
        if record is None:
            return self._task_not_found_result(task_id)
        task_label = "ForkTask" if record.is_fork else "AgentTask"
        existing_task = self._fork_task_tasks.get(task_id)
        if existing_task is not None and not existing_task.done():
            return {
                "content": [
                    {
                        "type": "text",
                        "text": f"{task_label} failed: task {task_id} is already running",
                    }
                ],
                "is_error": True,
            }

        prompt = str(args["prompt"])
        description = (
            str(
                args.get("display_name")
                or args.get("alias")
                or args.get("description")
                or args.get("name")
                or ""
            ).strip()
            or record.description
        )
        team_name = str(args.get("team_name") or "").strip() or record.team_name
        agent_name = (
            str(args.get("agent_name") or "").strip()
            or record.agent_name
        )
        # timeout_ms and max_turns disabled — all agents run without limits.
        timeout_ms = None
        max_turns = None
        child_state = self._get_state(record.child_route, create=False)
        if child_state is None or state.last_bot is None:
            return self._task_not_found_result(task_id)
        record.parent_route = route
        record.parent_session_id_at_launch = state.session_id or record.parent_session_id_at_launch
        record.parent_source_uuid = self._session_heads.get(state.session_id or "") or record.parent_source_uuid
        record.prompt = prompt
        record.description = description
        record.timeout_ms = timeout_ms
        record.max_turns = max_turns
        record.team_name = team_name
        record.agent_name = agent_name
        record.tool_use_id = str(args.get("tool_use_id") or "").strip() or None
        launch_tool_name = str(args.get("task_tool_name") or "").strip()
        if launch_tool_name:
            record.launch_tool_name = launch_tool_name
        record.status = "launched"
        record.error = None
        record.terminal_request = None
        record.result_text = None
        record.completed_at = None
        record.parent_callback_message_id = None
        record.child_completion_message_id = None
        child_state.last_bot = state.last_bot
        record.idle_ready = False
        record.wake_requested = False
        record.wake_source_sender = None
        record.wake_source_summary = None
        record.wake_source_content = None
        record.emit_parent_callback = True
        # The resumer gets the callback of this run; nothing else is owed.
        record.callback_owed = False
        self._register_team_worker_record(record)
        child_state.session_manager.set_sdk_env_overrides(
            self._with_explicit_env(
                child_state,
                self._build_team_worker_env(
                    team_name=record.team_name,
                    agent_name=record.agent_name,
                ),
            )
        )

        resume_service_html = self._build_fork_task_child_service_html(
            agent_id=task_id,
            description=description,
            prompt=prompt,
            source_link=None,
            max_turns=max_turns,
            is_fork=record.is_fork,
            team_name=record.team_name,
            agent_name=record.agent_name,
        )
        resume_service_messages = await self._send_task_launch_notice(
            route=record.child_route,
            bot=state.last_bot,
            html_text=self._underline_first_nonempty_line_html(resume_service_html),
            underline=False,
            purpose="resume service message",
        )
        record.launch_child_message_id = (
            self._sent_message_id(resume_service_messages[0]) if resume_service_messages else None
        )
        if record.launch_child_message_id is not None:
            current_child_session_id = child_state.session_id or record.child_session_id
            if current_child_session_id:
                record.child_session_id = current_child_session_id
            latest_child_uuid = self._session_heads.get(current_child_session_id or "") or record.parent_source_uuid
            self._record_message_binding(
                route=record.child_route,
                message_id=record.launch_child_message_id,
                jsonl_uuid=latest_child_uuid,
                session_id=current_child_session_id or record.child_session_id,
                role="assistant",
            )
        child_link = (
            self._build_message_link(record.child_route, record.launch_child_message_id)
            if record.launch_child_message_id is not None
            else None
        )
        record.child_session_id = child_state.session_id or record.child_session_id
        parent_html = "fork task resumed" if record.is_fork else "agent task resumed"
        if child_link:
            parent_html = (
                f'{"fork task resumed" if record.is_fork else "agent task resumed"}: '
                f'<a href="{html.escape(child_link)}">'
                f"{html.escape(self._current_topic_title(record.child_route))}</a>"
            )
        parent_messages = await self._send_task_launch_notice(
            route=route,
            bot=state.last_bot,
            html_text=parent_html,
            purpose="parent resume notice",
        )
        record.launch_parent_message_id = self._run_generation(
            self._sent_message_id(parent_messages[0]) if parent_messages else None
        )
        # obs-54 V1: make the new generation durable before the run starts, so a
        # restart in between restores the generation a control stop will pin.
        self._persist_task_handle_record(record)
        await self._schedule_fork_task(task_id=task_id, parent_state=state)
        return {
            "content": [
                {
                    "type": "text",
                    "text": self._build_fork_task_launch_text(
                        task_id=task_id,
                        output_file=self._record_output_file(record),
                        topic_link=child_link,
                        task_label=record.launch_tool_name,
                        agent_name=record.agent_name,
                        team_name=record.team_name,
                        lineage=self._record_lineage_for_record(record),
                        session_id=record.child_session_id or None,
                    ),
                }
            ]
        }

    async def _launch_new_tree_task(
        self,
        *,
        state: TelegramSessionState,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        """AgentTask(new_tree_chat=...): start a NEW root tree in an existing chat (ops-61).

        The tree is not the caller's lineage child. The caller is recorded as its origin so
        report-back and attribution can reach it, and the prompt says who launched it.
        """
        projection = self._state_inbox_projection(state)
        origin_team, origin_agent = projection if projection is not None else (None, None)
        origin = {
            "kind": "agent",
            "origin_team": origin_team,
            "origin_agent": origin_agent,
            "origin_session_id": state.session_id,
            "origin_chat_id": state.route.chat_id,
            "origin_thread_id": state.route.thread_id,
        }
        launcher = origin_agent or "an agent"
        trigger = f"new tree launched by {launcher}"
        if origin_team and origin_agent:
            trigger += f" (team {origin_team}); report completion to it with SendInboxMessage team_name={origin_team}"
        result = await self._create_new_tree(
            trigger_label=trigger,
            notice_text=f"new tree started by {launcher}",
            chat=args.get("new_tree_chat"),
            title=str(args.get("description") or "").strip(),
            prompt=str(args.get("prompt") or ""),
            prompt_file=str(args.get("prompt_file") or "").strip() or None,
            prompt_file_content=str(args.get("prompt_file_content") or "").strip() or None,
            hooks=args.get("hooks"),
            # Like AgentTask fork=false: an omitted model means the launcher's own model.
            model=args.get("model") or state.session_manager.effective_model,
            effort=args.get("effort") if args.get("effort") not in (None, "inherit") else None,
            env=args.get("env"),
            origin=origin,
        )
        if not result.get("ok"):
            text = f"AgentTask new tree failed: {result.get('error')}"
            return {"content": [{"type": "text", "text": text}], "tool_use_result": {"error": text}, "is_error": True}
        return {
            "content": [{"type": "text", "text": result["text"]}],
            "tool_use_result": result["result"],
        }

    async def _launch_fork_task(
        self,
        *,
        route: TelegramRoute,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        state = self._get_state(route, create=False)
        if state is None or state.last_bot is None:
            raise RuntimeError("ForkTask is only available inside an active Telegram topic")

        if args.get("new_tree_chat") is not None:
            return await self._launch_new_tree_task(state=state, args=args)

        resume_task_id = self._normalize_resume_task_id(args.get("resume"))
        session_source_raw = str(args.get("session_source") or "").strip() or None
        if resume_task_id and session_source_raw:
            raise ValueError("resume and session_source are mutually exclusive")
        allow_cold_wake = bool(args.get("allow_cold_wake"))
        if resume_task_id:
            if args.get("effort") is not None or "CLAUDE_CODE_EFFORT_LEVEL" in (args.get("env") or {}):
                raise ValueError("resume preserves the child's effort; use /effort in its topic")
            if not allow_cold_wake:
                resume_record = self._fork_tasks_by_id.get(resume_task_id)
                if resume_record is not None:
                    child_state = self._get_state(resume_record.child_route, create=False)
                    readiness = self._state_cache_readiness(
                        state=child_state,
                        session_id=(child_state.session_id if child_state is not None else None)
                        or resume_record.child_session_id,
                    )
                    if readiness is not None and readiness.cold:
                        raise ValueError(
                            _cache_readiness.cold_warning(
                                readiness,
                                action="resume of",
                                target=resume_record.agent_name or resume_task_id,
                            )
                        )
            return await self._resume_fork_task(
                route=route,
                state=state,
                args=args,
                task_id=resume_task_id,
            )

        is_fork = self._coerce_fork_flag(args.get("fork"))
        if session_source_raw and not is_fork:
            raise ValueError("session_source is only supported with fork=true")
        launch_tool_name = str(args.get("task_tool_name") or "").strip() or (
            "ForkTask" if is_fork else "AgentTask"
        )
        team_name = str(args.get("team_name") or "").strip() or None
        if team_name and not _SAFE_TEAM_IDENTITY_RE.fullmatch(team_name.lower()):
            raise ValueError("team_name must be a timestamp-prefixed stable identity")
        # With two-tier naming, the 'name' parameter is a display name (alias),
        # NOT the machine agent_name. The agent_name is computed from the lineage
        # by _create_child_fork_topic via agent_name_for_lineage.
        # Only use an explicit 'agent_name' if it's provided separately.
        agent_name = str(args.get("agent_name") or "").strip() or None
        source_session_id: str | None = None
        source_uuid: str | None = None
        source_route = route
        source_message_id: int | None = None
        source_jsonl_path: Path | None = None
        explicit_session_source = False
        if is_fork:
            if session_source_raw:
                source_descriptor = resolve_session_source(
                    session_source_raw,
                    cwd=self._config.vault_path,
                )
                explicit_session_source = True
                source_session_id = source_descriptor.source_session_id
                source_jsonl_path = source_descriptor.source_jsonl_path
                if not allow_cold_wake and source_jsonl_path is not None:
                    source_route_for_check = self._route_by_session_id.get(source_session_id or "")
                    source_state = (
                        self._get_state(source_route_for_check, create=False)
                        if source_route_for_check is not None
                        else None
                    )
                    readiness = _cache_readiness.assess(
                        jsonl_path=source_jsonl_path,
                        running=bool(
                            source_state is not None
                            and (source_state.busy or source_state.hook_state.execution_active)
                        ),
                    )
                    if readiness.cold:
                        raise ValueError(
                            _cache_readiness.cold_warning(
                                readiness,
                                action="fork from",
                                target=f"session {source_session_id}",
                            )
                        )
            else:
                source_session_id, source_uuid, source_route, source_message_id = self._resolve_fork_source(
                    state=state
                )
            fallback_session_id = str(args.get("session_id") or "").strip() or None
            if not explicit_session_source and not source_session_id and fallback_session_id:
                source_session_id = fallback_session_id
            if source_session_id and not source_uuid:
                persisted_uuid = await self._await_persisted_session_uuid(
                    session_id=source_session_id,
                    jsonl_path=source_jsonl_path,
                    timeout_seconds=8.0,
                )
                if persisted_uuid:
                    source_uuid = persisted_uuid
                    self._set_session_head(
                        session_id=source_session_id,
                        jsonl_uuid=persisted_uuid,
                    )
                    if not explicit_session_source:
                        resolved_uuid, resolved_route, resolved_message_id = self._resolve_persisted_fork_source(
                            session_id=source_session_id,
                            preferred_uuid=persisted_uuid,
                            preferred_route=source_route,
                        )
                        source_uuid = resolved_uuid
                        source_route = resolved_route
                        source_message_id = resolved_message_id
            if not source_session_id or not source_uuid:
                raise RuntimeError("Cannot launch ForkTask yet: no mapped head in this topic")

            # Wait for the parent's JSONL to stabilize before copying.
            # The parent may still be streaming tool_use blocks to JSONL;
            # copying now would produce a truncated prefix → cache miss.
            stable_uuid = await self._await_jsonl_stability(
                jsonl_path=source_jsonl_path,
            ) if source_jsonl_path is not None else await self._await_jsonl_stability(
                session_id=source_session_id,
            )
            if not stable_uuid:
                if explicit_session_source:
                    raise RuntimeError("Cannot launch ForkTask yet: no persisted head for session_source")
            elif stable_uuid != source_uuid:
                logger.info(
                    "[fork_task] JSONL advanced during stability wait: %s → %s",
                    source_uuid,
                    stable_uuid,
                )
                if explicit_session_source:
                    source_uuid = stable_uuid
                else:
                    resolved_uuid, resolved_route, resolved_message_id = (
                        self._resolve_persisted_fork_source(
                            session_id=source_session_id,
                            preferred_uuid=stable_uuid,
                            preferred_route=source_route,
                        )
                    )
                    source_uuid = resolved_uuid
                    source_route = resolved_route
                    source_message_id = resolved_message_id

        task_id = str(uuid.uuid4())
        description = str(
            args.get("display_name")
            or args.get("alias")
            or args.get("description")
            or args.get("name")
            or ""
        ).strip() or None
        prompt = str(args["prompt"])
        # timeout_ms and max_turns disabled — all agents run without limits.
        timeout_ms = None
        max_turns = None
        lineage_name, topic_name = self._next_topic_alias_and_title(state, description)
        source_link = (
            self._build_message_link(source_route, source_message_id)
            if is_fork and source_message_id is not None
            else None
        )
        prompt_file = str(args.get("prompt_file") or "").strip() or None
        prompt_file_content = str(args.get("prompt_file_content") or "").strip() or None
        model_raw = str(args.get("model") or "").strip()
        model = model_raw if model_raw and model_raw.lower() not in ("inherit", "source") else None
        child_effort = args.get("effort")
        if is_fork:
            # A fork runs on its SOURCE's model and effort unless a same-family model is given
            # (fork_model.py; Daniel 2026-10-15: never silently use the launcher's model).
            source = self._fork_source_model(
                state=state,
                source_session_id=source_session_id,
                source_jsonl_path=source_jsonl_path,
                explicit=explicit_session_source,
            )
            model, same_as_source = _fork_model.choose(
                model,
                source,
                source_label=(f"session {source_session_id}" if explicit_session_source else "this session"),
            )
            if source.origin == "launcher" and same_as_source:
                model = None  # own-head fork: unchanged path, the child inherits the parent
            elif same_as_source and child_effort is None and "CLAUDE_CODE_EFFORT_LEVEL" not in (args.get("env") or {}):
                child_effort = source.effort or "auto"
            logger.info(
                "[fork_task] child model=%s effort=%s source=%s origin=%s explicit_source=%s",
                model, child_effort, source_session_id, source.origin, explicit_session_source,
            )
        inherit_schedules = args.get("inherit_schedules", True)
        env_override: dict[str, str] | None = args.get("env")
        temperature: float | None = args.get("temperature")
        user_hooks: dict[str, str] | None = args.get("hooks")
        inherit_hooks: bool = bool(args.get("inherit_hooks", False))
        child_service_html = self._build_fork_task_child_service_html(
            agent_id=task_id,
            description=description,
            prompt=prompt,
            source_link=source_link,
            max_turns=max_turns,
            is_fork=is_fork,
            team_name=team_name,
            agent_name=agent_name,
            prompt_file=prompt_file,
            prompt_file_content=prompt_file_content,
        )
        created = await self._create_child_fork_topic(
            parent_state=state,
            bot=state.last_bot,
            source_session_id=source_session_id,
            source_uuid=source_uuid,
            source_route=source_route,
            source_message_id=source_message_id,
            topic_name=topic_name,
            child_service_html=child_service_html,
            source_jsonl_path=source_jsonl_path,
            notify_on_completion=True,
            is_fork=is_fork,
            team_name=team_name,
            agent_name=agent_name,
            lineage_name=lineage_name,
            lineage_origin="agent_task_fork" if is_fork else "agent_task_fresh",
            model=model,
            effort=child_effort,
            inherit_schedules=inherit_schedules,
            launcher_lineage=bool(is_fork and explicit_session_source),
            env_override=env_override,
            temperature=temperature,
            user_hooks=user_hooks,
            inherit_hooks=inherit_hooks,
        )
        child_route: TelegramRoute = created["child_route"]
        child_service_message_id: int | None = created["child_service_message_id"]
        child_link: str | None = created["child_link"]
        team_name = str(created.get("team_name") or team_name or "").strip() or None
        agent_name = str(created.get("agent_name") or agent_name or "").strip() or None
        if team_name and agent_name:
            self._upsert_team_projection_config(
                team_name=team_name,
                agent_name=agent_name,
                child_session_id=created.get("child_session_id") or None,
                obs_metadata=self._build_team_projection_obs_metadata(
                    lineage=created.get("child_lineage") or (),
                    team_name=team_name,
                    agent_name=agent_name,
                    route=child_route,
                ),
            )

        confirmation = "fork task launched" if is_fork else "agent task launched"
        if child_link:
            confirmation = (
                f'{"fork task launched" if is_fork else "agent task launched"}: '
                f'<a href="{html.escape(child_link)}">'
                f"{html.escape(topic_name)}</a>"
            )
        confirmation_messages = await self._send_task_launch_notice(
            route=route,
            bot=state.last_bot,
            html_text=confirmation,
            purpose="parent launch confirmation",
        )
        confirmation_id = (
            self._sent_message_id(confirmation_messages[0]) if confirmation_messages else None
        )
        if confirmation_id is not None and source_uuid and source_session_id:
            self._record_message_binding(
                route=route,
                message_id=confirmation_id,
                jsonl_uuid=source_uuid,
                session_id=source_session_id,
                role="assistant",
            )

        record = _ForkTaskRecord(
            task_id=task_id,
            tool_use_id=str(args.get("tool_use_id") or "").strip() or None,
            parent_route=route,
            parent_session_id_at_launch=source_session_id or (state.session_id or ""),
            parent_source_uuid=source_uuid or "",
            child_route=child_route,
            child_session_id=created["child_session_id"],
            prompt=prompt,
            prompt_file=prompt_file,
            prompt_file_content=prompt_file_content,
            description=description,
            timeout_ms=timeout_ms,
            max_turns=max_turns,
            launch_parent_message_id=self._run_generation(confirmation_id),
            launch_child_message_id=child_service_message_id,
            is_fork=is_fork,
            launch_tool_name=launch_tool_name,
            team_name=team_name,
            agent_name=agent_name,
        )
        self._fork_tasks_by_id[task_id] = record
        self._fork_task_by_child_route[child_route] = task_id
        self._register_team_worker_record(record)
        await self._schedule_fork_task(task_id=task_id, parent_state=state)
        return {
            "content": [
                {
                    "type": "text",
                    "text": self._build_fork_task_launch_text(
                        task_id=task_id,
                        output_file=self._record_output_file(record),
                        topic_link=child_link,
                        task_label=launch_tool_name,
                        agent_name=record.agent_name,
                        team_name=record.team_name,
                        lineage=self._record_lineage_for_record(record),
                        session_id=record.child_session_id or None,
                    ),
                }
            ]
        }

    @staticmethod
    def _normalize_resume_task_id(value: Any) -> str | None:
        if value is None:
            return None
        normalized = str(value).strip()
        if not normalized:
            return None
        if normalized.lower() in {"false", "none", "null", "nil", "0", "no"}:
            return None
        return normalized

    @staticmethod
    def _coerce_fork_flag(value: Any) -> bool:
        if value is None:
            return True
        if isinstance(value, bool):
            return value
        normalized = str(value).strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
        return True

    async def _execute_fork_task(self, task_id: str, *, wake_reserved: bool = False) -> None:
        record = self._fork_tasks_by_id.get(task_id)
        if record is None:
            return

        child_state = self._get_state(record.child_route, create=False)
        parent_state = self._get_state(record.parent_route, create=False)
        bot = (
            (child_state.last_bot if child_state is not None else None)
            or (parent_state.last_bot if parent_state is not None else None)
            or self._primary_bot
        )
        if child_state is not None:
            # Launch, resume and wake of this task are explicit (re)starts.
            self._clear_stop_latch(child_state, "agent_task_run")
        if child_state is None or bot is None:
            if wake_reserved and child_state is not None:
                child_state.busy = False
            record.status = record.terminal_request or "failed"
            record.error = record.error or "child route unavailable before launch"
            record.completed_at = time.time()
            if parent_state is not None:
                parent_state.active_fork_task_ids.discard(task_id)
            self._persist_task_handle_record(record)
            return
        child_state.last_bot = bot

        current_child_session_id = (child_state.session_id or "").strip()
        if current_child_session_id and current_child_session_id != record.child_session_id:
            record.child_session_id = current_child_session_id

        child_lock = self._get_route_lock(record.child_route)
        lifecycle_monitor_task: asyncio.Task | None = None
        if not record.is_fork and parent_state is not None and parent_state.last_bot is not None:
            lifecycle_monitor_task = asyncio.create_task(
                self._monitor_super_task_lifecycle(
                    record=record,
                    child_state=child_state,
                    parent_state=parent_state,
                )
            )
        try:
            async with child_lock:
                if record.is_fork and self._config.fork_cache_warmup_delay_seconds > 0:
                    await asyncio.sleep(self._config.fork_cache_warmup_delay_seconds)
                child_prompt = self._compose_prompt_file_context(
                    prompt=record.prompt,
                    prompt_file=record.prompt_file,
                    prompt_file_content=record.prompt_file_content,
                )
                if record.max_turns is not None:
                    child_prompt = (
                        f"(System: complete this task in at most {record.max_turns} turns.)\n\n"
                        f"{child_prompt}"
                    )
                outcome_coro = self._run_and_send(
                    state=child_state,
                    user_text=child_prompt,
                    bot=bot,
                    trigger_message=QueuedMessage(
                        text=child_prompt,
                        telegram_message_id=record.launch_child_message_id,
                    ),
                )
                if record.timeout_ms is not None:
                    outcome = await asyncio.wait_for(
                        outcome_coro,
                        timeout=record.timeout_ms / 1000.0,
                    )
                else:
                    outcome = await outcome_coro
            record.result_text = outcome.assistant_text or None
            if record.terminal_request:
                record.status = record.terminal_request
            elif outcome.failed:
                record.status = "failed"
                record.error = outcome.error
            else:
                record.status = "completed"
        except asyncio.TimeoutError:
            record.status = record.terminal_request or "failed"
            record.error = "timed out"
        except Exception as exc:
            record.status = record.terminal_request or "failed"
            record.error = f"{type(exc).__name__}: {exc}"
        finally:
            if wake_reserved:
                child_state.busy = False
                if parent_state is not None:
                    parent_state.active_fork_task_ids.discard(task_id)
            record.completed_at = time.time()
            # vault-1i53: the run's own session, even if it changed after the last event.
            finished_session_id = (child_state.session_id or "").strip() if child_state is not None else ""
            if finished_session_id:
                record.child_session_id = finished_session_id
            result_data = child_state.hook_state.last_result_data if child_state is not None else None
            usage = result_data.get("usage") if isinstance(result_data, dict) else None
            if isinstance(usage, dict):
                record.usage_total_tokens = sum(
                    int(usage.get(key) or 0)
                    for key in (
                        "input_tokens",
                        "output_tokens",
                        "cache_creation_input_tokens",
                        "cache_read_input_tokens",
                    )
                )
            if isinstance(result_data, dict):
                duration = result_data.get("duration_ms")
                if duration is not None:
                    record.usage_duration_ms = int(duration)
            output_snapshot = self._record_output_snapshot(record)
            record.usage_tool_uses = output_snapshot.count('"type":"tool_use"')
            if lifecycle_monitor_task is not None and not lifecycle_monitor_task.done():
                lifecycle_monitor_task.cancel()
                try:
                    await lifecycle_monitor_task
                except asyncio.CancelledError:
                    pass

        is_team_worker = bool((record.team_name or "").strip()) and bool(
            (record.agent_name or "").strip()
        )
        # All team workers become idle_ready after their task finishes,
        # regardless of outcome (completed, failed, stopped).  The inbox
        # wake path will attempt to restart them; if that fails it sends
        # bounce-backs.  Over-deliver rather than under-deliver.
        if is_team_worker and record.terminal_request is None:
            record.idle_ready = True

        if parent_state is not None:
            parent_state.active_fork_task_ids.discard(task_id)

        if record.terminal_request == "failed":
            self._persist_task_handle_record(record)
            self._fork_task_by_child_route.pop(record.child_route, None)
            return

        parent_callback_link: str | None = None
        child_terminal_link: str | None = None
        child_state = self._get_state(record.child_route, create=False)
        if child_state is not None and child_state.last_bot is not None:
            terminal_text = self._build_completion_summary(
                child_state,
                subtask_status=f"{'fork' if record.is_fork else 'agent task'} {self._record_status_label(record)}",
            )
            terminal_message = await self._send_system_message(
                route=record.child_route,
                bot=child_state.last_bot,
                text=terminal_text,
                disable_notification=True,
            )
            record.child_completion_message_id = (
                self._sent_message_id(terminal_message) if terminal_message is not None else None
            )
            if record.child_completion_message_id is not None:
                child_terminal_link = self._build_message_link(
                    record.child_route,
                    record.child_completion_message_id,
                )
            latest_uuid = self._session_heads.get(record.child_session_id) or record.parent_source_uuid
            if record.child_completion_message_id and latest_uuid:
                self._record_message_binding(
                    route=record.child_route,
                    message_id=record.child_completion_message_id,
                    jsonl_uuid=latest_uuid,
                    session_id=record.child_session_id,
                    role="assistant",
                )

        if (
            record.emit_parent_callback
            and parent_state is not None
            and parent_state.last_bot is None
        ):
            # A parent restored after a restart has no bot until its next turn;
            # without one its owed callback would be dropped (vault-u3b.35).
            parent_state.last_bot = self._bot_for_state(parent_state)
        if (
            record.emit_parent_callback
            and parent_state is not None
            and parent_state.last_bot is not None
        ):
            child_anchor_id = record.child_completion_message_id or record.launch_child_message_id
            child_anchor_link = (
                self._build_message_link(record.child_route, child_anchor_id)
                if child_anchor_id is not None
                else None
            )
            task_prefix = "fork task" if record.is_fork else "agent task"
            parent_marker = f"{task_prefix} {html.escape(self._record_status_label(record))}"
            if child_anchor_link:
                parent_marker = (
                    f'{task_prefix} {html.escape(self._record_status_label(record))}: '
                    f'<a href="{html.escape(child_anchor_link)}">open child idle notice</a>'
                )
            try:
                marker_messages = await self._send_system_html_message(
                    route=record.parent_route,
                    bot=parent_state.last_bot,
                    html_text=parent_marker,
                    disable_notification=True,
                    reply_to_message_id=self._reply_anchor(record.launch_parent_message_id),
                )
                record.parent_callback_message_id = (
                    self._sent_message_id(marker_messages[0]) if marker_messages else None
                )
                if record.parent_callback_message_id is not None:
                    parent_callback_link = self._build_message_link(
                        record.parent_route,
                        record.parent_callback_message_id,
                    )
                    latest_parent_uuid = self._session_heads.get(parent_state.session_id or "")
                    self._record_message_binding(
                        route=record.parent_route,
                        message_id=record.parent_callback_message_id,
                        jsonl_uuid=latest_parent_uuid or record.parent_source_uuid,
                        session_id=parent_state.session_id or record.parent_session_id_at_launch,
                        role="assistant",
                    )
            except Exception:
                logger.exception("Failed to send parent completion marker for ForkTask task_id=%s", task_id)
            finally:
                parent_state.hook_state.message_queue.put_nowait(
                    self._build_fork_task_callback_payload(record)
                )

        if (
            child_state is not None
            and child_state.last_bot is not None
            and parent_callback_link
            and child_terminal_link is not None
        ):
            backlink_text = self._build_completion_summary(
                child_state,
                subtask_status=f"{'fork' if record.is_fork else 'agent task'} {self._record_status_label(record)}",
                return_to_parent_link=parent_callback_link,
            )
            try:
                await child_state.last_bot.edit_message_text(
                    chat_id=record.child_route.chat_id,
                    message_id=record.child_completion_message_id,
                    text=self._format_system_html(backlink_text),
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True,
                )
            except Exception:
                logger.debug("Failed to add parent backlink to child terminal message", exc_info=True)

        self._persist_task_handle_record(record)
        if record.idle_ready and record.terminal_request is None:
            # Keep the team worker registered regardless of outcome status
            # (completed, failed, stopped) so inbox wakes can reach it.
            self._fork_task_by_child_route[record.child_route] = record.task_id
            self._register_team_worker_record(record)
            await self._prune_idle_claude_processes(completing_task_id=record.task_id)
            await self._replay_pending_team_worker_wake(record)
            return

        self._fork_task_by_child_route.pop(record.child_route, None)
        self._remove_team_worker_mappings_for_task(task_id)

    async def _replay_pending_team_worker_wake(self, record: _ForkTaskRecord) -> None:
        """Replay a pending worker wake once that recipient can accept a turn."""
        if not record.wake_requested:
            return
        child_state = self._get_state(record.child_route, create=False)
        if child_state is not None and (
            child_state.busy
            or child_state.hook_state.pause_queue_delivery
            or self._get_route_lock(child_state.route).locked()
            or self._chat_pending_ops.get(child_state.route.chat_id, 0) > 0
        ):
            # Keep the wake recoverable until this recipient and its transport
            # are ready. Other agents do not affect admission.
            record.wake_requested = False
            self._queue_running_team_worker_notice(
                state=child_state,
                team_name=record.team_name or "",
                agent_name=record.agent_name or "",
                sender=record.wake_source_sender,
                summary=record.wake_source_summary,
                content=record.wake_source_content,
            )
            self._persist_task_handle_record(record)
            return
        if child_state is not None:
            child_state.busy = True
        wake_scheduled = False
        try:
            await self._start_idle_team_worker_wake(
                record=record,
                sender=record.wake_source_sender,
                summary=record.wake_source_summary,
                content=record.wake_source_content,
            )
            wake_scheduled = True
        except Exception:
            logger.warning(
                "Failed immediate wake for team worker task_id=%s status=%s",
                record.task_id,
                record.status,
                exc_info=True,
            )
            await self._send_bounce_backs_for_dead_agent(record.child_route)
        finally:
            if child_state is not None and not wake_scheduled:
                child_state.busy = False

    async def _fork_task_output(
        self,
        *,
        route: TelegramRoute,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        try:
            task_id, team_name, agent_name = self._task_lookup_args(args)
        except ValueError as exc:
            return self._task_lookup_error_result(str(exc))
        block = bool(args["block"])
        timeout = max(int(args["timeout"]), 0)
        record = self._resolve_task_lookup(
            route=route,
            task_id=task_id,
            team_name=team_name,
            agent_name=agent_name,
        )
        lookup_label = task_id or f"{team_name or '<caller-team>'}/{agent_name}"
        if record is None:
            return self._task_not_found_result(lookup_label)
        task_id = record.task_id

        task = self._fork_task_tasks.get(task_id)
        output_file = self._record_output_file(record)
        if task is not None and not task.done():
            if block:
                try:
                    await asyncio.wait_for(asyncio.shield(task), timeout / 1000.0)
                except asyncio.TimeoutError:
                    return {
                        "content": [{"type": "text", "text": "<retrieval_status>timeout</retrieval_status>"}],
                        "tool_use_result": {"retrieval_status": "timeout", "task": None},
                    }
            else:
                running_output = (record.result_text or "").strip() or self._record_output_snapshot(record).strip() or None
                return self._build_fork_task_output_result(
                    record=record,
                    retrieval_status="not_ready",
                    status="running",
                    output=running_output,
                    output_file=output_file,
                )

        if record.status not in {"completed", "stopped", "failed"} and record.terminal_request in {"stopped", "killed"}:
            terminal_status = "stopped"
        elif record.status in {"completed", "stopped", "failed"}:
            terminal_status = record.status
        else:
            return self._task_not_found_result(task_id)

        if terminal_status == "failed":
            terminal_output = (record.error or record.result_text or "").strip() or None
        else:
            terminal_output = (record.result_text or "").strip() or None

        retrieval_status = "completed" if terminal_status == "completed" else terminal_status
        return self._build_fork_task_output_result(
            record=record,
            retrieval_status=retrieval_status,
            status=terminal_status,
            output=terminal_output,
            output_file=output_file,
        )

    async def _fork_task_stop(
        self,
        *,
        route: TelegramRoute,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        try:
            task_id, team_name, agent_name = self._task_lookup_args(args)
        except ValueError as exc:
            return self._task_lookup_error_result(str(exc))
        record = self._resolve_task_lookup(
            route=route,
            task_id=task_id,
            team_name=team_name,
            agent_name=agent_name,
        )
        lookup_label = task_id or f"{team_name or '<caller-team>'}/{agent_name}"
        if record is None:
            return self._task_not_found_result(lookup_label)
        task_id = record.task_id
        task = self._fork_task_tasks.get(task_id)
        child_state = self._get_state(record.child_route, create=False)
        # obs-2: the task record can look idle or finished while its route is
        # still running a turn that is not this task's fork run (a maintenance
        # resume, a queued-update delivery). Stop the route itself, always.
        record.wake_requested = False  # a wake queued before the stop
        if child_state is not None:
            self._latch_task_stop(child_state)
            await self._interrupt_live_client(child_state)
        route_active = child_state is not None and bool(
            child_state.busy or child_state.hook_state.execution_active
        )
        if record.idle_ready and (task is None or task.done()):
            record.idle_ready = False
            record.wake_requested = False
            record.wake_source_sender = None
            record.wake_source_summary = None
            record.wake_source_content = None
            record.terminal_request = "stopped"
            record.status = "stopped"
            record.completed_at = time.time()
            self._fork_task_by_child_route.pop(record.child_route, None)
            self._remove_team_worker_mappings_for_task(task_id)
            self._persist_task_handle_record(record)
            payload = {
                "message": f"Successfully stopped task: {task_id} ({record.description or 'fork task'})",
                "task_id": task_id,
                "task_id_scope": "deprecated_internal_compatibility",
                "team_name": record.team_name,
                "agent_name": record.agent_name,
                "session_id": record.child_session_id or None,
                "task_type": "local_agent",
                "command": record.description or "fork task",
                "status": "stopped",
                "idempotent": False,
            }
            return {
                "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=True)}],
                "tool_use_result": payload,
            }
        if record.status in {"completed", "failed", "stopped"} and route_active:
            # The record is terminal but its route is still executing (obs-2).
            prior_status = record.status
            record.terminal_request = "stopped"
            record.status = "stopped"
            self._persist_task_handle_record(record)
            payload = {
                "message": f"Task was {prior_status} but its agent was still running; interrupting it: {task_id}",
                "task_id": task_id,
                "task_id_scope": "deprecated_internal_compatibility",
                "team_name": record.team_name,
                "agent_name": record.agent_name,
                "session_id": record.child_session_id or None,
                "task_type": "local_agent",
                "status": "stopping",
                "idempotent": False,
            }
            return {
                "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=True)}],
                "tool_use_result": payload,
            }
        if record.status in {"completed", "failed", "stopped"}:
            payload = {
                "message": f"Task already {record.status}: {task_id}",
                "task_id": task_id,
                "task_id_scope": "deprecated_internal_compatibility",
                "team_name": record.team_name,
                "agent_name": record.agent_name,
                "session_id": record.child_session_id or None,
                "task_type": "local_agent",
                "status": record.status,
                "idempotent": True,
            }
            return {
                "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=True)}],
                "tool_use_result": payload,
            }
        if record.terminal_request == "stopped":
            payload = {
                "message": f"Task stop already requested: {task_id}",
                "task_id": task_id,
                "task_id_scope": "deprecated_internal_compatibility",
                "team_name": record.team_name,
                "agent_name": record.agent_name,
                "session_id": record.child_session_id or None,
                "task_type": "local_agent",
                "status": "stopping",
                "idempotent": True,
            }
            return {
                "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=True)}],
                "tool_use_result": payload,
            }

        record.terminal_request = "stopped"
        self._persist_task_handle_record(record)
        payload = {
            "message": f"Successfully stopped task: {task_id} ({record.description or 'fork task'})",
            "task_id": task_id,
            "task_id_scope": "deprecated_internal_compatibility",
            "team_name": record.team_name,
            "agent_name": record.agent_name,
            "session_id": record.child_session_id or None,
            "task_type": "local_agent",
            "command": record.description or "fork task",
            "status": "stopping",
            "idempotent": False,
        }
        return {
            "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=True)}],
            "tool_use_result": payload,
        }

    async def handle_fork(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /fork and report failures in its originating topic."""
        try:
            await self._handle_fork(update, context)
        except Exception as exc:
            logger.exception("Error in /fork")
            await self._report_command_error(update, context.bot, exc)

    async def _report_command_error(self, update: object, bot: Bot, exc: BaseException) -> None:
        if not isinstance(update, Update):
            return
        message = update.effective_message
        user = update.effective_user
        if message is None or user is None or not self._is_authorized(user.id):
            return
        cause = " ".join(str(exc).splitlines()).strip()
        for name, value in os.environ.items():
            if re.search(r"TOKEN|SECRET|PASSWORD|AUTH|API_?KEY|SESSION", name, re.IGNORECASE) and len(value) >= 8:
                cause = cause.replace(value, "[redacted]")
        for token in self._config.telegram_sender_bot_tokens:
            if token:
                cause = cause.replace(token, "[redacted]")
        cause = re.sub(r"(?i)(/bot)\d+:[A-Za-z0-9_-]+", r"\1[redacted]", cause)
        cause = re.sub(r"(?i)(bearer\s+)\S+", r"\1[redacted]", cause)
        cause = re.sub(r'''(?i)\b(token|secret|password|authorization|api[_-]?key)(["']?\s*[:=]\s*)(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[^\s,;}]+)''', r"\1\2[redacted]", cause)
        cause = re.sub(r"(https?://)[^/@\s]+:[^/@\s]+@", r"\1[redacted]@", cause)
        text = f"Command error (operation may have partially completed): {type(exc).__name__}: {cause[:200] or 'no details'}"
        try:
            sent = await asyncio.wait_for(message.reply_text(text, parse_mode=None), timeout=10)
        except Exception as send_exc:
            logger.error("Failed to send command error reply (%s)", type(send_exc).__name__)
            return
        try:
            self._remember_system_message_id(route=self._route_for_message(message), message_id=self._sent_message_id(sent))
        except Exception as store_exc:
            logger.warning("Could not record delivered command error (%s)", type(store_exc).__name__)

    async def handle_application_error(
        self, update: object, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        exc = context.error
        logger.error("Telegram update failed", exc_info=exc)
        if (
            exc is not None
            and isinstance(update, Update)
            and update.effective_message is not None
            and (update.effective_message.text or "").startswith("/")
        ):
            await self._report_command_error(update, context.bot, exc)
            raise ApplicationHandlerStop

    async def _handle_fork(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Create a new topic from current head or replied message."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        await self._ensure_background_poller(context.bot)
        message = update.effective_message
        route = self._route_for_message(message)
        state = self._get_state(route)
        if state is None:
            return
        state.last_bot = context.bot

        reply_message = message.reply_to_message
        reply_message_id = getattr(reply_message, "message_id", None)
        if isinstance(reply_message_id, int) and self._is_system_message_id(
            chat_id=route.chat_id,
            message_id=reply_message_id,
        ):
            reply_message_id = None
        elif (
            isinstance(reply_message_id, int)
            and route.thread_id is not None
            and reply_message_id == route.thread_id
            and self._message_map.get((route.chat_id, reply_message_id)) is None
        ):
            reply_message_id = None
        elif (
            reply_message_id is not None
            and self._message_map.get((route.chat_id, reply_message_id)) is None
        ):
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text="can't fork from this message",
                disable_notification=True,
                reply_to_message_id=message.message_id,
            )
            return

        source_session_id, source_uuid, source_route, source_message_id = self._resolve_fork_source(
            state=state,
            reply_message_id=reply_message_id,
        )

        logger.info(
            "[fork_command] route=%s state_session_id=%s source_session_id=%s source_uuid=%s "
            "reply_message_id=%s source_head=%s",
            route,
            state.session_id,
            source_session_id,
            source_uuid,
            reply_message_id,
            self._session_heads.get(source_session_id or ""),
        )

        if not source_session_id or not source_uuid:
            await self._send_system_message(
                route=route,
                bot=context.bot,
                text="can't fork yet: no mapped head in this topic",
                disable_notification=True,
                reply_to_message_id=message.message_id,
            )
            return

        # Wait for the parent's JSONL to stabilize before copying.
        stable_uuid = await self._await_jsonl_stability(
            session_id=source_session_id,
        )
        # vault-w0eg: an explicit reply source never moves to the latest row. Only a
        # head fork (no reply, or a reply to the true, non-stale head) follows the
        # JSONL as it advances; a reply whose bound uuid never reached the JSONL is
        # refused, as in the reply fork.
        follows_head = reply_message_id is None
        if not follows_head and source_uuid == self._session_heads.get(source_session_id or ""):
            _uuid, head_health = self._resolve_safe_jsonl_target(
                session_id=source_session_id, preferred_uuid=source_uuid, purpose="fork_command_head",
            )
            follows_head = not (head_health is not None and is_stale_session_head(head_health, source_uuid))
        if not follows_head:
            persisted = self._persisted_session_uuids(source_session_id)
            if persisted and source_uuid not in persisted:
                logger.warning(
                    "[fork_command] replied uuid missing from JSONL route=%s session_id=%s uuid=%s",
                    route, source_session_id, source_uuid,
                )
                await self._send_system_message(
                    route=route,
                    bot=context.bot,
                    text="can't fork from this message",
                    disable_notification=True,
                    reply_to_message_id=message.message_id,
                )
                return
        elif stable_uuid and stable_uuid != source_uuid:
            logger.info(
                "[fork_command] JSONL advanced during stability wait: %s → %s",
                source_uuid,
                stable_uuid,
            )
            resolved_uuid, resolved_route, resolved_message_id = (
                self._resolve_persisted_fork_source(
                    session_id=source_session_id,
                    preferred_uuid=stable_uuid,
                    preferred_route=source_route,
                )
            )
            source_uuid = resolved_uuid
            source_route = resolved_route
            source_message_id = resolved_message_id

        lineage_name, topic_name = self._next_topic_alias_and_title(
            state,
            " ".join(context.args).strip() or None,
        )
        source_link = (
            self._build_message_link(source_route, source_message_id)
            if source_message_id is not None
            else None
        )
        service_lines = ["fork created"]
        if source_link:
            service_lines.append(f'forked from <a href="{html.escape(source_link)}">source message</a>')
        service_html = "\n".join(service_lines)
        created = await self._create_child_fork_topic(
            parent_state=state,
            bot=context.bot,
            source_session_id=source_session_id,
            source_uuid=source_uuid,
            source_route=source_route,
            source_message_id=source_message_id,
            topic_name=topic_name,
            child_service_html=service_html,
            notify_on_completion=True,
            lineage_name=lineage_name,
            lineage_origin="user_fork",
        )
        child_link = created["child_link"]
        confirmation = "fork created"
        if child_link:
            confirmation = f'fork created: <a href="{html.escape(child_link)}">{html.escape(topic_name)}</a>'
        confirmation_message = await self._send_system_html_message(
            route=route,
            bot=context.bot,
            html_text=confirmation,
            disable_notification=True,
            reply_to_message_id=message.message_id,
        )
        confirmation_id = self._sent_message_id(confirmation_message[0]) if confirmation_message else None
        if confirmation_id is not None:
            self._record_message_binding(
                route=route,
                message_id=confirmation_id,
                jsonl_uuid=source_uuid,
                session_id=source_session_id,
                role="assistant",
            )

    async def handle_delete(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle deprecated /delete commands without removing topics or state."""
        if update.effective_user is None or update.effective_message is None:
            return
        if not self._is_authorized(update.effective_user.id):
            return

        route = self._route_for_message(update.effective_message)
        scope = "stop_tree" if len(context.args) == 1 and context.args[0].strip().lower() == "all" else "stop_branch"
        await self._send_system_message(
            route=route,
            bot=context.bot,
            text=f"/delete is deprecated and non-destructive; use /{scope} instead",
            disable_notification=True,
        )


_TELEGRAM_POLL_RETRY_DELAYS = (2.0, 4.0, 8.0, 16.0, 30.0)


class _TelegramPollingRetryExhaustedError(TelegramError):
    pass


class _TelegramPollingRequest(HTTPXRequest):
    def __init__(self) -> None:
        super().__init__(connection_pool_size=1)
        self.exhausted_error: TelegramError | None = None

    async def post(self, *args: Any, **kwargs: Any) -> Any:
        if self.exhausted_error is not None:
            raise _TelegramPollingRetryExhaustedError("Telegram polling retry budget exhausted")
        for attempt in range(len(_TELEGRAM_POLL_RETRY_DELAYS) + 1):
            try:
                result = await super().post(*args, **kwargs)
            except BadRequest:
                raise
            except (Conflict, NetworkError) as exc:
                if attempt == len(_TELEGRAM_POLL_RETRY_DELAYS):
                    self.exhausted_error = exc
                    raise _TelegramPollingRetryExhaustedError(
                        "Telegram polling retry budget exhausted"
                    ) from exc
                delay = _TELEGRAM_POLL_RETRY_DELAYS[attempt]
                logger.warning(
                    "[polling_retry] error=%s retry=%s/%s backoff=%.1fs",
                    type(exc).__name__, attempt + 1, len(_TELEGRAM_POLL_RETRY_DELAYS), delay,
                )
                await asyncio.sleep(delay)
            else:
                if attempt:
                    logger.info("[polling_retry] recovered after %s retries", attempt)
                return result


def create_telegram_app(config: OBSConfig) -> Application:
    """Create and configure a python-telegram-bot Application."""
    primary_token = config.telegram_primary_bot_token
    if not primary_token:
        raise ValueError("OBS_TELEGRAM_BOT_TOKEN or OBS_TELEGRAM_BOT_TOKENS is required")
    if not config.telegram_allowed_user_ids:
        raise ValueError(
            "OBS_TELEGRAM_ALLOWED_USERS is required (comma-separated Telegram user IDs). "
            "The bot will not start without an explicit allowlist."
        )

    bot = TelegramBot(config)
    polling_request = _TelegramPollingRequest()
    app = (
        Application.builder()
        .token(primary_token)
        .get_updates_request(polling_request)
        .concurrent_updates(True)
        .build()
    )
    app.bot_data["obs_telegram_bot"] = bot
    app.bot_data["obs_polling_request"] = polling_request
    app.add_error_handler(bot.handle_application_error)
    app.add_handler(MessageHandler(filters.COMMAND, bot.log_command_update), group=-1)
    app.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(r"^/(?:tree-|tree-(?:ancestors|descendants|children))(?:@[A-Za-z0-9_]+)?(?:\s|$)"),
            bot.handle_tree_alias_command,
        )
    )
    app.add_handler(CommandHandler("help", bot.handle_help))
    app.add_handler(CommandHandler("clear", bot.handle_clear))
    app.add_handler(CommandHandler("new", bot.handle_new))
    app.add_handler(CommandHandler("new_group", bot.handle_new_group))
    app.add_handler(CommandHandler("new_bot", bot.handle_new_bot))
    app.add_handler(CommandHandler("unschedule", bot.handle_unschedule))
    app.add_handler(CommandHandler("stop", bot.handle_stop))
    app.add_handler(CommandHandler("stop_branch", bot.handle_stop_branch))
    app.add_handler(CommandHandler("stop_tree", bot.handle_stop_tree))
    app.add_handler(CommandHandler("maintenance_restart", bot.handle_restart))
    app.add_handler(CommandHandler("restart", bot.handle_restart))
    app.add_handler(CommandHandler("shutdown", bot.handle_shutdown))
    app.add_handler(CommandHandler("shutdown_autoresume", bot.handle_shutdown_autoresume))
    app.add_handler(CommandHandler("model", bot.handle_model))
    app.add_handler(CommandHandler("effort", bot.handle_effort))
    app.add_handler(CommandHandler("session", bot.handle_session))
    app.add_handler(CommandHandler("report", bot.handle_report))
    app.add_handler(CommandHandler("schedule", bot.handle_schedule))
    app.add_handler(CommandHandler("tree", bot.handle_tree))
    app.add_handler(CommandHandler("tree_descendants", bot.handle_tree_descendants))
    app.add_handler(CommandHandler("tree_children", bot.handle_tree_children))
    app.add_handler(CommandHandler("tree_ancestors", bot.handle_tree_ancestors))
    app.add_handler(CommandHandler("fork", bot.handle_fork))
    app.add_handler(CommandHandler("delete", bot.handle_delete))
    app.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(_NEW_GROUP_ALIAS_PATTERN),
            bot.handle_new_group_alias,
        )
    )
    app.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(_NEW_BOT_ALIAS_PATTERN),
            bot.handle_new_bot_alias,
        )
    )
    app.add_handler(MessageHandler(filters.COMMAND, bot.handle_unknown_command))
    app.add_handler(MessageHandler(filters.StatusUpdate.FORUM_TOPIC_CREATED, bot.handle_forum_topic_created))
    app.add_handler(MessageHandler(filters.StatusUpdate.FORUM_TOPIC_EDITED, bot.handle_forum_topic_edited))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, bot.handle_new_chat_members))
    inbound_filter = (
        filters.TEXT
        | filters.CAPTION
        | filters.PHOTO
        | filters.VIDEO
        | filters.Document.ALL
        | filters.AUDIO
        | filters.VOICE
        | filters.VIDEO_NOTE
        | filters.ANIMATION
        | filters.ATTACHMENT
    ) & ~filters.COMMAND
    app.add_handler(MessageHandler(inbound_filter, bot.handle_message))
    return app


async def _set_bot_commands(app: Application) -> None:
    """Register bot commands with Telegram for menu auto-suggestion."""
    from telegram import BotCommand

    await app.bot.set_my_commands([
        BotCommand("help", "Show concise command usage"),
        BotCommand("clear", "Clear this topic but keep its agent identity; use '/clear all' for the whole group"),
        BotCommand("new", "Reset this topic into a new trunk agent; optional: /new [emoji] [name]"),
        BotCommand("new_group", "Create a new forum supergroup and add the configured OBS bots"),
        BotCommand("new_bot", "Create a new Claudia sender bot through BotFather"),
        BotCommand("unschedule", "Remove schedules: topic, or branch|tree|all|chat; --include-protected"),
        BotCommand("stop", "Interrupt this topic; '/stop all' every tree, '/stop chat' this chat"),
        BotCommand("stop_branch", "Interrupt this agent and all recursive descendants"),
        BotCommand("stop_tree", "Interrupt the complete root team tree"),
        BotCommand("restart", "Restart OBS, auto-resuming mid-turn agents; '/restart plain' resumes nothing"),
        BotCommand("maintenance_restart", "Same as /restart: restart and auto-resume mid-turn agents"),
        BotCommand("shutdown", "Stop OBS only; no running agents auto-resume at next startup"),
        BotCommand("shutdown_autoresume", "Stop OBS only; save running agents for auto-resume at next startup, without expiry"),
        BotCommand("model", "Select model before the first message of a new or cleared session"),
        BotCommand("effort", "Show or set effort: low, medium, high, xhigh, max, auto"),
        BotCommand("session", "Show agent, model, files, runtime and hooks"),
        BotCommand("report", "Save a debug case file for this message/topic"),
        BotCommand("schedule", "Create schedules once Sprint 1 reliability is approved"),
        BotCommand("tree", "Render the full agent tree for this team"),
        BotCommand("tree_descendants", "Render this agent and all descendants"),
        BotCommand("tree_children", "Render this agent and direct children"),
        BotCommand("tree_ancestors", "Render this agent and all ancestors"),
        BotCommand("fork", "Create a new topic from this head or replied message"),
    ])


async def _clear_secondary_bot_commands(config: OBSConfig) -> None:
    """Clear stale official command menus from secondary sender bots."""
    for token in config.telegram_sender_bot_tokens[1:]:
        try:
            await Bot(token=token).delete_my_commands()
        except Exception:
            logger.warning("Failed clearing commands on secondary sender bot", exc_info=True)


_TELEGRAM_RUNTIME_HEALTH_POLL_SECONDS = 0.5
_TELEGRAM_RUNTIME_RESTART_BASE_SECONDS = 1.0
_TELEGRAM_RUNTIME_RESTART_MAX_SECONDS = 30.0


async def _shutdown_telegram_runtime(*, app: Application, tg_bot: TelegramBot) -> None:
    """Best-effort shutdown for Telegram runtime resources."""
    try:
        updater = app.updater
        if updater is not None and updater.running:
            await updater.stop()
    except Exception:
        logger.warning("Telegram updater stop failed", exc_info=True)

    try:
        if app.running:
            await app.stop()
    except Exception:
        logger.warning("Telegram application stop failed", exc_info=True)

    try:
        await tg_bot.shutdown()
    except Exception:
        logger.warning("Telegram bot runtime shutdown failed", exc_info=True)

    try:
        await app.shutdown()
    except Exception:
        logger.warning("Telegram application shutdown failed", exc_info=True)


# Set once this process's first runtime reaches the resume step (see below).
_PROCESS_CRASH_RESUME_ATTEMPTED = False


async def _run_telegram_bot_once(config: OBSConfig, *, first_start: bool = True) -> None:
    """Run one Telegram runtime instance until cancellation or runtime failure."""
    app = create_telegram_app(config)
    tg_bot: TelegramBot = app.bot_data["obs_telegram_bot"]
    polling_error: asyncio.Queue[TelegramError] = asyncio.Queue(maxsize=1)

    def _record_polling_error(exc: TelegramError) -> None:
        logger.exception("Exception happened while polling for updates.", exc_info=exc)
        if isinstance(exc, Conflict) and polling_error.empty():
            polling_error.put_nowait(exc)

    logger.info("Starting Telegram bot...")
    try:
        await tg_bot.initialize_runtime()
        await app.initialize()
        await tg_bot._ensure_background_poller(app.bot)
        await _clear_secondary_bot_commands(config)
        await _set_bot_commands(app)
        await app.start()
        drop_pending_updates = (
            (os.environ.get("OBS_TELEGRAM_DROP_PENDING_UPDATES") or "").strip().lower()
            in {"1", "true", "yes", "on"}
        )
        await app.updater.start_polling(
            drop_pending_updates=drop_pending_updates,
            error_callback=_record_polling_error,
        )
        _install_maintenance_signal_handler(tg_bot)
        # Crash snapshot and orphan reaping belong to the FIRST runtime of this
        # process that gets this far, not to restart_count == 0: when Telegram is
        # unreachable at boot (power cut, Wi-Fi still down) the first runtime dies
        # in app.initialize() before reaching this point, and keying on
        # first_start skipped the previous process's snapshot forever while the
        # new writer overwrote it (2026-10-21 10:17Z power cut, vault-scg2). An
        # in-process restart after this point still must not replay this
        # process's own snapshot, so the flag is set before anything acts.
        global _PROCESS_CRASH_RESUME_ATTEMPTED
        resume_crash = not _PROCESS_CRASH_RESUME_ATTEMPTED
        _PROCESS_CRASH_RESUME_ATTEMPTED = True
        tg_bot.start_maintenance_resume(include_crash=resume_crash)
        tg_bot.start_crash_snapshot_writer()
        if resume_crash:
            _start_orphan_cli_reaper()

        while True:
            await asyncio.sleep(_TELEGRAM_RUNTIME_HEALTH_POLL_SECONDS)
            updater_running = app.updater.running if app.updater is not None else False
            polling_request = app.bot_data.get("obs_polling_request")
            if isinstance(polling_request, _TelegramPollingRequest) and polling_request.exhausted_error is not None:
                raise _TelegramPollingRetryExhaustedError(
                    "Telegram polling retry budget exhausted"
                ) from polling_request.exhausted_error
            if not polling_error.empty():
                raise _TelegramPollingConflictError(
                    "Telegram polling conflict: another getUpdates consumer is active"
                ) from polling_error.get_nowait()
            if not app.running or not updater_running:
                raise RuntimeError(
                    "Telegram runtime stopped unexpectedly: "
                    f"app.running={app.running} updater.running={updater_running}"
                )
    finally:
        await _shutdown_telegram_runtime(app=app, tg_bot=tg_bot)


def _cli_hang_watchdog_seconds() -> float:
    """Seconds a turn's CLI may spin at full CPU without JSONL progress (0 = off)."""
    raw = (os.environ.get("OBS_CLI_HANG_WATCHDOG_SECONDS") or "").strip()
    try:
        return max(0.0, float(raw)) if raw else 900.0
    except ValueError:
        return 900.0


def _read_proc_cpu_seconds(pid: int) -> float | None:
    """User+system CPU seconds of one process (not its children), or None."""
    try:
        raw = Path(f"/proc/{pid}/stat").read_text()
        fields = raw[raw.rindex(")") + 2:].split()
        return (int(fields[11]) + int(fields[12])) / os.sysconf("SC_CLK_TCK")
    except (OSError, ValueError, IndexError):
        return None


def _stop_kill_grace_seconds() -> float:
    """Seconds a stopped turn may keep running before its CLI is killed (0 = never)."""
    raw = (os.environ.get("OBS_STOP_KILL_GRACE_SECONDS") or "").strip()
    try:
        return max(0.0, float(raw)) if raw else 30.0
    except ValueError:
        return 30.0


_orphan_reaper_tasks: set[asyncio.Task] = set()


def _start_orphan_cli_reaper() -> None:
    """Kill Claude CLIs orphaned by a previous daemon (vault-u3b.66), off the event loop."""
    if (os.environ.get("OBS_ORPHAN_CLI_REAP") or "").strip().lower() in {"0", "false", "no", "off"}:
        return

    async def _reap() -> None:
        try:
            pids = await asyncio.to_thread(_maint.reap_orphaned_agent_clis, own_pgid=os.getpgrp())
        except Exception:
            logger.warning("[orphan_reaper] failed", exc_info=True)
            return
        if pids:
            logger.warning("[orphan_reaper] terminated orphaned Claude CLIs pids=%s", pids)
        else:
            logger.info("[orphan_reaper] no orphaned Claude CLIs")

    task = asyncio.create_task(_reap())
    _orphan_reaper_tasks.add(task)
    task.add_done_callback(_orphan_reaper_tasks.discard)


def _install_kill_switch_sigterm_handler(tg_bot: "TelegramBot") -> None:
    """SIGTERM = kill switch: discard the crash snapshot, then die as before (143).

    ``supervisorctl stop|restart``, a plain restart and the group SIGTERM of a
    maintenance restart all arrive here, so none of them resumes the crash
    snapshot. A Python-level handler (not loop.add_signal_handler) runs at the
    next bytecode boundary even when the event loop is saturated. Crashes (OOM
    SIGKILL, watchdog SIGKILL fallback, unhandled exit) never run it.
    """

    def _handler(signum, frame):  # noqa: ARG001
        try:
            discarded = tg_bot.discard_crash_snapshot_for_kill_switch()
            os.write(2, f"[crash_resume] SIGTERM: kill switch, crash snapshot discarded={discarded}\n".encode())
        except Exception:
            pass
        signal.signal(signal.SIGTERM, signal.SIG_DFL)
        os.kill(os.getpid(), signal.SIGTERM)

    try:
        signal.signal(signal.SIGTERM, _handler)
    except (ValueError, OSError):
        logger.warning("Kill-switch SIGTERM handler unavailable", exc_info=True)


def _install_maintenance_signal_handler(tg_bot: "TelegramBot") -> None:
    """SIGUSR1 = maintenance restart (``python -m obs_agent.maintenance_restart``); SIGTERM = kill switch."""
    _install_kill_switch_sigterm_handler(tg_bot)
    try:
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(
            _maint.MAINTENANCE_SIGNAL,
            lambda: asyncio.ensure_future(
                tg_bot.request_maintenance_restart(source="signal:SIGUSR1")
            ),
        )
    except (NotImplementedError, RuntimeError, ValueError):
        logger.warning("Maintenance-restart signal handler unavailable", exc_info=True)


def _is_fatal_telegram_runtime_error(exc: Exception) -> bool:
    """Errors that should fail fast rather than trigger restart loops."""
    return isinstance(exc, (ValueError, _TelegramPollingConflictError, _TelegramPollingRetryExhaustedError))


async def run_telegram_bot(config: OBSConfig) -> None:
    """Start Telegram bot with runtime supervision and bounded backoff restart."""
    # Outage age is measured to this process's start, not to the moment the
    # first Telegram runtime reaches the resume step (vault-9tij).
    _maint.set_process_started_at(time.time())
    restart_count = 0
    while True:
        try:
            await _run_telegram_bot_once(config, first_start=restart_count == 0)
            logger.warning("Telegram runtime exited unexpectedly; scheduling restart")
        except KeyboardInterrupt:
            logger.info("Telegram runtime interrupted; exiting")
            return
        except asyncio.CancelledError:
            logger.info("Telegram runtime cancelled; exiting")
            raise
        except Exception as exc:
            if _is_fatal_telegram_runtime_error(exc):
                raise
            logger.exception("Telegram runtime crashed; scheduling restart")

        restart_count += 1
        delay_seconds = min(
            _TELEGRAM_RUNTIME_RESTART_MAX_SECONDS,
            _TELEGRAM_RUNTIME_RESTART_BASE_SECONDS * (2 ** min(restart_count - 1, 5)),
        )
        logger.warning(
            "Restarting Telegram runtime in %.1fs (attempt=%d)",
            delay_seconds,
            restart_count,
        )
        await asyncio.sleep(delay_seconds)
